<?php  ?>

   <div class="row text-center text-uppercase mar_bot_3">
                                <h3 class="head_font"><?=(!empty($company->company_name)?$company->company_name:'')?></h3>
                            </div>
                            <div class="row">
                                <hr style="border-bottom: 2px solid #000; margin: 0 0 5px">
                            </div>
                            <div class="row border_bottom mar_bot_3">
                                <h4 class="mar_0 bold">Attention: <?= $header[0]->owner_name ?></h4>
                            </div>
                            <div class="row border-bottom-double text-center mar_bot_3">
                                <h5 class="mar_0 bold">Sales Contract</h5>
                            </div>