#
# TABLE STRUCTURE FOR: acc_master
#

DROP TABLE IF EXISTS `acc_master`;

CREATE TABLE `acc_master` (
  `am_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(99) NOT NULL,
  `am_code` varchar(30) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email_id` varchar(99) NOT NULL,
  `official_address` text CHARACTER SET utf16 NOT NULL,
  `shipping_address` text NOT NULL,
  `place_of_supply` text DEFAULT NULL,
  `supplier_buyer` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=Supplier,1=Buyer',
  `city` varchar(100) NOT NULL,
  `country_id` int(11) NOT NULL,
  `insured_amount` double DEFAULT NULL,
  `credit_limit` double DEFAULT NULL,
  `payment_term` varchar(255) DEFAULT NULL,
  `owner_name` varchar(100) CHARACTER SET utf16 NOT NULL,
  `owner_nationality` int(11) DEFAULT NULL,
  `owner_email` varchar(222) DEFAULT NULL,
  `manager_name` varchar(222) DEFAULT NULL,
  `manager_nationality` int(11) DEFAULT NULL,
  `manager_email` varchar(222) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modify_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`am_id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=latin1;

INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (12, 'ROY TRADER', 'AP-001', '87897899887', '', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 1, '2020-06-24 14:54:08', '2021-04-01 09:38:04', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (31, 'Sealord Group LTD', 'SLG', '-', '-', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-12 15:22:24', '2021-08-12 15:22:24', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (32, 'Cap Blanc Pelagique SARL', 'CBP SARL', '-', '-', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-12 15:23:19', '2021-08-12 15:23:19', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (33, 'Daisui Co. LTD', 'DAI JP', '', '', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-12 15:27:41', '2021-08-12 15:27:41', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (34, 'Burum Seafood Trading LLC', 'BURUM', '-', '-', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-12 15:30:44', '2021-08-12 15:30:44', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (35, 'CEPP SARL', 'CEPP', '-', '-', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-12 15:31:10', '2021-08-12 15:31:10', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (36, 'Maoming Hongye Aquatic Products Co. Ltd', 'Maoming- Mark', '-', '-', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-12 15:32:03', '2021-08-12 15:32:03', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (37, 'Trust Link Ventures Ltd', 'Trustlink', '-', 'saby@seafoodmiddleeast.com', '', '', NULL, 1, 'Tema', 81, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-12 15:33:01', '2021-10-26 14:28:49', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (38, 'African Everest Limited Company', 'African Everest', '-', 'brian@fsmiddleeast.ae, saby@seafoodmiddleeast.com', '<p>\r\n	Official Address</p>\r\n', '<p>\r\n	Shipping address</p>\r\n', '<p>\r\n	Supply address</p>\r\n', 1, 'Tema', 81, NULL, NULL, NULL, 'Mr. Robert Ocran', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-12 15:33:34', '2022-03-28 14:51:29', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (39, 'Congelcam SA', 'Congelcam', '-', 'saby@seafoodmiddleeast.com; brian@fsmiddleeast.ae', '', '', NULL, 1, 'Douala', 37, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-12 15:34:34', '2022-03-26 01:40:16', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (40, 'North South Seafood Trading LLC', 'North South- Robert', '-', '-', '', '', NULL, 1, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-12 15:35:45', '2021-08-12 15:35:45', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (41, 'Hashi Energy LTD', 'Hashi- UN', '-', '-', '', '', NULL, 1, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-12 15:36:16', '2021-08-12 15:36:16', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (42, 'Amisachi LTD', 'Amisachi- Annirudha', '-', '-', '', '', NULL, 1, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-12 15:36:54', '2021-08-12 15:36:54', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (43, 'AFRI VENTURES FZE', 'AFRI', '', '', '', '', NULL, 1, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 14:40:50', '2021-08-17 14:40:50', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (44, 'CDDA', 'CDDA', '', '', '', '', NULL, 1, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 14:43:44', '2021-08-17 14:43:44', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (45, 'CDPA-CI', 'CDPA-CI', '', '', '', '', NULL, 1, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 14:44:25', '2021-08-17 14:44:25', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (46, 'Just Ack Company Ltd', 'Just Ack', '', '', '', '', NULL, 1, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 14:45:12', '2021-08-17 14:45:12', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (47, 'Kyokuyo Ltd', 'Kyokuyo', '', '', '', '', NULL, 1, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 14:46:14', '2021-08-17 14:46:14', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (48, 'Lake Bounty', 'LBO', '', '', '', '', NULL, 1, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 14:46:51', '2021-08-17 14:46:51', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (49, 'Martin Pecheur SARL', 'Martin', '', '', '', '', NULL, 1, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 14:47:16', '2021-08-17 14:47:16', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (50, 'Ocean Fresh - Jordan', 'OFRESH', '', '', '', '', NULL, 1, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 14:48:12', '2021-08-17 14:48:12', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (51, 'UNITED TRADERS INCORPORATED', 'UTI', '', '', '', '', NULL, 1, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 14:48:54', '2021-08-17 14:48:54', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (52, 'West Africa Enterprise INC', 'West Africa', '', 'saby@seafoodmiddleeast.com; brian@fsmiddleeast.ae', '', '', NULL, 1, '0', 120, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 14:49:19', '2022-03-26 10:48:48', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (53, 'Blue Marine House', 'BM', '', '', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 14:51:44', '2021-08-17 14:51:44', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (54, 'Chunbo Moolsan Co., Ltd', 'Chunbo', '', '', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 14:52:38', '2021-08-17 14:52:38', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (55, 'COMAVIP SA', 'COMAVIP', '', '', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 14:53:54', '2021-08-17 14:53:54', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (56, 'Cornelis Vrolijk B.V.', 'Vrolijk', '', '', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 14:54:36', '2021-08-17 14:54:36', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (57, 'E & K CO LTD', 'Eunkang', '', '', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 14:55:18', '2021-08-17 14:55:18', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (58, 'ETS Cherif Ahmed Cherivou', 'ETS CAC', '', '', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 14:56:06', '2021-08-17 14:56:06', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (59, 'FH Group Procurement Sarl', 'FH Group', '', '', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 14:56:30', '2021-08-17 14:56:30', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (60, 'ICELAND PELAGIC EHF', 'ICE PELA', '', '', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 14:57:22', '2021-08-17 14:57:22', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (61, 'Independent Fisheries Ltd', 'INDEP', '', '', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 14:57:44', '2021-08-17 14:57:44', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (62, 'KYOREI CO., LTD', 'Kyorie', '', '', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 14:58:37', '2021-08-17 14:58:37', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (63, 'MARUHA NICHIRO CORPORATION', 'Maruha', '', '', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 15:00:10', '2021-08-17 15:00:10', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (64, 'Oman Fisheries Co. S.A.O.G.', 'Oman Biju', '', '', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 15:00:44', '2021-08-17 15:00:44', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (65, 'Parlevliet & Van Der Plas B.V', 'P&V', '', '', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 15:01:24', '2021-08-17 15:01:24', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (66, 'PORTSIDE FISH COMPANY LIMITED', 'Portside', '', '', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 15:02:00', '2021-08-17 15:02:00', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (67, 'Sea Freeze International LLC', 'Seafreese Rafeeq', '', '', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 15:02:33', '2021-08-17 15:02:33', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (68, 'SOMASCIR.SA', 'SOMASCIR.SA', '', '', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 15:03:12', '2021-08-17 15:03:12', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (69, 'Span Ice Ehf.', 'Span Ice Ehf.', '', '', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 15:03:29', '2021-08-17 15:03:29', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (70, 'SUNRISE FISHERIES CO LLC', 'Sunrise- Oman', '', '', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-08-17 15:04:24', '2021-08-17 15:04:24', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (71, 'Tamimi Fisheries Company Ltd', 'Tamimi- Yemen', '', '', '', '', NULL, 0, '0', 0, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-09-09 15:43:08', '2021-09-09 15:43:08', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (72, 'michael  pvt test', '0001', '1234567890', '', '', '', NULL, 0, '', 63, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-10-09 15:41:31', '2021-10-09 15:56:28', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (73, 'Ratan', '0002', '', '', '', '', NULL, 1, '', 2, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-10-09 16:05:36', '2021-10-09 16:05:36', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (74, 'Victoria Perch Ltd', 'Victoria', '', '', '', '', NULL, 0, 'Tanzania', 210, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-10-23 12:46:13', '2021-10-23 12:46:13', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (75, 'Nordic Seafood SA', 'Nord Denmark', '', '', '', '', NULL, 1, 'Copenhagen', 58, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-10-23 16:22:28', '2021-10-23 16:22:28', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (76, 'Marine Foods B.V.', 'Marine Foods Holland', '', '', '', '', NULL, 0, 'Scheveningen', 150, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-10-26 14:26:34', '2021-10-26 14:26:34', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (77, 'Mauritania Seafood SARL', 'MR SF SARL', '', '', '', '', NULL, 0, 'Nouadhibou', 135, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-10-27 15:20:37', '2021-10-27 15:20:37', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (78, 'Fish Mart - Anand', 'Anand', '', '', '', '', NULL, 0, 'Gujurat', 99, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-10-28 16:10:31', '2021-10-28 16:10:31', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (79, 'The Golden Al Sinyar', 'Golden Oman', '', '', '', '', NULL, 0, '', 161, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-10-28 18:08:58', '2021-10-28 18:08:58', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (80, 'ASMAK MUSCAT INTL LLC', 'ASMAK', '', '', '', '', NULL, 0, '', 161, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-10-28 18:52:30', '2021-10-28 18:52:30', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (81, 'Lake Treasure Ltd', 'Lake Treasure', '', '', '', '', NULL, 0, '', 110, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-10-29 19:18:58', '2021-10-29 19:18:58', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (82, 'raja', '001', '', '', '', '', NULL, 0, '', 3, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-11-05 15:27:37', '2021-11-05 15:56:58', 1);
INSERT INTO `acc_master` (`am_id`, `name`, `am_code`, `phone`, `email_id`, `official_address`, `shipping_address`, `place_of_supply`, `supplier_buyer`, `city`, `country_id`, `insured_amount`, `credit_limit`, `payment_term`, `owner_name`, `owner_nationality`, `owner_email`, `manager_name`, `manager_nationality`, `manager_email`, `user_id`, `create_date`, `modify_date`, `status`) VALUES (83, 'def', '002', '123456789', 'pritamkhanofficial@gmail.com', '', '', NULL, 1, '', 44, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0, '2021-11-05 15:28:43', '2022-04-04 13:47:29', 1);


#
# TABLE STRUCTURE FOR: assigned_templates
#

DROP TABLE IF EXISTS `assigned_templates`;

CREATE TABLE `assigned_templates` (
  `at_id` int(11) NOT NULL AUTO_INCREMENT,
  `offer_id` int(11) NOT NULL,
  `vt_id` int(11) NOT NULL,
  `resource_id` varchar(255) NOT NULL,
  `marketing_id` varchar(250) NOT NULL,
  `marketing_edit_status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 = can''t see',
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`at_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf16;

INSERT INTO `assigned_templates` (`at_id`, `offer_id`, `vt_id`, `resource_id`, `marketing_id`, `marketing_edit_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (11, 127, 20, '', '34', 1, 1, '2021-10-22 17:17:49', '2021-10-22 18:36:13', 1);
INSERT INTO `assigned_templates` (`at_id`, `offer_id`, `vt_id`, `resource_id`, `marketing_id`, `marketing_edit_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (12, 143, 16, '', '34,35', 1, 1, '2021-10-27 19:30:10', '2021-10-27 19:33:04', 1);
INSERT INTO `assigned_templates` (`at_id`, `offer_id`, `vt_id`, `resource_id`, `marketing_id`, `marketing_edit_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (13, 189, 20, '14', '', 0, 1, '2021-10-31 22:59:04', '2021-10-31 22:59:04', 1);
INSERT INTO `assigned_templates` (`at_id`, `offer_id`, `vt_id`, `resource_id`, `marketing_id`, `marketing_edit_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (14, 156, 20, '', '15', 1, 1, '2021-11-02 13:33:44', '2021-11-02 13:33:58', 1);
INSERT INTO `assigned_templates` (`at_id`, `offer_id`, `vt_id`, `resource_id`, `marketing_id`, `marketing_edit_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (15, 190, 16, '36', '45', 1, 1, '2021-11-05 16:43:32', '2021-11-05 16:44:56', 1);
INSERT INTO `assigned_templates` (`at_id`, `offer_id`, `vt_id`, `resource_id`, `marketing_id`, `marketing_edit_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (16, 192, 20, '', '52', 1, 1, '2021-11-05 18:41:43', '2022-02-16 15:54:27', 1);
INSERT INTO `assigned_templates` (`at_id`, `offer_id`, `vt_id`, `resource_id`, `marketing_id`, `marketing_edit_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (17, 193, 16, '36', '49', 1, 1, '2021-11-06 12:32:15', '2021-11-06 12:32:29', 1);
INSERT INTO `assigned_templates` (`at_id`, `offer_id`, `vt_id`, `resource_id`, `marketing_id`, `marketing_edit_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (18, 194, 16, '', '50', 1, 1, '2021-11-10 18:10:57', '2021-11-10 18:19:21', 1);
INSERT INTO `assigned_templates` (`at_id`, `offer_id`, `vt_id`, `resource_id`, `marketing_id`, `marketing_edit_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (19, 198, 24, '51', '50', 1, 1, '2021-12-16 11:50:16', '2022-02-02 17:40:20', 1);
INSERT INTO `assigned_templates` (`at_id`, `offer_id`, `vt_id`, `resource_id`, `marketing_id`, `marketing_edit_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (20, 210, 16, '', '34', 1, 1, '2022-03-19 18:31:38', '2022-03-24 14:41:40', 1);
INSERT INTO `assigned_templates` (`at_id`, `offer_id`, `vt_id`, `resource_id`, `marketing_id`, `marketing_edit_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (21, 213, 16, '', '34,50', 1, 1, '2022-03-22 19:55:26', '2022-03-24 14:40:42', 1);
INSERT INTO `assigned_templates` (`at_id`, `offer_id`, `vt_id`, `resource_id`, `marketing_id`, `marketing_edit_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (22, 214, 16, '', '35', 0, 1, '2022-03-26 01:33:51', '2022-03-26 01:33:51', 1);
INSERT INTO `assigned_templates` (`at_id`, `offer_id`, `vt_id`, `resource_id`, `marketing_id`, `marketing_edit_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (23, 214, 16, '', '35', 0, 1, '2022-03-26 01:34:05', '2022-03-26 01:34:05', 1);
INSERT INTO `assigned_templates` (`at_id`, `offer_id`, `vt_id`, `resource_id`, `marketing_id`, `marketing_edit_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (24, 215, 16, '', '35', 1, 1, '2022-03-26 10:50:03', '2022-03-28 14:48:33', 1);
INSERT INTO `assigned_templates` (`at_id`, `offer_id`, `vt_id`, `resource_id`, `marketing_id`, `marketing_edit_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (25, 221, 16, '', '35', 0, 1, '2022-03-30 15:27:46', '2022-03-30 15:27:46', 1);


#
# TABLE STRUCTURE FOR: blocks
#

DROP TABLE IF EXISTS `blocks`;

CREATE TABLE `blocks` (
  `block_id` int(11) NOT NULL AUTO_INCREMENT,
  `block_size` varchar(120) NOT NULL,
  `information` varchar(300) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`block_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf16;

INSERT INTO `blocks` (`block_id`, `block_size`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (3, '10/2', '', 1, '2021-08-04 19:16:53', '2021-08-04 19:51:38', 1);
INSERT INTO `blocks` (`block_id`, `block_size`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (4, '10/3', '', 0, '2021-08-04 19:55:08', '2021-09-09 15:32:58', 1);


#
# TABLE STRUCTURE FOR: buying_price
#

DROP TABLE IF EXISTS `buying_price`;

CREATE TABLE `buying_price` (
  `bp_id` int(11) NOT NULL AUTO_INCREMENT,
  `od_id` int(11) NOT NULL,
  `li_id` int(11) NOT NULL COMMENT 'line item',
  `incoterm_id` int(11) NOT NULL,
  `currency_id` int(11) NOT NULL,
  `buying_price` double NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`bp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf16;

INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (62, 149, 1, 2, 2, '100', 1, '2021-11-02 12:55:25', '2021-11-02 12:55:25', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (63, 150, 3, 2, 2, '50', 1, '2021-11-02 13:10:43', '2021-11-02 13:10:43', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (64, 150, 4, 2, 2, '75', 1, '2021-11-02 13:11:04', '2021-11-02 13:11:04', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (65, 151, 5, 2, 2, '500', 1, '2021-11-02 13:24:23', '2021-11-02 13:24:23', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (66, 284, 1, 1, 2, '500', 1, '2021-11-06 12:02:08', '2021-11-06 12:02:08', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (67, 281, 2, 2, 2, '150', 1, '2021-11-08 17:07:16', '2021-11-08 17:07:16', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (68, 281, 3, 2, 2, '50', 1, '2021-11-08 17:07:24', '2021-11-08 17:07:24', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (69, 112, 2, 2, 2, '150', 1, '2021-11-08 17:07:41', '2021-11-08 17:07:41', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (70, 112, 3, 2, 2, '50', 1, '2021-11-08 17:07:41', '2021-11-08 17:07:41', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (72, 85, 2, 2, 2, '150', 1, '2021-11-08 17:07:45', '2021-11-08 17:07:45', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (73, 85, 3, 2, 2, '50', 1, '2021-11-08 17:07:45', '2021-11-08 17:07:45', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (75, 285, 1, 1, 1, '5', 1, '2021-11-10 18:02:06', '2021-11-10 18:02:06', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (76, 285, 2, 1, 1, '5', 1, '2021-11-10 18:57:45', '2021-11-10 18:58:13', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (77, 290, 1, 4, 2, '100', 1, '2021-12-16 11:29:14', '2021-12-16 11:29:14', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (78, 290, 2, 4, 2, '10', 1, '2021-12-16 11:29:30', '2021-12-16 11:29:30', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (79, 290, 3, 4, 2, '40', 1, '2021-12-16 11:29:46', '2021-12-16 11:32:39', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (80, 289, 1, 4, 2, '100', 1, '2021-12-16 11:34:52', '2021-12-16 11:34:52', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (81, 289, 2, 4, 2, '60', 1, '2021-12-16 11:34:52', '2021-12-16 11:35:24', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (82, 289, 3, 4, 2, '40', 1, '2021-12-16 11:34:52', '2021-12-16 11:34:52', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (84, 291, 15, 3, 2, '0.05', 1, '2022-02-08 12:46:45', '2022-02-08 12:46:45', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (86, 292, 15, 3, 2, '0.03', 1, '2022-02-08 12:47:16', '2022-02-08 12:47:16', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (89, 293, 15, 3, 2, '0.05', 1, '2022-02-08 13:36:39', '2022-02-08 13:36:39', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (90, 294, 15, 3, 2, '0.05', 1, '2022-03-02 19:56:14', '2022-03-02 19:56:14', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (91, 295, 15, 3, 2, '0.05', 1, '2022-03-02 19:56:41', '2022-03-02 19:56:41', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (92, 305, 3, 1, 11, '15', 1, '2022-03-22 19:01:45', '2022-03-22 19:01:45', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (93, 310, 14, 2, 2, '12', 1, '2022-03-29 14:32:07', '2022-03-29 14:32:07', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (94, 315, 14, 2, 2, '12', 1, '2022-03-29 14:32:33', '2022-03-29 14:32:33', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (95, 319, 3, 1, 2, '10', 1, '2022-03-30 13:57:45', '2022-03-30 13:57:45', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (96, 321, 3, 1, 2, '10', 1, '2022-03-30 14:06:48', '2022-03-30 14:06:48', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (97, 322, 3, 1, 6, '10', 1, '2022-03-30 14:06:52', '2022-03-30 14:16:39', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (98, 323, 3, 1, 2, '10', 1, '2022-03-30 14:06:56', '2022-03-30 14:06:56', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (99, 330, 3, 1, 2, '10', 1, '2022-04-02 15:02:13', '2022-04-02 15:02:13', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (100, 331, 3, 1, 2, '10', 1, '2022-04-02 17:15:53', '2022-04-02 17:15:53', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (101, 331, 3, 1, 2, '10', 1, '2022-04-02 17:44:17', '2022-04-02 17:44:17', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (103, 332, 3, 1, 2, '10', 1, '2022-04-03 16:22:27', '2022-04-03 16:22:27', 1);
INSERT INTO `buying_price` (`bp_id`, `od_id`, `li_id`, `incoterm_id`, `currency_id`, `buying_price`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (104, 333, 10, 1, 2, '20', 1, '2022-04-04 13:40:43', '2022-04-04 13:40:43', 1);


#
# TABLE STRUCTURE FOR: countries
#

DROP TABLE IF EXISTS `countries`;

CREATE TABLE `countries` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `iso` char(2) NOT NULL,
  `name` varchar(80) NOT NULL,
  `nicename` varchar(80) NOT NULL,
  `iso3` char(3) DEFAULT NULL,
  `numcode` smallint(6) DEFAULT NULL,
  `phonecode` int(5) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`country_id`)
) ENGINE=MyISAM AUTO_INCREMENT=240 DEFAULT CHARSET=latin1;

INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (1, 'AF', 'AFGHANISTAN', 'Afghanistan', 'AFG', 4, 93, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (2, 'AL', 'ALBANIA', 'Albania', 'ALB', 8, 355, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (3, 'DZ', 'ALGERIA', 'Algeria', 'DZA', 12, 213, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (4, 'AS', 'AMERICAN SAMOA', 'American Samoa', 'ASM', 16, 1684, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (5, 'AD', 'ANDORRA', 'Andorra', 'AND', 20, 376, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (6, 'AO', 'ANGOLA', 'Angola', 'AGO', 24, 244, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (7, 'AI', 'ANGUILLA', 'Anguilla', 'AIA', 660, 1264, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (8, 'AQ', 'ANTARCTICA', 'Antarctica', NULL, NULL, 0, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (9, 'AG', 'ANTIGUA AND BARBUDA', 'Antigua and Barbuda', 'ATG', 28, 1268, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (10, 'AR', 'ARGENTINA', 'Argentina', 'ARG', 32, 54, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (11, 'AM', 'ARMENIA', 'Armenia', 'ARM', 51, 374, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (12, 'AW', 'ARUBA', 'Aruba', 'ABW', 533, 297, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (13, 'AU', 'AUSTRALIA', 'Australia', 'AUS', 36, 61, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (14, 'AT', 'AUSTRIA', 'Austria', 'AUT', 40, 43, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (15, 'AZ', 'AZERBAIJAN', 'Azerbaijan', 'AZE', 31, 994, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (16, 'BS', 'BAHAMAS', 'Bahamas', 'BHS', 44, 1242, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (17, 'BH', 'BAHRAIN', 'Bahrain', 'BHR', 48, 973, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (18, 'BD', 'BANGLADESH', 'Bangladesh', 'BGD', 50, 880, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (19, 'BB', 'BARBADOS', 'Barbados', 'BRB', 52, 1246, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (20, 'BY', 'BELARUS', 'Belarus', 'BLR', 112, 375, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (21, 'BE', 'BELGIUM', 'Belgium', 'BEL', 56, 32, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (22, 'BZ', 'BELIZE', 'Belize', 'BLZ', 84, 501, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (23, 'BJ', 'BENIN', 'Benin', 'BEN', 204, 229, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (24, 'BM', 'BERMUDA', 'Bermuda', 'BMU', 60, 1441, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (25, 'BT', 'BHUTAN', 'Bhutan', 'BTN', 64, 975, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (26, 'BO', 'BOLIVIA', 'Bolivia', 'BOL', 68, 591, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (27, 'BA', 'BOSNIA AND HERZEGOVINA', 'Bosnia and Herzegovina', 'BIH', 70, 387, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (28, 'BW', 'BOTSWANA', 'Botswana', 'BWA', 72, 267, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (29, 'BV', 'BOUVET ISLAND', 'Bouvet Island', NULL, NULL, 0, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (30, 'BR', 'BRAZIL', 'Brazil', 'BRA', 76, 55, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (31, 'IO', 'BRITISH INDIAN OCEAN TERRITORY', 'British Indian Ocean Territory', NULL, NULL, 246, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (32, 'BN', 'BRUNEI DARUSSALAM', 'Brunei Darussalam', 'BRN', 96, 673, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (33, 'BG', 'BULGARIA', 'Bulgaria', 'BGR', 100, 359, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (34, 'BF', 'BURKINA FASO', 'Burkina Faso', 'BFA', 854, 226, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (35, 'BI', 'BURUNDI', 'Burundi', 'BDI', 108, 257, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (36, 'KH', 'CAMBODIA', 'Cambodia', 'KHM', 116, 855, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (37, 'CM', 'CAMEROON', 'Cameroon', 'CMR', 120, 237, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (38, 'CA', 'CANADA', 'Canada', 'CAN', 124, 1, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (39, 'CV', 'CAPE VERDE', 'Cape Verde', 'CPV', 132, 238, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (40, 'KY', 'CAYMAN ISLANDS', 'Cayman Islands', 'CYM', 136, 1345, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (41, 'CF', 'CENTRAL AFRICAN REPUBLIC', 'Central African Republic', 'CAF', 140, 236, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (42, 'TD', 'CHAD', 'Chad', 'TCD', 148, 235, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (43, 'CL', 'CHILE', 'Chile', 'CHL', 152, 56, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (44, 'CN', 'CHINA', 'China', 'CHN', 156, 86, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (45, 'CX', 'CHRISTMAS ISLAND', 'Christmas Island', NULL, NULL, 61, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (46, 'CC', 'COCOS (KEELING) ISLANDS', 'Cocos (Keeling) Islands', NULL, NULL, 672, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (47, 'CO', 'COLOMBIA', 'Colombia', 'COL', 170, 57, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (48, 'KM', 'COMOROS', 'Comoros', 'COM', 174, 269, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (49, 'CG', 'CONGO', 'Congo', 'COG', 178, 242, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (50, 'CD', 'CONGO, THE DEMOCRATIC REPUBLIC OF THE', 'Congo, the Democratic Republic of the', 'COD', 180, 242, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (51, 'CK', 'COOK ISLANDS', 'Cook Islands', 'COK', 184, 682, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (52, 'CR', 'COSTA RICA', 'Costa Rica', 'CRI', 188, 506, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (53, 'CI', 'COTE D\'IVOIRE', 'Cote D\'Ivoire', 'CIV', 384, 225, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (54, 'HR', 'CROATIA', 'Croatia', 'HRV', 191, 385, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (55, 'CU', 'CUBA', 'Cuba', 'CUB', 192, 53, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (56, 'CY', 'CYPRUS', 'Cyprus', 'CYP', 196, 357, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (57, 'CZ', 'CZECH REPUBLIC', 'Czech Republic', 'CZE', 203, 420, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (58, 'DK', 'DENMARK', 'Denmark', 'DNK', 208, 45, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (59, 'DJ', 'DJIBOUTI', 'Djibouti', 'DJI', 262, 253, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (60, 'DM', 'DOMINICA', 'Dominica', 'DMA', 212, 1767, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (61, 'DO', 'DOMINICAN REPUBLIC', 'Dominican Republic', 'DOM', 214, 1809, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (62, 'EC', 'ECUADOR', 'Ecuador', 'ECU', 218, 593, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (63, 'EG', 'EGYPT', 'Egypt', 'EGY', 818, 20, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (64, 'SV', 'EL SALVADOR', 'El Salvador', 'SLV', 222, 503, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (65, 'GQ', 'EQUATORIAL GUINEA', 'Equatorial Guinea', 'GNQ', 226, 240, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (66, 'ER', 'ERITREA', 'Eritrea', 'ERI', 232, 291, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (67, 'EE', 'ESTONIA', 'Estonia', 'EST', 233, 372, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (68, 'ET', 'ETHIOPIA', 'Ethiopia', 'ETH', 231, 251, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (69, 'FK', 'FALKLAND ISLANDS (MALVINAS)', 'Falkland Islands (Malvinas)', 'FLK', 238, 500, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (70, 'FO', 'FAROE ISLANDS', 'Faroe Islands', 'FRO', 234, 298, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (71, 'FJ', 'FIJI', 'Fiji', 'FJI', 242, 679, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (72, 'FI', 'FINLAND', 'Finland', 'FIN', 246, 358, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (73, 'FR', 'FRANCE', 'France', 'FRA', 250, 33, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (74, 'GF', 'FRENCH GUIANA', 'French Guiana', 'GUF', 254, 594, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (75, 'PF', 'FRENCH POLYNESIA', 'French Polynesia', 'PYF', 258, 689, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (76, 'TF', 'FRENCH SOUTHERN TERRITORIES', 'French Southern Territories', NULL, NULL, 0, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (77, 'GA', 'GABON', 'Gabon', 'GAB', 266, 241, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (78, 'GM', 'GAMBIA', 'Gambia', 'GMB', 270, 220, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (79, 'GE', 'GEORGIA', 'Georgia', 'GEO', 268, 995, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (80, 'DE', 'GERMANY', 'Germany', 'DEU', 276, 49, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (81, 'GH', 'GHANA', 'Ghana', 'GHA', 288, 233, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (82, 'GI', 'GIBRALTAR', 'Gibraltar', 'GIB', 292, 350, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (83, 'GR', 'GREECE', 'Greece', 'GRC', 300, 30, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (84, 'GL', 'GREENLAND', 'Greenland', 'GRL', 304, 299, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (85, 'GD', 'GRENADA', 'Grenada', 'GRD', 308, 1473, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (86, 'GP', 'GUADELOUPE', 'Guadeloupe', 'GLP', 312, 590, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (87, 'GU', 'GUAM', 'Guam', 'GUM', 316, 1671, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (88, 'GT', 'GUATEMALA', 'Guatemala', 'GTM', 320, 502, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (89, 'GN', 'GUINEA', 'Guinea', 'GIN', 324, 224, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (90, 'GW', 'GUINEA-BISSAU', 'Guinea-Bissau', 'GNB', 624, 245, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (91, 'GY', 'GUYANA', 'Guyana', 'GUY', 328, 592, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (92, 'HT', 'HAITI', 'Haiti', 'HTI', 332, 509, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (93, 'HM', 'HEARD ISLAND AND MCDONALD ISLANDS', 'Heard Island and Mcdonald Islands', NULL, NULL, 0, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (94, 'VA', 'HOLY SEE (VATICAN CITY STATE)', 'Holy See (Vatican City State)', 'VAT', 336, 39, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (95, 'HN', 'HONDURAS', 'Honduras', 'HND', 340, 504, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (96, 'HK', 'HONG KONG', 'Hong Kong', 'HKG', 344, 852, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (97, 'HU', 'HUNGARY', 'Hungary', 'HUN', 348, 36, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (98, 'IS', 'ICELAND', 'Iceland', 'ISL', 352, 354, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (99, 'IN', 'INDIA', 'India', 'IND', 356, 91, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (100, 'ID', 'INDONESIA', 'Indonesia', 'IDN', 360, 62, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (101, 'IR', 'IRAN, ISLAMIC REPUBLIC OF', 'Iran, Islamic Republic of', 'IRN', 364, 98, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (102, 'IQ', 'IRAQ', 'Iraq', 'IRQ', 368, 964, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (103, 'IE', 'IRELAND', 'Ireland', 'IRL', 372, 353, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (104, 'IL', 'ISRAEL', 'Israel', 'ISR', 376, 972, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (105, 'IT', 'ITALY', 'Italy', 'ITA', 380, 39, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (106, 'JM', 'JAMAICA', 'Jamaica', 'JAM', 388, 1876, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (107, 'JP', 'JAPAN', 'Japan', 'JPN', 392, 81, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (108, 'JO', 'JORDAN', 'Jordan', 'JOR', 400, 962, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (109, 'KZ', 'KAZAKHSTAN', 'Kazakhstan', 'KAZ', 398, 7, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (110, 'KE', 'KENYA', 'Kenya', 'KEN', 404, 254, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (111, 'KI', 'KIRIBATI', 'Kiribati', 'KIR', 296, 686, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (112, 'KP', 'KOREA, DEMOCRATIC PEOPLE\'S REPUBLIC OF', 'Korea, Democratic People\'s Republic of', 'PRK', 408, 850, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (113, 'KR', 'KOREA, REPUBLIC OF', 'Korea, Republic of', 'KOR', 410, 82, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (114, 'KW', 'KUWAIT', 'Kuwait', 'KWT', 414, 965, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (115, 'KG', 'KYRGYZSTAN', 'Kyrgyzstan', 'KGZ', 417, 996, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (116, 'LA', 'LAO PEOPLE\'S DEMOCRATIC REPUBLIC', 'Lao People\'s Democratic Republic', 'LAO', 418, 856, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (117, 'LV', 'LATVIA', 'Latvia', 'LVA', 428, 371, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (118, 'LB', 'LEBANON', 'Lebanon', 'LBN', 422, 961, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (119, 'LS', 'LESOTHO', 'Lesotho', 'LSO', 426, 266, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (120, 'LR', 'LIBERIA', 'Liberia', 'LBR', 430, 231, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (121, 'LY', 'LIBYAN ARAB JAMAHIRIYA', 'Libyan Arab Jamahiriya', 'LBY', 434, 218, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (122, 'LI', 'LIECHTENSTEIN', 'Liechtenstein', 'LIE', 438, 423, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (123, 'LT', 'LITHUANIA', 'Lithuania', 'LTU', 440, 370, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (124, 'LU', 'LUXEMBOURG', 'Luxembourg', 'LUX', 442, 352, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (125, 'MO', 'MACAO', 'Macao', 'MAC', 446, 853, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (126, 'MK', 'MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF', 'Macedonia, the Former Yugoslav Republic of', 'MKD', 807, 389, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (127, 'MG', 'MADAGASCAR', 'Madagascar', 'MDG', 450, 261, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (128, 'MW', 'MALAWI', 'Malawi', 'MWI', 454, 265, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (129, 'MY', 'MALAYSIA', 'Malaysia', 'MYS', 458, 60, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (130, 'MV', 'MALDIVES', 'Maldives', 'MDV', 462, 960, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (131, 'ML', 'MALI', 'Mali', 'MLI', 466, 223, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (132, 'MT', 'MALTA', 'Malta', 'MLT', 470, 356, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (133, 'MH', 'MARSHALL ISLANDS', 'Marshall Islands', 'MHL', 584, 692, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (134, 'MQ', 'MARTINIQUE', 'Martinique', 'MTQ', 474, 596, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (135, 'MR', 'MAURITANIA', 'Mauritania', 'MRT', 478, 222, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (136, 'MU', 'MAURITIUS', 'Mauritius', 'MUS', 480, 230, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (137, 'YT', 'MAYOTTE', 'Mayotte', NULL, NULL, 269, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (138, 'MX', 'MEXICO', 'Mexico', 'MEX', 484, 52, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (139, 'FM', 'MICRONESIA, FEDERATED STATES OF', 'Micronesia, Federated States of', 'FSM', 583, 691, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (140, 'MD', 'MOLDOVA, REPUBLIC OF', 'Moldova, Republic of', 'MDA', 498, 373, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (141, 'MC', 'MONACO', 'Monaco', 'MCO', 492, 377, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (142, 'MN', 'MONGOLIA', 'Mongolia', 'MNG', 496, 976, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (143, 'MS', 'MONTSERRAT', 'Montserrat', 'MSR', 500, 1664, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (144, 'MA', 'MOROCCO', 'Morocco', 'MAR', 504, 212, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (145, 'MZ', 'MOZAMBIQUE', 'Mozambique', 'MOZ', 508, 258, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (146, 'MM', 'MYANMAR', 'Myanmar', 'MMR', 104, 95, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (147, 'NA', 'NAMIBIA', 'Namibia', 'NAM', 516, 264, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (148, 'NR', 'NAURU', 'Nauru', 'NRU', 520, 674, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (149, 'NP', 'NEPAL', 'Nepal', 'NPL', 524, 977, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (150, 'NL', 'NETHERLANDS', 'Netherlands', 'NLD', 528, 31, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (151, 'AN', 'NETHERLANDS ANTILLES', 'Netherlands Antilles', 'ANT', 530, 599, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (152, 'NC', 'NEW CALEDONIA', 'New Caledonia', 'NCL', 540, 687, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (153, 'NZ', 'NEW ZEALAND', 'New Zealand', 'NZL', 554, 64, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (154, 'NI', 'NICARAGUA', 'Nicaragua', 'NIC', 558, 505, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (155, 'NE', 'NIGER', 'Niger', 'NER', 562, 227, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (156, 'NG', 'NIGERIA', 'Nigeria', 'NGA', 566, 234, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (157, 'NU', 'NIUE', 'Niue', 'NIU', 570, 683, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (158, 'NF', 'NORFOLK ISLAND', 'Norfolk Island', 'NFK', 574, 672, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (159, 'MP', 'NORTHERN MARIANA ISLANDS', 'Northern Mariana Islands', 'MNP', 580, 1670, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (160, 'NO', 'NORWAY', 'Norway', 'NOR', 578, 47, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (161, 'OM', 'OMAN', 'Oman', 'OMN', 512, 968, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (162, 'PK', 'PAKISTAN', 'Pakistan', 'PAK', 586, 92, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (163, 'PW', 'PALAU', 'Palau', 'PLW', 585, 680, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (164, 'PS', 'PALESTINIAN TERRITORY, OCCUPIED', 'Palestinian Territory, Occupied', NULL, NULL, 970, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (165, 'PA', 'PANAMA', 'Panama', 'PAN', 591, 507, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (166, 'PG', 'PAPUA NEW GUINEA', 'Papua New Guinea', 'PNG', 598, 675, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (167, 'PY', 'PARAGUAY', 'Paraguay', 'PRY', 600, 595, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (168, 'PE', 'PERU', 'Peru', 'PER', 604, 51, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (169, 'PH', 'PHILIPPINES', 'Philippines', 'PHL', 608, 63, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (170, 'PN', 'PITCAIRN', 'Pitcairn', 'PCN', 612, 0, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (171, 'PL', 'POLAND', 'Poland', 'POL', 616, 48, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (172, 'PT', 'PORTUGAL', 'Portugal', 'PRT', 620, 351, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (173, 'PR', 'PUERTO RICO', 'Puerto Rico', 'PRI', 630, 1787, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (174, 'QA', 'QATAR', 'Qatar', 'QAT', 634, 974, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (175, 'RE', 'REUNION', 'Reunion', 'REU', 638, 262, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (176, 'RO', 'ROMANIA', 'Romania', 'ROM', 642, 40, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (177, 'RU', 'RUSSIAN FEDERATION', 'Russian Federation', 'RUS', 643, 70, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (178, 'RW', 'RWANDA', 'Rwanda', 'RWA', 646, 250, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (179, 'SH', 'SAINT HELENA', 'Saint Helena', 'SHN', 654, 290, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (180, 'KN', 'SAINT KITTS AND NEVIS', 'Saint Kitts and Nevis', 'KNA', 659, 1869, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (181, 'LC', 'SAINT LUCIA', 'Saint Lucia', 'LCA', 662, 1758, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (182, 'PM', 'SAINT PIERRE AND MIQUELON', 'Saint Pierre and Miquelon', 'SPM', 666, 508, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (183, 'VC', 'SAINT VINCENT AND THE GRENADINES', 'Saint Vincent and the Grenadines', 'VCT', 670, 1784, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (184, 'WS', 'SAMOA', 'Samoa', 'WSM', 882, 684, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (185, 'SM', 'SAN MARINO', 'San Marino', 'SMR', 674, 378, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (186, 'ST', 'SAO TOME AND PRINCIPE', 'Sao Tome and Principe', 'STP', 678, 239, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (187, 'SA', 'SAUDI ARABIA', 'Saudi Arabia', 'SAU', 682, 966, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (188, 'SN', 'SENEGAL', 'Senegal', 'SEN', 686, 221, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (189, 'CS', 'SERBIA AND MONTENEGRO', 'Serbia and Montenegro', NULL, NULL, 381, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (190, 'SC', 'SEYCHELLES', 'Seychelles', 'SYC', 690, 248, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (191, 'SL', 'SIERRA LEONE', 'Sierra Leone', 'SLE', 694, 232, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (192, 'SG', 'SINGAPORE', 'Singapore', 'SGP', 702, 65, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (193, 'SK', 'SLOVAKIA', 'Slovakia', 'SVK', 703, 421, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (194, 'SI', 'SLOVENIA', 'Slovenia', 'SVN', 705, 386, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (195, 'SB', 'SOLOMON ISLANDS', 'Solomon Islands', 'SLB', 90, 677, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (196, 'SO', 'SOMALIA', 'Somalia', 'SOM', 706, 252, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (197, 'ZA', 'SOUTH AFRICA', 'South Africa', 'ZAF', 710, 27, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (198, 'GS', 'SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS', 'South Georgia and the South Sandwich Islands', NULL, NULL, 0, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (199, 'ES', 'SPAIN', 'Spain', 'ESP', 724, 34, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (200, 'LK', 'SRI LANKA', 'Sri Lanka', 'LKA', 144, 94, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (201, 'SD', 'SUDAN', 'Sudan', 'SDN', 736, 249, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (202, 'SR', 'SURINAME', 'Suriname', 'SUR', 740, 597, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (203, 'SJ', 'SVALBARD AND JAN MAYEN', 'Svalbard and Jan Mayen', 'SJM', 744, 47, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (204, 'SZ', 'SWAZILAND', 'Swaziland', 'SWZ', 748, 268, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (205, 'SE', 'SWEDEN', 'Sweden', 'SWE', 752, 46, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (206, 'CH', 'SWITZERLAND', 'Switzerland', 'CHE', 756, 41, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (207, 'SY', 'SYRIAN ARAB REPUBLIC', 'Syrian Arab Republic', 'SYR', 760, 963, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (208, 'TW', 'TAIWAN, PROVINCE OF CHINA', 'Taiwan, Province of China', 'TWN', 158, 886, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (209, 'TJ', 'TAJIKISTAN', 'Tajikistan', 'TJK', 762, 992, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (210, 'TZ', 'TANZANIA, UNITED REPUBLIC OF', 'Tanzania, United Republic of', 'TZA', 834, 255, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (211, 'TH', 'THAILAND', 'Thailand', 'THA', 764, 66, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (212, 'TL', 'TIMOR-LESTE', 'Timor-Leste', NULL, NULL, 670, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (213, 'TG', 'TOGO', 'Togo', 'TGO', 768, 228, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (214, 'TK', 'TOKELAU', 'Tokelau', 'TKL', 772, 690, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (215, 'TO', 'TONGA', 'Tonga', 'TON', 776, 676, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (216, 'TT', 'TRINIDAD AND TOBAGO', 'Trinidad and Tobago', 'TTO', 780, 1868, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (217, 'TN', 'TUNISIA', 'Tunisia', 'TUN', 788, 216, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (218, 'TR', 'TURKEY', 'Turkey', 'TUR', 792, 90, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (219, 'TM', 'TURKMENISTAN', 'Turkmenistan', 'TKM', 795, 7370, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (220, 'TC', 'TURKS AND CAICOS ISLANDS', 'Turks and Caicos Islands', 'TCA', 796, 1649, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (221, 'TV', 'TUVALU', 'Tuvalu', 'TUV', 798, 688, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (222, 'UG', 'UGANDA', 'Uganda', 'UGA', 800, 256, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (223, 'UA', 'UKRAINE', 'Ukraine', 'UKR', 804, 380, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (224, 'AE', 'UNITED ARAB EMIRATES', 'United Arab Emirates', 'ARE', 784, 971, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (225, 'GB', 'UNITED KINGDOM', 'United Kingdom', 'GBR', 826, 44, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (226, 'US', 'UNITED STATES', 'United States', 'USA', 840, 1, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (227, 'UM', 'UNITED STATES MINOR OUTLYING ISLANDS', 'United States Minor Outlying Islands', NULL, NULL, 1, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (228, 'UY', 'URUGUAY', 'Uruguay', 'URY', 858, 598, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (229, 'UZ', 'UZBEKISTAN', 'Uzbekistan', 'UZB', 860, 998, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (230, 'VU', 'VANUATU', 'Vanuatu', 'VUT', 548, 678, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (231, 'VE', 'VENEZUELA', 'Venezuela', 'VEN', 862, 58, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (232, 'VN', 'VIET NAM', 'Viet Nam', 'VNM', 704, 84, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (233, 'VG', 'VIRGIN ISLANDS, BRITISH', 'Virgin Islands, British', 'VGB', 92, 1284, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (234, 'VI', 'VIRGIN ISLANDS, U.S.', 'Virgin Islands, U.s.', 'VIR', 850, 1340, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (235, 'WF', 'WALLIS AND FUTUNA', 'Wallis and Futuna', 'WLF', 876, 681, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (236, 'EH', 'WESTERN SAHARA', 'Western Sahara', 'ESH', 732, 212, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (237, 'YE', 'YEMEN', 'Yemen', 'YEM', 887, 967, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (238, 'ZM', 'ZAMBIA', 'Zambia', 'ZMB', 894, 260, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);
INSERT INTO `countries` (`country_id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (239, 'ZW', 'ZIMBABWE', 'Zimbabwe', 'ZWE', 716, 263, 1, '2021-08-04 18:28:18', '2021-08-04 18:29:26', 1);


#
# TABLE STRUCTURE FOR: currencies
#

DROP TABLE IF EXISTS `currencies`;

CREATE TABLE `currencies` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `currency` varchar(100) DEFAULT NULL,
  `code` varchar(25) DEFAULT NULL,
  `symbol` varchar(25) DEFAULT NULL,
  `thousand_separator` varchar(10) DEFAULT NULL,
  `decimal_separator` varchar(10) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`c_id`)
) ENGINE=MyISAM AUTO_INCREMENT=132 DEFAULT CHARSET=utf8;

INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (1, 'Leke', 'ALL', 'Lek', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (2, 'Dollars', 'USD', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (3, 'Afghanis', 'AF', '؋', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (4, 'Pesos', 'ARS', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (5, 'Guilders', 'AWG', 'ƒ', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (6, 'Dollars', 'AUD', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (7, 'New Manats', 'AZ', 'ман', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (8, 'Dollars', 'BSD', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (9, 'Dollars', 'BBD', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (10, 'Rubles', 'BYR', 'p.', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (11, 'Euro', 'EUR', '€', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (12, 'Dollars', 'BZD', 'BZ$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (13, 'Dollars', 'BMD', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (14, 'Bolivianos', 'BOB', '$b', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (15, 'Convertible Marka', 'BAM', 'KM', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (16, 'Pula\'s', 'BWP', 'P', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (17, 'Leva', 'BG', 'лв', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (18, 'Reais', 'BRL', 'R$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (19, 'Pounds', 'GBP', '£', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (20, 'Dollars', 'BND', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (21, 'Riels', 'KHR', '៛', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (22, 'Dollars', 'CAD', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (23, 'Dollars', 'KYD', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (24, 'Pesos', 'CLP', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (25, 'Yuan Renminbi', 'CNY', '¥', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (26, 'Pesos', 'COP', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (27, 'Colón', 'CRC', '₡', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (28, 'Kuna', 'HRK', 'kn', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (29, 'Pesos', 'CUP', '₱', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (30, 'Euro', 'EUR', '€', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (31, 'Koruny', 'CZK', 'Kč', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (32, 'Kroner', 'DKK', 'kr', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (33, 'Pesos', 'DOP ', 'RD$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (34, 'Dollars', 'XCD', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (35, 'Pounds', 'EGP', '£', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (36, 'Colones', 'SVC', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (37, 'Pounds', 'GBP', '£', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (38, 'Euro', 'EUR', '€', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (39, 'Pounds', 'FKP', '£', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (40, 'Dollars', 'FJD', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (41, 'Euro', 'EUR', '€', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (42, 'Cedis', 'GHC', '¢', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (43, 'Pounds', 'GIP', '£', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (44, 'Euro', 'EUR', '€', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (45, 'Quetzales', 'GTQ', 'Q', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (46, 'Pounds', 'GGP', '£', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (47, 'Dollars', 'GYD', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (48, 'Euro', 'EUR', '€', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (49, 'Lempiras', 'HNL', 'L', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (50, 'Dollars', 'HKD', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (51, 'Forint', 'HUF', 'Ft', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (52, 'Kronur', 'ISK', 'kr', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (53, 'Rupees', 'INR', 'Rp', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (54, 'Rupiahs', 'IDR', 'Rp', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (55, 'Rials', 'IRR', '﷼', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (56, 'Euro', 'EUR', '€', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (57, 'Pounds', 'IMP', '£', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (58, 'New Shekels', 'ILS', '₪', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (59, 'Euro', 'EUR', '€', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (60, 'Dollars', 'JMD', 'J$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (61, 'Yen', 'JPY', '¥', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (62, 'Pounds', 'JEP', '£', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (63, 'Tenge', 'KZT', 'лв', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (64, 'Won', 'KPW', '₩', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (65, 'Won', 'KRW', '₩', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (66, 'Soms', 'KGS', 'лв', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (67, 'Kips', 'LAK', '₭', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (68, 'Lati', 'LVL', 'Ls', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (69, 'Pounds', 'LBP', '£', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (70, 'Dollars', 'LRD', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (71, 'Switzerland Francs', 'CHF', 'CHF', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (72, 'Litai', 'LTL', 'Lt', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (73, 'Euro', 'EUR', '€', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (74, 'Denars', 'MKD', 'ден', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (75, 'Ringgits', 'MYR', 'RM', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (76, 'Euro', 'EUR', '€', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (77, 'Rupees', 'MUR', '₨', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (78, 'Pesos', 'MX', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (79, 'Tugriks', 'MNT', '₮', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (80, 'Meticais', 'MZ', 'MT', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (81, 'Dollars', 'NAD', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (82, 'Rupees', 'NPR', '₨', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (83, 'Guilders', 'ANG', 'ƒ', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (84, 'Euro', 'EUR', '€', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (85, 'Dollars', 'NZD', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (86, 'Cordobas', 'NIO', 'C$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (87, 'Nairas', 'NG', '₦', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (88, 'Won', 'KPW', '₩', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (89, 'Krone', 'NOK', 'kr', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (90, 'Rials', 'OMR', '﷼', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (91, 'Rupees', 'PKR', '₨', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (92, 'Balboa', 'PAB', 'B/.', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (93, 'Guarani', 'PYG', 'Gs', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (94, 'Nuevos Soles', 'PE', 'S/.', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (95, 'Pesos', 'PHP', 'Php', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (96, 'Zlotych', 'PL', 'zł', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (97, 'Rials', 'QAR', '﷼', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (98, 'New Lei', 'RO', 'lei', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (99, 'Rubles', 'RUB', 'руб', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (100, 'Pounds', 'SHP', '£', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (101, 'Riyals', 'SAR', '﷼', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (102, 'Dinars', 'RSD', 'Дин.', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (103, 'Rupees', 'SCR', '₨', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (104, 'Dollars', 'SGD', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (105, 'Euro', 'EUR', '€', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (106, 'Dollars', 'SBD', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (107, 'Shillings', 'SOS', 'S', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (108, 'Rand', 'ZAR', 'R', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (109, 'Won', 'KRW', '₩', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (110, 'Euro', 'EUR', '€', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (111, 'Rupees', 'LKR', '₨', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (112, 'Kronor', 'SEK', 'kr', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (113, 'Francs', 'CHF', 'CHF', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (114, 'Dollars', 'SRD', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (115, 'Pounds', 'SYP', '£', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (116, 'New Dollars', 'TWD', 'NT$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (117, 'Baht', 'THB', '฿', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (118, 'Dollars', 'TTD', 'TT$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (119, 'Lira', 'TRY', 'TL', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (120, 'Liras', 'TRL', '£', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (121, 'Dollars', 'TVD', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (122, 'Hryvnia', 'UAH', '₴', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (123, 'Pounds', 'GBP', '£', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (124, 'Dollars', 'USD', '$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (125, 'Pesos', 'UYU', '$U', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (126, 'Sums', 'UZS', 'лв', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (127, 'Euro', 'EUR', '€', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (128, 'Bolivares Fuertes', 'VEF', 'Bs', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (129, 'Dong', 'VND', '₫', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (130, 'Rials', 'YER', '﷼', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);
INSERT INTO `currencies` (`c_id`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (131, 'Zimbabwe Dollars', 'ZWD', 'Z$', ',', '.', 0, '2021-08-04 20:39:52', '2021-08-04 20:39:52', 1);


#
# TABLE STRUCTURE FOR: customer_invoice
#

DROP TABLE IF EXISTS `customer_invoice`;

CREATE TABLE `customer_invoice` (
  `cus_inv_id` int(11) NOT NULL AUTO_INCREMENT,
  `co_id` int(11) NOT NULL COMMENT 'PK of customer_order',
  `cus_inv_number` varchar(50) NOT NULL,
  `cus_inv_e_way_bill_no` varchar(50) NOT NULL,
  `am_id` int(11) NOT NULL COMMENT 'PK of acc_master Reference of customer_order acc_master_id',
  `transporter_id` int(11) NOT NULL COMMENT 'PK of transporter',
  `transporter_cn_number` varchar(50) NOT NULL,
  `cus_inv_number_of_cartons` int(11) NOT NULL,
  `cus_inv_total_weight` decimal(10,2) NOT NULL,
  `invoice_create_date` date NOT NULL,
  `shipment_cost` double DEFAULT NULL,
  `remarks` text NOT NULL,
  `terms` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modify_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`cus_inv_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: customer_invoice_detail
#

DROP TABLE IF EXISTS `customer_invoice_detail`;

CREATE TABLE `customer_invoice_detail` (
  `cus_inv_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `cus_inv_id` int(11) NOT NULL COMMENT 'PK of customer_invoice',
  `co_id` int(11) NOT NULL COMMENT 'Pk of customer_order',
  `cod_id` int(11) NOT NULL COMMENT 'PK of customer_order_dtl',
  `sz_id` int(11) NOT NULL COMMENT 'PK of sizes Reference of customer_order_dtl',
  `paper_gsm` int(11) NOT NULL,
  `paper_bf` int(11) NOT NULL,
  `c_id` int(11) NOT NULL COMMENT 'Pk of colors Reference of customer_order_dtl',
  `cus_order_quantity` int(11) NOT NULL COMMENT 'reference of cus_order_detail',
  `rate_per_unit` decimal(10,2) NOT NULL COMMENT 'Reference of sizes',
  `delivered_quantity` int(11) NOT NULL,
  `due_quantity` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modify_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`cus_inv_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: customer_order
#

DROP TABLE IF EXISTS `customer_order`;

CREATE TABLE `customer_order` (
  `co_id` int(11) NOT NULL AUTO_INCREMENT,
  `co_no` varchar(100) NOT NULL,
  `acc_master_id` int(11) NOT NULL,
  `buyer_reference_no` varchar(100) NOT NULL,
  `co_date` date NOT NULL,
  `co_delivery_date` date NOT NULL,
  `co_remarks` text DEFAULT NULL,
  `co_total_amount` double NOT NULL DEFAULT 0,
  `co_total_quantity` double NOT NULL DEFAULT 0,
  `img` varchar(255) DEFAULT NULL,
  `invoice_status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1=Invoice Initiate',
  `invoice_pending_status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=Not Pending, 1=Pending',
  `invoice_final_status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1=Invoice Finalize',
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modify_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`co_id`),
  KEY `acc_master_id` (`acc_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: customer_order_dtl
#

DROP TABLE IF EXISTS `customer_order_dtl`;

CREATE TABLE `customer_order_dtl` (
  `cod_id` int(11) NOT NULL AUTO_INCREMENT,
  `co_id` int(11) NOT NULL COMMENT 'customer order',
  `sz_id` int(11) NOT NULL COMMENT 'PK of sizes',
  `cus_order_quantity` double NOT NULL,
  `c_id` int(11) NOT NULL COMMENT 'PK of colors',
  `paper_gsm` int(11) DEFAULT NULL,
  `paper_bf` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modify_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`cod_id`),
  KEY `co_id` (`co_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: departments
#

DROP TABLE IF EXISTS `departments`;

CREATE TABLE `departments` (
  `d_id` int(11) NOT NULL AUTO_INCREMENT,
  `department` varchar(99) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modify_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`d_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `departments` (`d_id`, `department`, `status`, `user_id`, `create_date`, `modify_date`) VALUES (1, 'FACTORY - BAG', 1, 1, '2020-04-12 10:22:34', '2020-04-12 10:22:56');
INSERT INTO `departments` (`d_id`, `department`, `status`, `user_id`, `create_date`, `modify_date`) VALUES (3, 'OFFICE', 1, 1, '2020-04-12 10:22:46', '2020-04-12 10:22:46');


#
# TABLE STRUCTURE FOR: exportdata
#

DROP TABLE IF EXISTS `exportdata`;

CREATE TABLE `exportdata` (
  `export_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `offer_id` bigint(20) NOT NULL,
  `company` enum('FSG','SFME','Other') DEFAULT 'FSG',
  `fz_ref_no` varchar(255) DEFAULT NULL,
  `actual_sale_amt` double DEFAULT NULL,
  `admin_appr` varchar(255) DEFAULT NULL,
  `adv_amt_from_cust` double DEFAULT NULL,
  `rlink_for_bl_to_appear` varchar(255) DEFAULT NULL,
  `advise_received_from_bank` varchar(255) DEFAULT NULL,
  `adv_paid_to_vendor` double DEFAULT NULL,
  `adv_amt_to_vendor` double DEFAULT NULL,
  `adv_recd_from_cust` double DEFAULT NULL,
  `ata` date DEFAULT NULL,
  `atd` date DEFAULT NULL,
  `besc_applied` enum('Yes','No','NA') DEFAULT NULL,
  `bl_no` varchar(255) DEFAULT NULL,
  `corrc_appr_by_cust` enum('Yes','No','N/A') DEFAULT NULL,
  `corrc_appr_cust_date` date DEFAULT NULL,
  `corrc_appr_to_vend` enum('Yes','No','N/A') DEFAULT NULL,
  `correc_appr_vend_date` date DEFAULT NULL,
  `cr_note_to_cust` varchar(255) DEFAULT NULL,
  `cr_note_to_supp` varchar(255) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `cust_po_no` varchar(255) DEFAULT NULL,
  `cust_pi_conf` varchar(255) DEFAULT NULL,
  `dbt_note_to_cust` varchar(255) DEFAULT NULL,
  `dbt_note_to_supp` varchar(255) DEFAULT NULL,
  `dbt_note_cust_comm` varchar(255) DEFAULT NULL,
  `docs_sent_to_sgs_for_clean_cer` varchar(255) DEFAULT NULL COMMENT '(CEAN CERT)',
  `draft_docs_recd` enum('Yes','No','N/A') DEFAULT NULL,
  `draft_docs_recd_date` date DEFAULT NULL,
  `draft_docs_sent` enum('Yes','No','N/A') DEFAULT NULL,
  `draft_docs_sent_date` date DEFAULT NULL,
  `eta` date DEFAULT NULL,
  `etd` date DEFAULT NULL,
  `export_appr` varchar(255) DEFAULT NULL,
  `final_docs_submitted` varchar(255) DEFAULT NULL,
  `final_copy_cust` enum('Yes','No','N/A') DEFAULT NULL,
  `final_copy_cust_date` date DEFAULT NULL,
  `final_copy_vend` enum('Yes','No','N/A') DEFAULT NULL,
  `final_copy_vend_date` date DEFAULT NULL,
  `finance_appr` varchar(255) DEFAULT NULL,
  `freight_agent` varchar(255) DEFAULT NULL,
  `freight_invoice_no` varchar(255) DEFAULT NULL,
  `frieght` double DEFAULT NULL,
  `lc_amt_recd` varchar(255) DEFAULT NULL,
  `lc_amd_reqd` varchar(255) DEFAULT NULL,
  `lc_amd_transfer` varchar(255) DEFAULT NULL,
  `lc_critical_condition` varchar(255) DEFAULT NULL,
  `lc_doc_submission_date` date DEFAULT NULL,
  `lc_expiry_date` date DEFAULT NULL,
  `lc_recd_cust` enum('Yes','No','N/A') DEFAULT NULL,
  `insp_license_number` varchar(255) DEFAULT NULL,
  `insurance` double DEFAULT NULL,
  `label_appr_cust` varchar(255) DEFAULT NULL,
  `label_appr_vend` varchar(255) DEFAULT NULL,
  `last_edited_by` varchar(100) DEFAULT NULL,
  `last_remark` text DEFAULT NULL,
  `last_updated_at` datetime DEFAULT NULL,
  `latest_dos` date DEFAULT NULL,
  `mrktng_appr` varchar(255) DEFAULT NULL,
  `org_docs_cust` enum('Yes','No','N/A') DEFAULT NULL,
  `org_docs_cust_date` date DEFAULT NULL,
  `org_docs_vend` enum('Yes','No','N/A') DEFAULT NULL,
  `org_docs_vend_date` date DEFAULT NULL,
  `sale_contract` varchar(255) DEFAULT NULL,
  `sc_qty` varchar(20) DEFAULT NULL,
  `pi_sales_amt` double DEFAULT NULL,
  `po_purch_amt` double DEFAULT NULL,
  `qty_loaded` int(11) DEFAULT NULL,
  `resource_appr` varchar(255) DEFAULT NULL,
  `remark_for_outstation` text DEFAULT NULL,
  `remark_from_outstation` text DEFAULT NULL,
  `remark_admin_rp` text DEFAULT NULL,
  `remark_finan_rp` text DEFAULT NULL,
  `remark_purch_rp` text DEFAULT NULL,
  `remark_sales_rp` text DEFAULT NULL,
  `think` varchar(255) DEFAULT NULL,
  `3rd_insp_upload` date DEFAULT NULL,
  `vend_pi` varchar(255) DEFAULT NULL,
  `vend_inv_amt` double DEFAULT NULL,
  `vend_po_conf` varchar(255) DEFAULT NULL,
  `actual_sales_amt_currency` int(11) DEFAULT NULL,
  `adv_amt_cust_currency` int(20) DEFAULT NULL,
  `adv_amt_vend_currency` int(20) DEFAULT NULL,
  `adv_paid_vend_currency` int(20) DEFAULT NULL,
  `adv_recd_from_cust_currency` int(20) DEFAULT NULL,
  `country_id` int(20) DEFAULT NULL,
  `cust_inco_id` int(20) DEFAULT NULL,
  `frieght_currency` int(20) DEFAULT NULL,
  `insurance_currency` int(20) DEFAULT NULL,
  `pymt_terms_cust_id` varchar(255) DEFAULT NULL,
  `pi_sales_amt_currency` int(20) DEFAULT NULL,
  `po_purch_amt_currency` int(20) DEFAULT NULL,
  `responsible_purchase_id` int(20) DEFAULT NULL,
  `responsible_sale_id` int(20) DEFAULT NULL,
  `responsible_logistics_id` int(20) DEFAULT NULL,
  `vend_inv_amt_currency` int(20) DEFAULT NULL,
  `dox_remark` text DEFAULT NULL,
  `shipt_remark` text DEFAULT NULL,
  `payment_remark` text DEFAULT NULL,
  `collect_remark` text DEFAULT NULL,
  `general_remark` text DEFAULT NULL,
  `insp_sr_applied` enum('Yes','No','N/A') DEFAULT NULL,
  `insp_sr_number` varchar(100) DEFAULT NULL,
  `sr_date` date DEFAULT NULL,
  `insp_aoc_coc` varchar(255) DEFAULT NULL,
  `aoc_coc_date` date DEFAULT NULL,
  `dayes_delayed` varchar(255) DEFAULT NULL,
  `customer` int(11) DEFAULT NULL,
  `rem_dayes_for_shipt` varchar(255) DEFAULT NULL,
  `besc_others_no` varchar(255) DEFAULT NULL,
  `besc_cert` enum('Yes','No','NA') DEFAULT NULL,
  `check_list_applied` varchar(255) DEFAULT NULL,
  `doc_courier_no_incoming` varchar(255) DEFAULT NULL,
  `doc_courier_no_outgoing` varchar(255) DEFAULT NULL,
  `container_discharge_date` date DEFAULT NULL,
  `final_clearance_date` date DEFAULT NULL,
  `doc_recd` varchar(255) DEFAULT NULL COMMENT '(Email/FAX)',
  `accounts_appr` varchar(255) DEFAULT NULL,
  `latest_doc_lc` date DEFAULT NULL,
  `payment_by_supplier_comm` varchar(255) DEFAULT NULL,
  `invoice_file` varchar(255) DEFAULT NULL,
  `packing_list_file` varchar(255) DEFAULT NULL,
  `health_cer_file` varchar(255) DEFAULT NULL,
  `cert_of_origin` varchar(255) DEFAULT NULL,
  `bill_of_leading` varchar(255) DEFAULT NULL,
  `sgs_cert` varchar(255) DEFAULT NULL,
  `feri_cert` varchar(255) DEFAULT NULL,
  `insp_report_file` varchar(255) DEFAULT NULL,
  `besc_cert_file` varchar(255) DEFAULT NULL,
  `appr_label_file` varchar(255) DEFAULT NULL,
  `confirmed_po_file` varchar(255) DEFAULT NULL,
  `confirmed_pi_file` varchar(255) DEFAULT NULL,
  `micrbiology_report_file` varchar(255) DEFAULT NULL,
  `other_export_report_file` varchar(255) DEFAULT NULL,
  `any_other_quality_report_file` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`export_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `exportdata` (`export_id`, `offer_id`, `company`, `fz_ref_no`, `actual_sale_amt`, `admin_appr`, `adv_amt_from_cust`, `rlink_for_bl_to_appear`, `advise_received_from_bank`, `adv_paid_to_vendor`, `adv_amt_to_vendor`, `adv_recd_from_cust`, `ata`, `atd`, `besc_applied`, `bl_no`, `corrc_appr_by_cust`, `corrc_appr_cust_date`, `corrc_appr_to_vend`, `correc_appr_vend_date`, `cr_note_to_cust`, `cr_note_to_supp`, `created_by`, `created_at`, `cust_po_no`, `cust_pi_conf`, `dbt_note_to_cust`, `dbt_note_to_supp`, `dbt_note_cust_comm`, `docs_sent_to_sgs_for_clean_cer`, `draft_docs_recd`, `draft_docs_recd_date`, `draft_docs_sent`, `draft_docs_sent_date`, `eta`, `etd`, `export_appr`, `final_docs_submitted`, `final_copy_cust`, `final_copy_cust_date`, `final_copy_vend`, `final_copy_vend_date`, `finance_appr`, `freight_agent`, `freight_invoice_no`, `frieght`, `lc_amt_recd`, `lc_amd_reqd`, `lc_amd_transfer`, `lc_critical_condition`, `lc_doc_submission_date`, `lc_expiry_date`, `lc_recd_cust`, `insp_license_number`, `insurance`, `label_appr_cust`, `label_appr_vend`, `last_edited_by`, `last_remark`, `last_updated_at`, `latest_dos`, `mrktng_appr`, `org_docs_cust`, `org_docs_cust_date`, `org_docs_vend`, `org_docs_vend_date`, `sale_contract`, `sc_qty`, `pi_sales_amt`, `po_purch_amt`, `qty_loaded`, `resource_appr`, `remark_for_outstation`, `remark_from_outstation`, `remark_admin_rp`, `remark_finan_rp`, `remark_purch_rp`, `remark_sales_rp`, `think`, `3rd_insp_upload`, `vend_pi`, `vend_inv_amt`, `vend_po_conf`, `actual_sales_amt_currency`, `adv_amt_cust_currency`, `adv_amt_vend_currency`, `adv_paid_vend_currency`, `adv_recd_from_cust_currency`, `country_id`, `cust_inco_id`, `frieght_currency`, `insurance_currency`, `pymt_terms_cust_id`, `pi_sales_amt_currency`, `po_purch_amt_currency`, `responsible_purchase_id`, `responsible_sale_id`, `responsible_logistics_id`, `vend_inv_amt_currency`, `dox_remark`, `shipt_remark`, `payment_remark`, `collect_remark`, `general_remark`, `insp_sr_applied`, `insp_sr_number`, `sr_date`, `insp_aoc_coc`, `aoc_coc_date`, `dayes_delayed`, `customer`, `rem_dayes_for_shipt`, `besc_others_no`, `besc_cert`, `check_list_applied`, `doc_courier_no_incoming`, `doc_courier_no_outgoing`, `container_discharge_date`, `final_clearance_date`, `doc_recd`, `accounts_appr`, `latest_doc_lc`, `payment_by_supplier_comm`, `invoice_file`, `packing_list_file`, `health_cer_file`, `cert_of_origin`, `bill_of_leading`, `sgs_cert`, `feri_cert`, `insp_report_file`, `besc_cert_file`, `appr_label_file`, `confirmed_po_file`, `confirmed_pi_file`, `micrbiology_report_file`, `other_export_report_file`, `any_other_quality_report_file`) VALUES ('4', '215', 'SFME', 'FZ-958', '38700', '', '0', '', '', '0', '0', '0', '2022-02-06', '2022-01-13', '', 'CLC0117947', 'N/A', '0000-00-00', 'Yes', '2022-01-18', '', '', '52', '2022-03-26 11:22:33', '', 'Received', '', '', '', '', 'Yes', '2022-01-16', 'Yes', '2022-01-16', '2022-02-06', '2022-01-13', '', '', 'Yes', '2022-02-22', 'Yes', '2022-02-22', '', '', '', '0', '', '', '', '', '0000-00-00', '0000-00-00', '', 'NA', '0', 'Confirmed', 'Confirmed', NULL, 'Shipment Closed', NULL, '2022-01-10', '', 'Yes', '2022-02-25', 'Yes', '2022-02-25', 'FZ/950/Dec/2021', '27', '38700', '37300', 27, '', '', '', '', '', '', '', '', '0000-00-00', '3734-FSG-2022', '37300', 'Received', 2, 2, 2, 2, 2, NULL, 3, 2, 2, '60 Days from BL Date', 6, 2, 0, 1, 2, 2, 'BL Telex Released', 'Shipment Cleared in Destination', 'Vendor Fully Paid', 'Payment received from Congelcam', '', 'N/A', '', '0000-00-00', '', '0000-00-00', '72 days ', 52, '72 days ', '', '', 'YES', '', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', '', '361401__Sales_Invoice.pdf', '596602__Packing_List.pdf', '852303__Health_Certificate.pdf', '310704__Certificate_of_Origin.pdf', '447805__Bill_of_Lading.pdf', NULL, NULL, NULL, NULL, NULL, '8378Purchase_Order.pdf', '7714Proforma_Invoice.pdf', NULL, NULL, NULL);
INSERT INTO `exportdata` (`export_id`, `offer_id`, `company`, `fz_ref_no`, `actual_sale_amt`, `admin_appr`, `adv_amt_from_cust`, `rlink_for_bl_to_appear`, `advise_received_from_bank`, `adv_paid_to_vendor`, `adv_amt_to_vendor`, `adv_recd_from_cust`, `ata`, `atd`, `besc_applied`, `bl_no`, `corrc_appr_by_cust`, `corrc_appr_cust_date`, `corrc_appr_to_vend`, `correc_appr_vend_date`, `cr_note_to_cust`, `cr_note_to_supp`, `created_by`, `created_at`, `cust_po_no`, `cust_pi_conf`, `dbt_note_to_cust`, `dbt_note_to_supp`, `dbt_note_cust_comm`, `docs_sent_to_sgs_for_clean_cer`, `draft_docs_recd`, `draft_docs_recd_date`, `draft_docs_sent`, `draft_docs_sent_date`, `eta`, `etd`, `export_appr`, `final_docs_submitted`, `final_copy_cust`, `final_copy_cust_date`, `final_copy_vend`, `final_copy_vend_date`, `finance_appr`, `freight_agent`, `freight_invoice_no`, `frieght`, `lc_amt_recd`, `lc_amd_reqd`, `lc_amd_transfer`, `lc_critical_condition`, `lc_doc_submission_date`, `lc_expiry_date`, `lc_recd_cust`, `insp_license_number`, `insurance`, `label_appr_cust`, `label_appr_vend`, `last_edited_by`, `last_remark`, `last_updated_at`, `latest_dos`, `mrktng_appr`, `org_docs_cust`, `org_docs_cust_date`, `org_docs_vend`, `org_docs_vend_date`, `sale_contract`, `sc_qty`, `pi_sales_amt`, `po_purch_amt`, `qty_loaded`, `resource_appr`, `remark_for_outstation`, `remark_from_outstation`, `remark_admin_rp`, `remark_finan_rp`, `remark_purch_rp`, `remark_sales_rp`, `think`, `3rd_insp_upload`, `vend_pi`, `vend_inv_amt`, `vend_po_conf`, `actual_sales_amt_currency`, `adv_amt_cust_currency`, `adv_amt_vend_currency`, `adv_paid_vend_currency`, `adv_recd_from_cust_currency`, `country_id`, `cust_inco_id`, `frieght_currency`, `insurance_currency`, `pymt_terms_cust_id`, `pi_sales_amt_currency`, `po_purch_amt_currency`, `responsible_purchase_id`, `responsible_sale_id`, `responsible_logistics_id`, `vend_inv_amt_currency`, `dox_remark`, `shipt_remark`, `payment_remark`, `collect_remark`, `general_remark`, `insp_sr_applied`, `insp_sr_number`, `sr_date`, `insp_aoc_coc`, `aoc_coc_date`, `dayes_delayed`, `customer`, `rem_dayes_for_shipt`, `besc_others_no`, `besc_cert`, `check_list_applied`, `doc_courier_no_incoming`, `doc_courier_no_outgoing`, `container_discharge_date`, `final_clearance_date`, `doc_recd`, `accounts_appr`, `latest_doc_lc`, `payment_by_supplier_comm`, `invoice_file`, `packing_list_file`, `health_cer_file`, `cert_of_origin`, `bill_of_leading`, `sgs_cert`, `feri_cert`, `insp_report_file`, `besc_cert_file`, `appr_label_file`, `confirmed_po_file`, `confirmed_pi_file`, `micrbiology_report_file`, `other_export_report_file`, `any_other_quality_report_file`) VALUES ('5', '215', 'FSG', 'FZ/953/JAN/2022', '36500', '', '0', '', '', '0', '0', '0', '2022-02-05', '2022-01-05', '', 'HOD2110896', '', '0000-00-00', '', '0000-00-00', '', '', '52', '2022-03-26 11:34:01', '', '', '11', '33', '', '', '', '0000-00-00', '', '0000-00-00', '2022-02-05', '2022-01-05', '', '', '', '0000-00-00', '', '0000-00-00', '', '', '', '0', '', '', '', '', '0000-00-00', '0000-00-00', '', '', '0', '', '', '52', 'Shipment Closed', '2022-04-04 11:30:09', '2022-01-03', '', '', '0000-00-00', '', '0000-00-00', 'FZ/953/JAN/2022', '777', '36500', '35000', 27, '', '', '', '', '', '', '', '', '0000-00-00', '', '35000', '', 2, 0, 0, 0, 0, NULL, 3, 0, 0, '', 2, 2, 2, 1, 2, 2, 'BL Telex Released', 'Shipment Arrived', 'Vendor Fully paid', 'Payment Pending', '', '', '', '0000-00-00', '', '0000-00-00', '89 days ', 38, '89 days ', '', '', '', '', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', '', '7901pic2.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `exportdata` (`export_id`, `offer_id`, `company`, `fz_ref_no`, `actual_sale_amt`, `admin_appr`, `adv_amt_from_cust`, `rlink_for_bl_to_appear`, `advise_received_from_bank`, `adv_paid_to_vendor`, `adv_amt_to_vendor`, `adv_recd_from_cust`, `ata`, `atd`, `besc_applied`, `bl_no`, `corrc_appr_by_cust`, `corrc_appr_cust_date`, `corrc_appr_to_vend`, `correc_appr_vend_date`, `cr_note_to_cust`, `cr_note_to_supp`, `created_by`, `created_at`, `cust_po_no`, `cust_pi_conf`, `dbt_note_to_cust`, `dbt_note_to_supp`, `dbt_note_cust_comm`, `docs_sent_to_sgs_for_clean_cer`, `draft_docs_recd`, `draft_docs_recd_date`, `draft_docs_sent`, `draft_docs_sent_date`, `eta`, `etd`, `export_appr`, `final_docs_submitted`, `final_copy_cust`, `final_copy_cust_date`, `final_copy_vend`, `final_copy_vend_date`, `finance_appr`, `freight_agent`, `freight_invoice_no`, `frieght`, `lc_amt_recd`, `lc_amd_reqd`, `lc_amd_transfer`, `lc_critical_condition`, `lc_doc_submission_date`, `lc_expiry_date`, `lc_recd_cust`, `insp_license_number`, `insurance`, `label_appr_cust`, `label_appr_vend`, `last_edited_by`, `last_remark`, `last_updated_at`, `latest_dos`, `mrktng_appr`, `org_docs_cust`, `org_docs_cust_date`, `org_docs_vend`, `org_docs_vend_date`, `sale_contract`, `sc_qty`, `pi_sales_amt`, `po_purch_amt`, `qty_loaded`, `resource_appr`, `remark_for_outstation`, `remark_from_outstation`, `remark_admin_rp`, `remark_finan_rp`, `remark_purch_rp`, `remark_sales_rp`, `think`, `3rd_insp_upload`, `vend_pi`, `vend_inv_amt`, `vend_po_conf`, `actual_sales_amt_currency`, `adv_amt_cust_currency`, `adv_amt_vend_currency`, `adv_paid_vend_currency`, `adv_recd_from_cust_currency`, `country_id`, `cust_inco_id`, `frieght_currency`, `insurance_currency`, `pymt_terms_cust_id`, `pi_sales_amt_currency`, `po_purch_amt_currency`, `responsible_purchase_id`, `responsible_sale_id`, `responsible_logistics_id`, `vend_inv_amt_currency`, `dox_remark`, `shipt_remark`, `payment_remark`, `collect_remark`, `general_remark`, `insp_sr_applied`, `insp_sr_number`, `sr_date`, `insp_aoc_coc`, `aoc_coc_date`, `dayes_delayed`, `customer`, `rem_dayes_for_shipt`, `besc_others_no`, `besc_cert`, `check_list_applied`, `doc_courier_no_incoming`, `doc_courier_no_outgoing`, `container_discharge_date`, `final_clearance_date`, `doc_recd`, `accounts_appr`, `latest_doc_lc`, `payment_by_supplier_comm`, `invoice_file`, `packing_list_file`, `health_cer_file`, `cert_of_origin`, `bill_of_leading`, `sgs_cert`, `feri_cert`, `insp_report_file`, `besc_cert_file`, `appr_label_file`, `confirmed_po_file`, `confirmed_pi_file`, `micrbiology_report_file`, `other_export_report_file`, `any_other_quality_report_file`) VALUES ('6', '221', 'SFME', 'FZ-911', '0', '', '0', '', '', '0', '0', '0', '0000-00-00', '0000-00-00', '', '', '', '0000-00-00', '', '0000-00-00', '', '', '52', '2022-03-30 14:06:54', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '', '', '', '0000-00-00', '', '0000-00-00', '', '', '', '0', '', '', '', '', '0000-00-00', '0000-00-00', '', '', '0', '', '', NULL, '', NULL, '0000-00-00', '', '', '0000-00-00', '', '0000-00-00', '', '3', '0', '0', 0, '', '', '', '', '', '', '', '', '0000-00-00', '', '0', '', 0, 0, 0, 0, 0, NULL, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '0 days ', 0, '0 days ', '', '', '', '', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: final_mail_send
#

DROP TABLE IF EXISTS `final_mail_send`;

CREATE TABLE `final_mail_send` (
  `final_mail_send_id` int(11) NOT NULL AUTO_INCREMENT,
  `final_mail_send_status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1 for mail send and 0 for mail not send',
  `offer_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`final_mail_send_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4;

INSERT INTO `final_mail_send` (`final_mail_send_id`, `final_mail_send_status`, `offer_id`, `created_at`, `updated_at`) VALUES (28, 1, 194, '2022-03-16 12:29:39', '2022-03-16 12:29:39');
INSERT INTO `final_mail_send` (`final_mail_send_id`, `final_mail_send_status`, `offer_id`, `created_at`, `updated_at`) VALUES (29, 1, 194, '2022-03-16 12:37:40', '2022-03-16 12:37:40');
INSERT INTO `final_mail_send` (`final_mail_send_id`, `final_mail_send_status`, `offer_id`, `created_at`, `updated_at`) VALUES (30, 0, 214, '2022-03-26 01:41:07', '2022-03-26 01:41:07');
INSERT INTO `final_mail_send` (`final_mail_send_id`, `final_mail_send_status`, `offer_id`, `created_at`, `updated_at`) VALUES (31, 0, 214, '2022-03-26 01:41:31', '2022-03-26 01:41:31');
INSERT INTO `final_mail_send` (`final_mail_send_id`, `final_mail_send_status`, `offer_id`, `created_at`, `updated_at`) VALUES (32, 0, 215, '2022-03-26 10:51:04', '2022-03-26 10:51:04');
INSERT INTO `final_mail_send` (`final_mail_send_id`, `final_mail_send_status`, `offer_id`, `created_at`, `updated_at`) VALUES (33, 1, 215, '2022-03-28 14:51:57', '2022-03-28 14:51:57');
INSERT INTO `final_mail_send` (`final_mail_send_id`, `final_mail_send_status`, `offer_id`, `created_at`, `updated_at`) VALUES (34, 1, 221, '2022-04-04 13:49:38', '2022-04-04 13:49:38');
INSERT INTO `final_mail_send` (`final_mail_send_id`, `final_mail_send_status`, `offer_id`, `created_at`, `updated_at`) VALUES (35, 0, 221, '2022-04-04 13:54:50', '2022-04-04 13:54:50');
INSERT INTO `final_mail_send` (`final_mail_send_id`, `final_mail_send_status`, `offer_id`, `created_at`, `updated_at`) VALUES (36, 0, 221, '2022-04-04 13:59:34', '2022-04-04 13:59:34');
INSERT INTO `final_mail_send` (`final_mail_send_id`, `final_mail_send_status`, `offer_id`, `created_at`, `updated_at`) VALUES (37, 0, 221, '2022-04-04 13:59:38', '2022-04-04 13:59:38');
INSERT INTO `final_mail_send` (`final_mail_send_id`, `final_mail_send_status`, `offer_id`, `created_at`, `updated_at`) VALUES (38, 0, 221, '2022-04-04 14:00:17', '2022-04-04 14:00:17');
INSERT INTO `final_mail_send` (`final_mail_send_id`, `final_mail_send_status`, `offer_id`, `created_at`, `updated_at`) VALUES (39, 1, 221, '2022-04-04 15:00:00', '2022-04-04 15:00:00');
INSERT INTO `final_mail_send` (`final_mail_send_id`, `final_mail_send_status`, `offer_id`, `created_at`, `updated_at`) VALUES (40, 1, 221, '2022-04-04 17:02:19', '2022-04-04 17:02:19');


#
# TABLE STRUCTURE FOR: freezing
#

DROP TABLE IF EXISTS `freezing`;

CREATE TABLE `freezing` (
  `ft_id` int(11) NOT NULL AUTO_INCREMENT,
  `freezing_category` enum('Type','Method') NOT NULL,
  `freezing_type` varchar(150) NOT NULL,
  `comment` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`ft_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf16;

INSERT INTO `freezing` (`ft_id`, `freezing_category`, `freezing_type`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (1, 'Type', 'Sea Frozen', '', 0, '2021-08-04 18:46:03', '2021-08-12 16:05:31', 1);
INSERT INTO `freezing` (`ft_id`, `freezing_category`, `freezing_type`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (2, 'Type', 'Land Frozen', '', 0, '2021-08-12 16:04:46', '2021-08-12 16:04:46', 1);
INSERT INTO `freezing` (`ft_id`, `freezing_category`, `freezing_type`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (3, 'Method', 'IQF', '', 0, '2021-08-12 16:05:19', '2021-08-17 15:54:54', 1);
INSERT INTO `freezing` (`ft_id`, `freezing_category`, `freezing_type`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (4, 'Method', 'IWP', '', 0, '2021-08-12 16:05:42', '2021-08-17 15:55:04', 1);
INSERT INTO `freezing` (`ft_id`, `freezing_category`, `freezing_type`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (5, 'Method', 'Blast Frozen', '', 0, '2021-08-12 16:05:57', '2021-08-17 15:55:15', 1);


#
# TABLE STRUCTURE FOR: freight_master
#

DROP TABLE IF EXISTS `freight_master`;

CREATE TABLE `freight_master` (
  `fm_id` int(11) NOT NULL AUTO_INCREMENT,
  `source_country` int(11) NOT NULL,
  `destination_country` int(11) NOT NULL,
  `container_size` enum('20 feeter','40 feeter') NOT NULL,
  `freight_amount` double NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`fm_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf16;

INSERT INTO `freight_master` (`fm_id`, `source_country`, `destination_country`, `container_size`, `freight_amount`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (1, 6, 4, '20 feeter', '50', 0, '2021-09-18 23:40:16', '2021-09-18 23:40:16', 1);


#
# TABLE STRUCTURE FOR: glazing
#

DROP TABLE IF EXISTS `glazing`;

CREATE TABLE `glazing` (
  `gl_id` int(11) NOT NULL AUTO_INCREMENT,
  `glazing` varchar(120) NOT NULL,
  `information` varchar(300) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`gl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf16;

INSERT INTO `glazing` (`gl_id`, `glazing`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (1, '0% (Net Weight)', '', 1, '2021-08-04 19:05:15', '2021-08-12 16:10:59', 1);
INSERT INTO `glazing` (`gl_id`, `glazing`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (2, '5%', '', 0, '2021-08-12 16:11:13', '2021-08-12 16:11:13', 1);
INSERT INTO `glazing` (`gl_id`, `glazing`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (3, '10%', '', 0, '2021-08-12 16:11:22', '2021-08-12 16:11:22', 1);
INSERT INTO `glazing` (`gl_id`, `glazing`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (4, '15%', '', 0, '2021-08-12 16:11:29', '2021-08-12 16:11:29', 1);
INSERT INTO `glazing` (`gl_id`, `glazing`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (5, '20%', '', 0, '2021-08-12 16:11:37', '2021-08-12 16:11:37', 1);
INSERT INTO `glazing` (`gl_id`, `glazing`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (6, '25%', '', 0, '2021-09-09 15:30:52', '2021-09-09 15:30:52', 1);
INSERT INTO `glazing` (`gl_id`, `glazing`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (7, '30%', '', 0, '2021-09-09 15:30:58', '2021-09-09 15:30:58', 1);
INSERT INTO `glazing` (`gl_id`, `glazing`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (8, '35%', '', 0, '2021-09-09 15:31:03', '2021-09-09 15:31:03', 1);
INSERT INTO `glazing` (`gl_id`, `glazing`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (9, '40%', '', 0, '2021-09-09 15:31:09', '2021-09-09 15:31:09', 1);
INSERT INTO `glazing` (`gl_id`, `glazing`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (10, '45%', '', 0, '2021-09-09 15:31:13', '2021-09-09 15:31:13', 1);
INSERT INTO `glazing` (`gl_id`, `glazing`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (11, '50%', '', 0, '2021-09-09 15:32:42', '2021-09-09 15:32:42', 1);


#
# TABLE STRUCTURE FOR: incoterms
#

DROP TABLE IF EXISTS `incoterms`;

CREATE TABLE `incoterms` (
  `it_id` int(11) NOT NULL AUTO_INCREMENT,
  `incoterm` varchar(120) NOT NULL,
  `information` varchar(300) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT 1,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`it_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf16;

INSERT INTO `incoterms` (`it_id`, `incoterm`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (1, 'FOB', '', 1, '2021-08-04 19:05:15', '2021-08-04 23:33:59', 1);
INSERT INTO `incoterms` (`it_id`, `incoterm`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (2, 'CNF', '', 1, '2021-08-04 23:33:35', '2021-08-04 23:33:35', 1);
INSERT INTO `incoterms` (`it_id`, `incoterm`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (3, 'CIF', '', 1, '2021-08-04 23:33:42', '2021-08-04 23:33:42', 1);
INSERT INTO `incoterms` (`it_id`, `incoterm`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (4, 'Ex-Works', '', 1, '2021-08-04 23:33:51', '2021-08-04 23:33:51', 1);


#
# TABLE STRUCTURE FOR: line_items
#

DROP TABLE IF EXISTS `line_items`;

CREATE TABLE `line_items` (
  `li_id` int(11) NOT NULL AUTO_INCREMENT,
  `line_item_category` enum('Line Item','First Level','Second Level','Third Level') NOT NULL,
  `line_item_name` varchar(222) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`li_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf16;

INSERT INTO `line_items` (`li_id`, `line_item_category`, `line_item_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (1, 'Line Item', 'Ex-Works (Quoted by Vendor)', 0, '2021-08-16 09:39:21', '2021-08-16 09:39:21', 1);
INSERT INTO `line_items` (`li_id`, `line_item_category`, `line_item_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (2, 'Line Item', 'Inland / Domestic Cost', 0, '2021-08-16 09:39:36', '2021-08-16 09:39:36', 1);
INSERT INTO `line_items` (`li_id`, `line_item_category`, `line_item_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (3, 'Line Item', 'Inspection / Docs Cost', 0, '2021-08-16 09:39:47', '2021-08-16 09:39:47', 1);
INSERT INTO `line_items` (`li_id`, `line_item_category`, `line_item_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (4, 'Line Item', 'FOB (Quoted by Vendor)', 0, '2021-08-16 09:40:17', '2021-08-16 09:40:17', 1);
INSERT INTO `line_items` (`li_id`, `line_item_category`, `line_item_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (5, 'Line Item', 'Ocean / Air- Freight', 0, '2021-08-16 09:40:40', '2021-08-16 09:40:40', 1);
INSERT INTO `line_items` (`li_id`, `line_item_category`, `line_item_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (6, 'Line Item', 'Destination Charges', 0, '2021-08-16 09:40:49', '2021-08-16 09:40:49', 1);
INSERT INTO `line_items` (`li_id`, `line_item_category`, `line_item_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (7, 'Line Item', 'CFR (Quoted by Vendor)', 0, '2021-08-16 09:41:00', '2021-08-16 09:41:00', 1);
INSERT INTO `line_items` (`li_id`, `line_item_category`, `line_item_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (8, 'Line Item', 'Insurance', 0, '2021-08-16 09:41:13', '2021-08-16 09:41:13', 1);
INSERT INTO `line_items` (`li_id`, `line_item_category`, `line_item_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (9, 'Line Item', 'CIF (Quoted by Vendor)', 0, '2021-08-16 09:41:21', '2021-08-16 09:41:21', 1);
INSERT INTO `line_items` (`li_id`, `line_item_category`, `line_item_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (10, 'First Level', 'FOB Cost', 0, '2021-08-16 09:42:18', '2021-08-16 09:42:18', 1);
INSERT INTO `line_items` (`li_id`, `line_item_category`, `line_item_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (11, 'First Level', 'CFR Cost', 0, '2021-08-16 09:42:27', '2021-08-16 09:42:27', 1);
INSERT INTO `line_items` (`li_id`, `line_item_category`, `line_item_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (12, 'First Level', 'CIF Cost', 0, '2021-08-16 09:42:36', '2021-08-16 09:42:36', 1);
INSERT INTO `line_items` (`li_id`, `line_item_category`, `line_item_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (13, 'First Level', 'Final Cost', 0, '2021-08-16 09:42:44', '2021-08-16 09:42:44', 1);
INSERT INTO `line_items` (`li_id`, `line_item_category`, `line_item_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (14, 'Second Level', 'MARGIN (Value / Percentage)', 0, '2021-08-16 09:42:53', '2021-08-16 09:42:53', 1);
INSERT INTO `line_items` (`li_id`, `line_item_category`, `line_item_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (15, 'Third Level', 'Commission ', 0, '2021-09-10 17:02:05', '2021-09-10 17:02:05', 1);


#
# TABLE STRUCTURE FOR: menu_setting
#

DROP TABLE IF EXISTS `menu_setting`;

CREATE TABLE `menu_setting` (
  `menu_setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(20) NOT NULL,
  `users_id` varchar(200) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modify_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`menu_setting_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `menu_setting` (`menu_setting_id`, `menu_name`, `users_id`, `user_id`, `create_date`, `modify_date`) VALUES (1, 'Colours', '1,2', 1, '2021-03-30 23:36:28', '2021-03-30 23:47:43');


#
# TABLE STRUCTURE FOR: offer_comments
#

DROP TABLE IF EXISTS `offer_comments`;

CREATE TABLE `offer_comments` (
  `oc_id` int(11) NOT NULL AUTO_INCREMENT,
  `offer_id` int(11) NOT NULL,
  `resource_id` int(11) NOT NULL COMMENT 'resource and marketing both',
  `comment` text NOT NULL,
  `action` enum('Postponed','Solved','Working','No action taken','New') NOT NULL DEFAULT 'No action taken',
  `type` enum('comment','request') DEFAULT 'request',
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`oc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf16;

INSERT INTO `offer_comments` (`oc_id`, `offer_id`, `resource_id`, `comment`, `action`, `type`, `created_date`, `modified_date`, `status`) VALUES (46, 207, 51, 'Hi', 'No action taken', 'request', '2022-03-18 14:49:56', '2022-03-18 14:50:15', 0);
INSERT INTO `offer_comments` (`oc_id`, `offer_id`, `resource_id`, `comment`, `action`, `type`, `created_date`, `modified_date`, `status`) VALUES (47, 213, 31, 'Price has increased by 20 dollar per ton\r\n', 'No action taken', 'request', '2022-03-22 18:28:23', '2022-03-22 18:40:31', 0);
INSERT INTO `offer_comments` (`oc_id`, `offer_id`, `resource_id`, `comment`, `action`, `type`, `created_date`, `modified_date`, `status`) VALUES (48, 210, 51, 'dfdf', 'No action taken', 'request', '2022-03-24 13:21:33', '2022-03-24 13:21:47', 0);
INSERT INTO `offer_comments` (`oc_id`, `offer_id`, `resource_id`, `comment`, `action`, `type`, `created_date`, `modified_date`, `status`) VALUES (50, 214, 31, 'price change', 'No action taken', 'request', '2022-03-26 01:55:45', '2022-03-26 01:55:45', 1);
INSERT INTO `offer_comments` (`oc_id`, `offer_id`, `resource_id`, `comment`, `action`, `type`, `created_date`, `modified_date`, `status`) VALUES (51, 0, 31, 'sasa', 'No action taken', 'request', '2022-03-26 02:00:17', '2022-03-26 02:00:17', 1);
INSERT INTO `offer_comments` (`oc_id`, `offer_id`, `resource_id`, `comment`, `action`, `type`, `created_date`, `modified_date`, `status`) VALUES (52, 219, 51, 'ghg', 'No action taken', 'request', '2022-03-29 15:43:49', '2022-03-29 15:43:54', 0);
INSERT INTO `offer_comments` (`oc_id`, `offer_id`, `resource_id`, `comment`, `action`, `type`, `created_date`, `modified_date`, `status`) VALUES (53, 221, 31, 'Price Change in Yellow Tail Scad Only', 'No action taken', 'request', '2022-03-30 13:39:09', '2022-03-30 13:39:46', 0);


#
# TABLE STRUCTURE FOR: offer_details
#

DROP TABLE IF EXISTS `offer_details`;

CREATE TABLE `offer_details` (
  `od_id` int(11) NOT NULL AUTO_INCREMENT,
  `offer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `freezing_id` int(11) DEFAULT NULL,
  `freezing_method_id` int(11) DEFAULT NULL,
  `primary_packing_type_id` int(11) DEFAULT NULL,
  `secondary_packing_type_id` int(11) DEFAULT NULL,
  `packing_size_id` int(11) DEFAULT NULL,
  `glazing_id` int(11) DEFAULT NULL,
  `block_id` int(11) DEFAULT NULL,
  `size_id` int(11) DEFAULT NULL,
  `product_description` varchar(300) DEFAULT NULL,
  `pieces` varchar(120) NOT NULL,
  `grade` varchar(120) NOT NULL,
  `size_before_glaze` enum('Yes','No','NA') CHARACTER SET utf8 DEFAULT NULL,
  `size_after_glaze` enum('Yes','No','NA') CHARACTER SET utf8 DEFAULT NULL,
  `quantity_offered` decimal(10,2) NOT NULL,
  `unit_id` int(11) NOT NULL COMMENT 'quantity unit',
  `cartons_offered` varchar(150) DEFAULT NULL,
  `product_price` double NOT NULL,
  `comment` text DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`od_id`)
) ENGINE=InnoDB AUTO_INCREMENT=334 DEFAULT CHARSET=utf16;

INSERT INTO `offer_details` (`od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (302, 210, 2, 1, 3, 1, 3, 5, 3, 3, 3, 'Demo Test', '8', '7', 'Yes', 'Yes', '3.00', 9, '', '200', 'n publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without', 51, '2022-03-19 18:26:35', '2022-03-19 18:26:35', 1);
INSERT INTO `offer_details` (`od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (305, 213, 6, 2, 5, 1, 3, 7, 1, 3, 29, 'Whole Round', '2', '', 'NA', 'NA', '0.25', 12, '2700', '550', '', 1, '2022-03-22 18:16:46', '2022-03-28 18:33:53', 1);
INSERT INTO `offer_details` (`od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (310, 215, 18, 2, 5, 1, 3, 1, 1, 3, 19, 'Whole Round', '', '', 'No', 'No', '5.00', 12, '500', '1400', '', 31, '2022-03-26 10:35:05', '2022-03-26 10:35:05', 1);
INSERT INTO `offer_details` (`od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (311, 215, 18, 2, 5, 1, 3, 1, 1, 3, 20, '', '', '', 'No', 'No', '17.00', 12, '1700', '1400', '', 31, '2022-03-26 10:35:45', '2022-03-26 10:35:45', 1);
INSERT INTO `offer_details` (`od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (312, 215, 18, 2, 5, 1, 3, 1, 1, 3, 21, '', '', '', 'No', 'No', '5.00', 12, '500', '1300', '', 31, '2022-03-26 10:36:25', '2022-03-26 10:36:25', 1);
INSERT INTO `offer_details` (`od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (313, 217, 2, 1, 3, 1, 3, 5, 3, 3, 3, NULL, '8', '7', 'Yes', 'Yes', '3.00', 9, '', '200', 'n publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without', 1, '2022-03-28 15:04:03', '2022-03-28 15:04:03', 1);
INSERT INTO `offer_details` (`od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (314, 218, 2, 1, 3, 1, 3, 5, 3, 3, 3, NULL, '8', '7', 'Yes', 'Yes', '3.00', 9, '', '200', 'n publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without', 1, '2022-03-28 18:34:41', '2022-03-28 18:34:41', 1);
INSERT INTO `offer_details` (`od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (315, 215, 8, 0, 4, 0, 0, 7, 5, 0, 8, 'Lorem', '12', '', '', '', '7.00', 0, '', '1000', '', 1, '2022-03-29 14:30:21', '2022-03-29 14:30:21', 1);
INSERT INTO `offer_details` (`od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (316, 215, 8, NULL, 4, NULL, NULL, 7, 5, NULL, 8, '', '12', '', NULL, NULL, '7.00', 12, '', '1000', '', 1, '2022-03-29 14:34:31', '2022-03-29 14:34:31', 1);
INSERT INTO `offer_details` (`od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (317, 219, 2, 1, 0, 1, 3, 5, 0, 4, 3, '', '56', '', '', '', '0.25', 12, '', '700', '', 51, '2022-03-29 15:44:37', '2022-03-29 15:44:37', 1);
INSERT INTO `offer_details` (`od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (318, 220, 2, 1, 0, 1, 3, 5, 0, 4, 3, NULL, '56', '', '', '', '0.25', 12, '', '700', '', 1, '2022-03-29 15:45:05', '2022-03-29 15:45:05', 1);
INSERT INTO `offer_details` (`od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (320, 213, 18, 2, 4, 1, 3, 1, 1, 3, 20, NULL, '', '', 'NA', 'NA', '0.75', 12, '250', '565', '', 31, '2022-03-30 13:26:11', '2022-03-30 13:26:11', 1);
INSERT INTO `offer_details` (`od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (324, 222, 18, 2, 5, 1, 3, 1, 1, 3, 29, 'Whole Round', '', '', 'NA', 'NA', '1.00', 12, '100', '1400', '', 56, '2022-03-31 15:41:40', '2022-03-31 15:41:40', 1);
INSERT INTO `offer_details` (`od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (325, 222, 18, 2, 5, 1, 3, 1, 1, 3, 19, '', '', '', 'NA', 'NA', '10.00', 12, '1000', '1400', '', 56, '2022-03-31 15:44:52', '2022-03-31 15:44:52', 1);
INSERT INTO `offer_details` (`od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (326, 222, 18, 2, 5, 1, 3, 1, 1, 3, 20, '', '', '', 'NA', 'NA', '16.00', 12, '1600', '1400', '', 56, '2022-03-31 15:47:01', '2022-03-31 15:47:01', 1);
INSERT INTO `offer_details` (`od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (327, 223, 18, 2, 5, 1, 3, 1, 1, 3, 29, 'Whole Round', '', '', 'NA', 'NA', '1.00', 12, '100', '1400', '', 56, '2022-03-31 17:59:08', '2022-03-31 17:59:08', 1);
INSERT INTO `offer_details` (`od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (328, 223, 18, 2, 5, 1, 3, 1, 1, 3, 19, '', '', '', 'NA', 'NA', '17.00', 12, '1700', '1400', '', 56, '2022-03-31 18:07:28', '2022-03-31 18:07:28', 1);
INSERT INTO `offer_details` (`od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (329, 223, 18, 2, 5, 1, 3, 1, 1, 3, 20, '', '', '', 'NA', 'NA', '36.00', 12, '3600', '1400', '', 56, '2022-03-31 18:08:26', '2022-03-31 18:08:26', 1);
INSERT INTO `offer_details` (`od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (333, 221, 1, 1, 4, 1, 4, 6, 3, 3, 4, 'New Product', '56', '11', 'Yes', 'Yes', '7.00', 12, '5', '775', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ', 1, '2022-04-04 13:39:47', '2022-04-04 13:39:47', 1);


#
# TABLE STRUCTURE FOR: offer_details_resource
#

DROP TABLE IF EXISTS `offer_details_resource`;

CREATE TABLE `offer_details_resource` (
  `odr_id` int(11) NOT NULL AUTO_INCREMENT,
  `od_id` int(11) DEFAULT NULL,
  `offer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `freezing_id` int(11) DEFAULT NULL,
  `freezing_method_id` int(11) DEFAULT NULL,
  `primary_packing_type_id` int(11) DEFAULT NULL,
  `secondary_packing_type_id` int(11) DEFAULT NULL,
  `packing_size_id` int(11) DEFAULT NULL,
  `glazing_id` int(11) DEFAULT NULL,
  `block_id` int(11) DEFAULT NULL,
  `size_id` int(11) DEFAULT NULL,
  `product_description` varchar(300) DEFAULT NULL,
  `pieces` varchar(120) NOT NULL,
  `grade` varchar(120) NOT NULL,
  `size_before_glaze` enum('Yes','No','NA') CHARACTER SET utf8 DEFAULT NULL,
  `size_after_glaze` enum('Yes','No','NA') CHARACTER SET utf8 DEFAULT NULL,
  `quantity_offered` decimal(10,2) NOT NULL,
  `unit_id` int(11) NOT NULL COMMENT 'quantity unit',
  `cartons_offered` varchar(150) DEFAULT NULL,
  `product_price` double NOT NULL,
  `comment` text DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`odr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=334 DEFAULT CHARSET=utf16;

INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (308, 302, 210, 2, 1, 3, 1, 3, 5, 3, 3, 3, 'Demo Test', '8', '7', 'Yes', 'Yes', '3.00', 9, '', '200', 'n publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without', 51, '2022-03-19 18:26:35', '2022-03-19 18:26:35', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (309, 303, 211, 2, 1, 3, 1, 3, 5, 3, 3, 3, NULL, '8', '7', 'Yes', 'Yes', '3.00', 9, '', '200', 'n publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without', 1, '2022-03-19 18:30:17', '2022-03-19 18:30:17', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (310, 304, 212, 4, 1, 4, 1, 3, 4, 1, 3, 6, '', '', '', 'NA', 'NA', '27.00', 12, '1350', '1500', '', 16, '2022-03-22 17:37:14', '2022-03-22 17:37:14', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (311, 305, 213, 6, 2, 5, 1, 3, 7, 1, 3, 29, 'Whole Round', '', '', 'NA', 'NA', '54.00', 12, '2700', '550', '', 31, '2022-03-22 18:16:46', '2022-03-22 18:16:46', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (312, 306, 214, 23, 2, 3, 1, 3, 1, 1, 3, 11, 'Whole Round', '', '', 'No', 'No', '0.00', 12, '25', '750', '', 31, '2022-03-25 22:18:42', '2022-03-25 22:18:42', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (313, 307, 214, 23, 2, 3, 1, 3, 1, 1, 3, 5, 'Whole Round', '', '', 'No', 'No', '26.00', 12, '2580', '830', '', 31, '2022-03-25 22:25:33', '2022-03-25 22:25:33', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (314, 308, 214, 23, 2, 3, 1, 3, 1, 1, 3, 15, 'Whole Round', '', '', 'No', 'No', '1.00', 12, '74', '880', '', 31, '2022-03-25 22:29:57', '2022-03-25 22:29:57', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (315, 309, 214, 23, 2, 3, 1, 3, 1, 1, 3, 29, '', '', '', 'No', 'No', '0.00', 12, '21', '1000', '', 31, '2022-03-25 22:33:52', '2022-03-25 22:33:52', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (316, 310, 215, 18, 2, 5, 1, 3, 1, 1, 3, 19, 'Whole Round', '', '', 'No', 'No', '5.00', 12, '500', '1400', '', 31, '2022-03-26 10:35:05', '2022-03-26 10:35:05', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (317, 311, 215, 18, 2, 5, 1, 3, 1, 1, 3, 20, '', '', '', 'No', 'No', '17.00', 12, '1700', '1400', '', 31, '2022-03-26 10:35:45', '2022-03-26 10:35:45', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (318, 312, 215, 18, 2, 5, 1, 3, 1, 1, 3, 21, '', '', '', 'No', 'No', '5.00', 12, '500', '1300', '', 31, '2022-03-26 10:36:25', '2022-03-26 10:36:25', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (319, 313, 217, 2, 1, 3, 1, 3, 5, 3, 3, 3, NULL, '8', '7', 'Yes', 'Yes', '3.00', 9, '', '200', 'n publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without', 1, '2022-03-28 15:04:03', '2022-03-28 15:04:03', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (320, 314, 218, 2, 1, 3, 1, 3, 5, 3, 3, 3, NULL, '8', '7', 'Yes', 'Yes', '3.00', 9, '', '200', 'n publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without', 1, '2022-03-28 18:34:41', '2022-03-28 18:34:41', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (321, 317, 219, 2, 1, 0, 1, 3, 5, 0, 4, 3, '', '56', '', '', '', '0.25', 12, '', '700', '', 51, '2022-03-29 15:44:37', '2022-03-29 15:44:37', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (322, 318, 220, 2, 1, 0, 1, 3, 5, 0, 4, 3, NULL, '56', '', '', '', '0.25', 12, '', '700', '', 1, '2022-03-29 15:45:05', '2022-03-29 15:45:05', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (323, 319, 221, 18, 2, 4, 1, 3, 1, 1, 3, 3, 'Whole Round', '2-4 Pcs', '', 'NA', 'NA', '0.25', 12, '250', '550', '', 31, '2022-03-30 13:25:25', '2022-03-30 13:30:16', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (324, 320, 213, 18, 2, 4, 1, 3, 1, 1, 3, 20, NULL, '', '', 'NA', 'NA', '0.75', 12, '250', '565', '', 31, '2022-03-30 13:26:11', '2022-03-30 13:26:11', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (325, 321, 221, 23, 2, 4, 1, 3, 1, 1, 3, 30, '', '3-4 Pcs', '', 'NA', 'NA', '0.75', 12, '250', '580', '', 31, '2022-03-30 13:28:05', '2022-03-30 13:30:57', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (326, 322, 221, 23, 2, 4, 1, 3, 1, 1, 3, 29, '', '10-12 Pcs', '', 'NA', 'NA', '26.00', 12, '250', '1275', '', 31, '2022-03-30 13:28:48', '2022-03-30 13:29:38', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (327, 323, 221, 23, 2, 4, 1, 3, 7, 1, 3, 29, '', '10-12 Pcs', '', 'NA', 'NA', '27.00', 12, '250', '1350', '', 31, '2022-03-30 13:32:08', '2022-03-30 13:32:08', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (328, 324, 222, 18, 2, 5, 1, 3, 1, 1, 3, 29, 'Whole Round', '', '', 'NA', 'NA', '1.00', 12, '100', '1400', '', 56, '2022-03-31 15:41:40', '2022-03-31 15:41:40', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (329, 325, 222, 18, 2, 5, 1, 3, 1, 1, 3, 19, '', '', '', 'NA', 'NA', '10.00', 12, '1000', '1400', '', 56, '2022-03-31 15:44:52', '2022-03-31 15:44:52', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (330, 326, 222, 18, 2, 5, 1, 3, 1, 1, 3, 20, '', '', '', 'NA', 'NA', '16.00', 12, '1600', '1400', '', 56, '2022-03-31 15:47:01', '2022-03-31 15:47:01', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (331, 327, 223, 18, 2, 5, 1, 3, 1, 1, 3, 29, 'Whole Round', '', '', 'NA', 'NA', '1.00', 12, '100', '1400', '', 56, '2022-03-31 17:59:08', '2022-03-31 17:59:08', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (332, 328, 223, 18, 2, 5, 1, 3, 1, 1, 3, 19, '', '', '', 'NA', 'NA', '17.00', 12, '1700', '1400', '', 56, '2022-03-31 18:07:28', '2022-03-31 18:07:28', 1);
INSERT INTO `offer_details_resource` (`odr_id`, `od_id`, `offer_id`, `product_id`, `freezing_id`, `freezing_method_id`, `primary_packing_type_id`, `secondary_packing_type_id`, `packing_size_id`, `glazing_id`, `block_id`, `size_id`, `product_description`, `pieces`, `grade`, `size_before_glaze`, `size_after_glaze`, `quantity_offered`, `unit_id`, `cartons_offered`, `product_price`, `comment`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (333, 329, 223, 18, 2, 5, 1, 3, 1, 1, 3, 20, '', '', '', 'NA', 'NA', '36.00', 12, '3600', '1400', '', 56, '2022-03-31 18:08:26', '2022-03-31 18:08:26', 1);


#
# TABLE STRUCTURE FOR: offer_files
#

DROP TABLE IF EXISTS `offer_files`;

CREATE TABLE `offer_files` (
  `op_id` int(11) NOT NULL AUTO_INCREMENT,
  `offer_id` int(11) NOT NULL,
  `file_category` enum('picture','report') NOT NULL,
  `file_name` varchar(300) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`op_id`)
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=utf16;

INSERT INTO `offer_files` (`op_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (127, 221, 'picture', 'IMG20220110135021.jpg', 31, '2022-03-30 13:22:37', '2022-03-30 13:22:37', 1);
INSERT INTO `offer_files` (`op_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (128, 221, 'picture', 'IMG20220110135030.jpg', 31, '2022-03-30 13:22:37', '2022-03-30 13:22:37', 1);
INSERT INTO `offer_files` (`op_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (129, 221, 'picture', 'IMG20220110135120.jpg', 31, '2022-03-30 13:22:37', '2022-03-30 13:22:37', 1);
INSERT INTO `offer_files` (`op_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (130, 221, 'picture', 'IMG20220110135122.jpg', 31, '2022-03-30 13:22:37', '2022-03-30 13:22:37', 1);
INSERT INTO `offer_files` (`op_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (131, 221, 'picture', 'IMG20220110135124.jpg', 31, '2022-03-30 13:22:37', '2022-03-30 13:22:37', 1);
INSERT INTO `offer_files` (`op_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (132, 221, 'picture', 'IMG20220110135133.jpg', 31, '2022-03-30 13:22:37', '2022-03-30 13:22:37', 1);
INSERT INTO `offer_files` (`op_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (133, 221, 'picture', 'IMG20220110135143.jpg', 31, '2022-03-30 13:22:37', '2022-03-30 13:22:37', 1);
INSERT INTO `offer_files` (`op_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (134, 221, 'report', 'loading_instruction_SFME_FZ-FSG-CC-261.XLSX', 31, '2022-03-30 13:22:37', '2022-03-30 13:22:37', 1);


#
# TABLE STRUCTURE FOR: offer_files_resource
#

DROP TABLE IF EXISTS `offer_files_resource`;

CREATE TABLE `offer_files_resource` (
  `op_id` int(11) NOT NULL AUTO_INCREMENT,
  `offer_files_id` int(11) DEFAULT NULL,
  `offer_id` int(11) NOT NULL,
  `file_category` enum('picture','report') NOT NULL,
  `file_name` varchar(300) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`op_id`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf16;

INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (94, 0, 127, 'picture', 'c-15609.jpg', 16, '2021-10-22 15:23:00', '2021-10-22 15:23:00', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (95, 0, 127, 'picture', 'Capture.JPG', 16, '2021-10-22 15:23:00', '2021-10-22 15:23:00', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (96, 0, 127, 'report', 'ABC.pdf', 16, '2021-10-22 15:23:00', '2021-10-22 15:23:00', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (97, 0, 127, 'report', '6.xlsx', 16, '2021-10-22 15:23:00', '2021-10-22 15:23:00', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (98, 0, 127, 'report', 'ABC.xlsx', 16, '2021-10-22 15:23:00', '2021-10-22 15:23:00', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (99, 0, 127, 'report', 'Doc1.docx', 16, '2021-10-22 15:23:00', '2021-10-22 15:23:00', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (100, 0, 127, 'report', 'Fish_Parameters.docx', 16, '2021-10-22 15:23:00', '2021-10-22 15:23:00', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (101, 0, 127, 'report', 'ABC1.pdf', 16, '2021-10-22 15:23:34', '2021-10-22 15:23:34', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (102, 0, 127, 'report', 'ABC2.pdf', 16, '2021-10-22 15:23:50', '2021-10-22 15:23:50', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (103, 0, 127, 'picture', 'Capture1.JPG', 16, '2021-10-22 15:24:20', '2021-10-22 15:24:20', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (104, 104, 189, 'picture', 'PO.jpg', 14, '2021-10-31 18:52:32', '2021-10-31 18:52:32', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (105, 105, 189, 'report', 'proforma.pdf', 14, '2021-10-31 18:52:32', '2021-10-31 18:52:32', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (106, 107, 190, 'picture', 'Best2.png', 1, '2021-11-05 15:44:46', '2021-11-05 15:44:46', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (107, 108, 190, 'report', 'Capture.PNG', 1, '2021-11-05 15:44:46', '2021-11-05 15:44:46', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (108, 109, 191, 'picture', '1_(2).jpeg', 1, '2021-11-05 18:23:54', '2021-11-05 18:23:54', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (109, 110, 191, 'report', 'circle1.jpg', 1, '2021-11-05 18:23:54', '2021-11-05 18:23:54', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (110, 111, 192, 'picture', '1_(2)1.jpeg', 46, '2021-11-05 18:32:44', '2021-11-05 18:32:44', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (111, 112, 192, 'report', 'circle11.jpg', 46, '2021-11-05 18:32:44', '2021-11-05 18:32:44', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (112, 113, 193, 'picture', '1_(2)2.jpeg', 48, '2021-11-06 11:40:47', '2021-11-06 11:40:47', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (113, 114, 193, 'report', 'WhatsApp_Image_2021-11-02_at_10_54_31_PM.jpeg', 48, '2021-11-06 11:40:47', '2021-11-06 11:40:47', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (114, 115, 201, 'picture', 'IMG20220110135021.jpg', 16, '2022-03-17 18:28:12', '2022-03-17 18:28:12', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (115, 116, 201, 'picture', 'IMG20220110135030.jpg', 16, '2022-03-17 18:28:12', '2022-03-17 18:28:12', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (116, 117, 201, 'picture', 'IMG20220110135120.jpg', 16, '2022-03-17 18:28:12', '2022-03-17 18:28:12', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (117, 118, 201, 'picture', 'IMG20220110135122.jpg', 16, '2022-03-17 18:28:12', '2022-03-17 18:28:12', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (118, 119, 201, 'picture', 'IMG20220110135124.jpg', 16, '2022-03-17 18:28:12', '2022-03-17 18:28:12', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (119, 120, 201, 'picture', 'IMG20220110135133.jpg', 16, '2022-03-17 18:28:12', '2022-03-17 18:28:12', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (120, 121, 201, 'picture', 'IMG20220110135143.jpg', 16, '2022-03-17 18:28:12', '2022-03-17 18:28:12', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (121, 122, 201, 'picture', 'IMG20220110135155.jpg', 16, '2022-03-17 18:28:12', '2022-03-17 18:28:12', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (122, 123, 201, 'picture', 'IMG20220110135159.jpg', 16, '2022-03-17 18:28:12', '2022-03-17 18:28:12', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (123, 124, 201, 'picture', 'IMG20220110135203.jpg', 16, '2022-03-17 18:28:12', '2022-03-17 18:28:12', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (124, 125, 201, 'picture', 'IMG20220110135206.jpg', 16, '2022-03-17 18:28:12', '2022-03-17 18:28:12', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (125, 126, 201, 'report', 'loading_instruction_SFME_FZ-FSG-CC-261.XLSX', 16, '2022-03-17 18:28:12', '2022-03-17 18:28:12', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (126, 127, 221, 'picture', 'IMG20220110135021.jpg', 31, '2022-03-30 13:22:37', '2022-03-30 13:22:37', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (127, 128, 221, 'picture', 'IMG20220110135030.jpg', 31, '2022-03-30 13:22:37', '2022-03-30 13:22:37', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (128, 129, 221, 'picture', 'IMG20220110135120.jpg', 31, '2022-03-30 13:22:37', '2022-03-30 13:22:37', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (129, 130, 221, 'picture', 'IMG20220110135122.jpg', 31, '2022-03-30 13:22:37', '2022-03-30 13:22:37', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (130, 131, 221, 'picture', 'IMG20220110135124.jpg', 31, '2022-03-30 13:22:37', '2022-03-30 13:22:37', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (131, 132, 221, 'picture', 'IMG20220110135133.jpg', 31, '2022-03-30 13:22:37', '2022-03-30 13:22:37', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (132, 133, 221, 'picture', 'IMG20220110135143.jpg', 31, '2022-03-30 13:22:37', '2022-03-30 13:22:37', 1);
INSERT INTO `offer_files_resource` (`op_id`, `offer_files_id`, `offer_id`, `file_category`, `file_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (133, 134, 221, 'report', 'loading_instruction_SFME_FZ-FSG-CC-261.XLSX', 31, '2022-03-30 13:22:37', '2022-03-30 13:22:37', 1);


#
# TABLE STRUCTURE FOR: offers
#

DROP TABLE IF EXISTS `offers`;

CREATE TABLE `offers` (
  `offer_id` int(11) NOT NULL AUTO_INCREMENT,
  `offer_name` varchar(120) NOT NULL,
  `offer_number` varchar(120) DEFAULT NULL,
  `offer_fz_number` varchar(200) DEFAULT NULL,
  `offer_date` date NOT NULL,
  `am_id` int(11) NOT NULL COMMENT 'supplier_id',
  `destination_c_id` varchar(200) NOT NULL,
  `country_id` int(11) NOT NULL COMMENT 'Source country',
  `c_id` int(11) NOT NULL COMMENT 'currency_id',
  `incoterm_id` int(11) NOT NULL,
  `no_of_container` int(11) NOT NULL,
  `size_of_container` varchar(100) NOT NULL,
  `quantity_each_container` varchar(120) NOT NULL,
  `shipping_line` text NOT NULL,
  `supplier_payment_terms` text NOT NULL,
  `document_clause` text NOT NULL,
  `inspection_clause` text NOT NULL,
  `lab_report_clause` text NOT NULL,
  `shipment_timing` varchar(120) DEFAULT NULL,
  `etd` varchar(200) DEFAULT NULL,
  `port_of_loading` varchar(120) DEFAULT NULL,
  `production_date` varchar(200) DEFAULT NULL,
  `shelf_life` varchar(120) DEFAULT NULL,
  `tolerance` varchar(120) DEFAULT NULL,
  `label_attached` varchar(120) NOT NULL DEFAULT '?',
  `carton_with_date` varchar(120) NOT NULL DEFAULT '?',
  `remarks_1` text NOT NULL,
  `remarks_2` text NOT NULL,
  `remarks_3` text NOT NULL,
  `resource_edit_status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 = resource not finalised',
  `resource_id` int(11) NOT NULL,
  `cloned_offer_id` int(11) DEFAULT NULL COMMENT 'Cloned from ID',
  `final_marketing_approval_status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 = not sent to marketing for client communication',
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`offer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=225 DEFAULT CHARSET=utf16;

INSERT INTO `offers` (`offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (213, 'Grey Mullet from Mauritania', 'OFFER/22032022/054556', '', '2022-02-07', 32, '37,49,81', 135, 11, 1, 2, '40 FT REEFER', '27 Tons', 'any international line', '100 % advance before shipment', 'invoice, packing list, Health certificate, Certificate of origin, Bill of lading ', 'Subject to inspection ', 'Can be provided if required', 'prompt', '20.01.2022', '3', 'Nov/Dec\'2021', '18 months', '10%', 'No', 'Yes', '3', '18 kg carton. document will be provided for 20 kg\r\nto be charged on 18 kg basis', 'auto production date exists on the carton', 0, 31, NULL, 1, 1, '2022-03-22 18:10:00', '2022-03-26 01:05:49', 1);
INSERT INTO `offers` (`offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (215, 'Yellow Tail Scad f rom Oman', 'OFFER/26032022/102436', 'FZ-958', '2022-01-01', 70, '120', 161, 2, 2, 1, '40 FT', '27 Tons', 'CMA-CGM', '20% Advance; Balance on Scan copy of Final Docs', 'Inv, PL, HC, COO, BL', 'Will be provided on Demand', 'Will be provided on Demand', 'Prompt', '10th Jan 2022 approx', '11', 'Dec 2021', '18 Months', '10%', 'No', 'No', '1', '', '', 0, 31, NULL, 1, 31, '2022-03-26 10:32:57', '2022-03-28 14:48:39', 1);
INSERT INTO `offers` (`offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (216, 'demo', 'OFFER/28032022/030221', 'FZ-777', '2022-03-28', 12, '', 1, 2, 3, 0, '', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '1', '', '', 1, 51, NULL, 0, 51, '2022-03-28 15:03:19', '2022-03-28 15:03:19', 1);
INSERT INTO `offers` (`offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (217, 'testoffer', 'OFFER/28032022/030403', NULL, '2022-03-19', 12, '', 1, 1, 1, 0, '', '', '', '', '', '', '', '', '', '2', '', '', '', '', '', '1', '', '', 0, 51, NULL, 0, 0, '2022-03-28 15:04:03', '2022-04-03 16:10:59', 1);
INSERT INTO `offers` (`offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (218, 'testoffer', 'OFFER/28032022/063441', NULL, '2022-03-19', 12, '', 1, 1, 1, 0, '', '', '', '', '', '', '', '', '', '2', '', '', '', '', '', '1', '', '', 1, 51, NULL, 0, 0, '2022-03-28 18:34:41', '2022-03-28 18:34:41', 1);
INSERT INTO `offers` (`offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (219, 'demo22', 'OFFER/29032022/034237', 'FZ-88', '2022-03-29', 12, '3', 1, 1, 2, 0, '', '', '', '', '', '', '', '', '', '1', '', '', '', 'Yes', 'Yes', '1', '', '', 0, 51, NULL, 0, 1, '2022-03-29 15:43:08', '2022-04-01 12:36:20', 1);
INSERT INTO `offers` (`offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (220, 'demo22', 'OFFER/29032022/034505', '', '2022-03-29', 12, '44,162', 1, 1, 2, 0, '', '', '', '', '', '', '', '', '', '1', '', '', '', 'Yes', 'Yes', '1', '', '', 0, 51, NULL, 0, 1, '2022-03-29 15:45:05', '2022-04-03 15:28:27', 1);
INSERT INTO `offers` (`offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (221, 'Cat Fish from Yemen', 'OFFER/30032022/010926', '', '2022-02-15', 71, '37,81', 237, 2, 1, 2, '40 FT', '27 Tons', 'CMA / Maersk', '25% Advance; Balance on Scan copy of Docs', 'Inv, PL, HC, COO and BL', 'Subject to Inspection', 'Not Required', 'Prompt', 'by End of Feb 2022', '6', 'Feb 2022', '18 Months', '10%', 'No', 'No', '3', 'dsfsdfsdfdf', '', 0, 31, NULL, 1, 31, '2022-03-30 13:22:37', '2022-03-30 15:27:54', 1);
INSERT INTO `offers` (`offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (222, 'Yellow tail scad from Yemen', 'OFFER/31032022/031046', 'FZ-FSG-CC-270', '2022-02-23', 71, '81', 237, 2, 2, 1, '40 ft Reefer', '27', 'CMA CGM/Maersk Line', '25 % in Advance & balance after scan copy of original documents', 'Invoice, Packing list, HC, COO& BL', 'Loading photos to be provided by Tamimi', 'N/A', 'Prompt', '28th Feb', '6', 'Jan 2022', '18 months from production date', '10 % Tlerance', 'No', 'No', '1', '', '', 1, 56, NULL, 0, 56, '2022-03-31 15:29:13', '2022-03-31 15:29:13', 1);
INSERT INTO `offers` (`offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (223, 'Yellow tail Scad from Yemen', 'OFFER/31032022/053716', 'FZ-FSG-CC-271', '2022-02-23', 71, '120', 237, 2, 2, 2, '40 ft Reefer', '27', 'CMA CGM/Maersk Line', '25 % advance payment and balance after scan copy of original documents', 'Invoice, Packing list, HC, COO, BL', 'Loading photos to be provided by Tamimi', 'N/A', '', '28 th Feb', '6', 'Jan 2022', '18 months from production date', '10 %', 'No', 'No', '1', '', '', 1, 56, NULL, 0, 56, '2022-03-31 17:44:27', '2022-03-31 17:58:58', 1);
INSERT INTO `offers` (`offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (224, 'ds', 'OFFER/01042022/121706', '', '2022-04-01', 12, '', 1, 1, 1, 0, '', '', '', '', '', '', '', '', 'fedfd', '1', '', '', '', 'Yes', 'Yes', '1', '', '', 0, 51, NULL, 0, 51, '2022-04-01 12:17:48', '2022-04-03 15:38:21', 1);


#
# TABLE STRUCTURE FOR: offers_resource
#

DROP TABLE IF EXISTS `offers_resource`;

CREATE TABLE `offers_resource` (
  `offer_resource_id` int(11) NOT NULL AUTO_INCREMENT,
  `offer_id` int(11) DEFAULT NULL,
  `offer_name` varchar(120) NOT NULL,
  `offer_number` varchar(120) DEFAULT NULL,
  `offer_fz_number` varchar(200) DEFAULT NULL,
  `offer_date` date NOT NULL,
  `am_id` int(11) NOT NULL COMMENT 'supplier_id',
  `destination_c_id` varchar(200) NOT NULL,
  `country_id` int(11) NOT NULL COMMENT 'Source country',
  `c_id` int(11) NOT NULL COMMENT 'currency_id',
  `incoterm_id` int(11) NOT NULL,
  `no_of_container` int(11) NOT NULL,
  `size_of_container` varchar(100) NOT NULL,
  `quantity_each_container` varchar(120) NOT NULL,
  `shipping_line` text NOT NULL,
  `supplier_payment_terms` text NOT NULL,
  `document_clause` text NOT NULL,
  `inspection_clause` text NOT NULL,
  `lab_report_clause` text NOT NULL,
  `shipment_timing` varchar(120) DEFAULT NULL,
  `etd` varchar(200) DEFAULT NULL,
  `port_of_loading` varchar(120) DEFAULT NULL,
  `production_date` varchar(200) DEFAULT NULL,
  `shelf_life` varchar(120) DEFAULT NULL,
  `tolerance` varchar(120) DEFAULT NULL,
  `label_attached` varchar(120) NOT NULL DEFAULT '?',
  `carton_with_date` varchar(120) NOT NULL DEFAULT '?',
  `remarks_1` text NOT NULL,
  `remarks_2` text NOT NULL,
  `remarks_3` text NOT NULL,
  `resource_edit_status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 = resource not finalised',
  `resource_id` int(11) NOT NULL,
  `cloned_offer_id` int(11) DEFAULT NULL COMMENT 'Cloned from ID',
  `final_marketing_approval_status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 = not sent to marketing for client communication',
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`offer_resource_id`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf16;

INSERT INTO `offers_resource` (`offer_resource_id`, `offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (97, 211, 'testoffer', 'OFFER/19032022/063017', '', '2022-03-19', 33, '', 1, 2, 2, 0, '', '', '', '', '', '', '', '', '', '2', '', '', '', 'Yes', 'Yes', '1', '', '', 0, 51, NULL, 0, 51, '2022-03-19 18:30:17', '2022-04-03 15:42:25', 1);
INSERT INTO `offers_resource` (`offer_resource_id`, `offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (98, 212, 'DEMO 22/03/2022 - 1', 'OFFER/22032022/053434', '', '2022-03-22', 32, '3', 4, 2, 1, 1, '', '', '', '', '', '', '', '', '', '6', '', '', '', '', '', '1', '', '', 1, 16, NULL, 0, 16, '2022-03-22 17:35:49', '2022-03-22 17:35:49', 1);
INSERT INTO `offers_resource` (`offer_resource_id`, `offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (99, 213, 'Grey Mullet from Mauritania', 'OFFER/22032022/054556', '', '2022-03-22', 32, '37,49,81', 135, 11, 1, 2, '40 FT REEFER', '27 Tons', 'any international line', '100 % advance before shipment', 'invoice, packing list, Health certificate, Certificate of origin, Bill of lading ', 'Subject to inspection ', 'Can be provided if required', 'prompt', '20.01.2022', '3', 'Nov/Dec\'2021', '18 months', '10%', 'remarks', 'Yes', '3', '18 kg carton. document will be provided for 20 kg\r\nto be charged on 18 kg basis', 'auto production date is there in the boxes.\r\nbut explanation required since the code are associated with traceability. ', 0, 31, NULL, 0, 31, '2022-03-22 18:10:00', '2022-03-22 18:51:20', 1);
INSERT INTO `offers_resource` (`offer_resource_id`, `offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (100, 214, 'Cat Fish from Oman', 'OFFER/25032022/093647', 'FZ-939', '2021-09-29', 67, '', 161, 2, 2, 1, '40 FT REEFER', '27 tons', 'CMA-CGM / MAERSK LINE', 'Payment against Scan copy of Original Documents', 'Invoice PL HC COO BL', 'on Request', 'On Request', 'Prompt', 'Around 1st week of October 2021', '11', 'Sep 2021', '18 Months', '10%', 'No', 'No', '2', '', '', 0, 31, NULL, 0, 31, '2022-03-25 22:04:52', '2022-03-25 22:48:53', 1);
INSERT INTO `offers_resource` (`offer_resource_id`, `offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (101, 0, 'Cat Fish from Oman', 'OFFER/26032022/015743', NULL, '2021-09-29', 67, '', 161, 2, 2, 1, '40 FT REEFER', '27 tons', 'CMA-CGM / MAERSK LINE', 'Payment against Scan copy of Original Documents', 'Invoice PL HC COO BL', 'on Request', 'On Request', 'Prompt', 'Around 1st week of October 2021', '11', 'Sep 2021', '18 Months', '10%', 'No', 'No', '2', '', '', 0, 31, NULL, 0, 0, '2022-03-26 01:57:43', '2022-03-26 01:58:39', 1);
INSERT INTO `offers_resource` (`offer_resource_id`, `offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (102, 215, 'Yellow Tail Scad f rom Oman', 'OFFER/26032022/102436', 'FZ-958', '2022-01-01', 70, '120', 161, 2, 2, 1, '40 FT', '27 Tons', 'CMA-CGM', '20% Advance; Balance on Scan copy of Final Docs', 'Inv, PL, HC, COO, BL', 'Will be provided on Demand', 'Will be provided on Demand', 'Prompt', '10th Jan 2022 approx', '11', 'Dec 2021', '18 Months', '10%', 'No', 'No', '1', '', '', 0, 31, NULL, 0, 31, '2022-03-26 10:32:57', '2022-03-26 10:37:17', 1);
INSERT INTO `offers_resource` (`offer_resource_id`, `offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (103, 216, 'demo', 'OFFER/28032022/030221', 'FZ-777', '2022-03-28', 12, '', 1, 2, 3, 0, '', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '1', '', '', 1, 51, NULL, 0, 51, '2022-03-28 15:03:19', '2022-03-28 15:03:19', 1);
INSERT INTO `offers_resource` (`offer_resource_id`, `offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (104, 217, 'testoffer', 'OFFER/28032022/030403', NULL, '2022-03-19', 12, '', 1, 1, 1, 0, '', '', '', '', '', '', '', '', '', '2', '', '', '', '', '', '1', '', '', 0, 51, NULL, 0, 0, '2022-03-28 15:04:03', '2022-04-03 16:10:59', 1);
INSERT INTO `offers_resource` (`offer_resource_id`, `offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (105, 218, 'testoffer', 'OFFER/28032022/063441', NULL, '2022-03-19', 12, '', 1, 1, 1, 0, '', '', '', '', '', '', '', '', '', '2', '', '', '', '', '', '1', '', '', 1, 51, NULL, 0, 0, '2022-03-28 18:34:41', '2022-03-28 18:34:41', 1);
INSERT INTO `offers_resource` (`offer_resource_id`, `offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (106, 219, 'demo22', 'OFFER/29032022/034237', 'FZ-88', '2022-03-29', 12, '', 1, 1, 2, 0, '', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '1', '', '', 0, 51, NULL, 0, 51, '2022-03-29 15:43:08', '2022-03-29 15:44:50', 1);
INSERT INTO `offers_resource` (`offer_resource_id`, `offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (107, 220, 'demo22', 'OFFER/29032022/034505', NULL, '2022-03-29', 12, '', 1, 1, 2, 0, '', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '1', '', '', 0, 51, NULL, 0, 0, '2022-03-29 15:45:05', '2022-04-03 15:28:28', 1);
INSERT INTO `offers_resource` (`offer_resource_id`, `offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (108, 221, 'Cat Fish from Yemen', 'OFFER/30032022/010926', '', '2022-02-15', 71, '37,81', 237, 2, 1, 2, '40 FT', '27 Tons', 'CMA / Maersk', '25% Advance; Balance on Scan copy of Docs', 'Inv, PL, HC, COO and BL', 'Subject to Inspection', 'Not Required', 'Prompt', 'by End of Feb 2022', '6', 'Feb 2022', '18 Months', '10%', 'No', 'No', '3', 'dsfsdfsdfdf', '', 0, 31, NULL, 0, 31, '2022-03-30 13:22:37', '2022-03-30 13:50:32', 1);
INSERT INTO `offers_resource` (`offer_resource_id`, `offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (109, 222, 'Yellow tail scad from Yemen', 'OFFER/31032022/031046', 'FZ-FSG-CC-270', '2022-02-23', 71, '81', 237, 2, 2, 1, '40 ft Reefer', '27', 'CMA CGM/Maersk Line', '25 % in Advance & balance after scan copy of original documents', 'Invoice, Packing list, HC, COO& BL', 'Loading photos to be provided by Tamimi', 'N/A', 'Prompt', '28th Feb', '6', 'Jan 2022', '18 months from production date', '10 % Tlerance', 'No', 'No', '1', '', '', 1, 56, NULL, 0, 56, '2022-03-31 15:29:14', '2022-03-31 15:29:14', 1);
INSERT INTO `offers_resource` (`offer_resource_id`, `offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (110, 223, 'Yellow tail Scad from Yemen', 'OFFER/31032022/053716', 'FZ-FSG-CC-271', '2022-02-23', 71, '120', 237, 2, 2, 2, '40 ft Reefer', '27', 'CMA CGM/Maersk Line', '25 % advance payment and balance after scan copy of original documents', 'Invoice, Packing list, HC, COO, BL', 'Loading photos to be provided by Tamimi', 'N/A', '', '28 th Feb', '6', 'Jan 2022', '18 months from production date', '10 %', 'No', 'No', '1', '', '', 1, 56, NULL, 0, 56, '2022-03-31 17:44:27', '2022-03-31 17:58:58', 1);
INSERT INTO `offers_resource` (`offer_resource_id`, `offer_id`, `offer_name`, `offer_number`, `offer_fz_number`, `offer_date`, `am_id`, `destination_c_id`, `country_id`, `c_id`, `incoterm_id`, `no_of_container`, `size_of_container`, `quantity_each_container`, `shipping_line`, `supplier_payment_terms`, `document_clause`, `inspection_clause`, `lab_report_clause`, `shipment_timing`, `etd`, `port_of_loading`, `production_date`, `shelf_life`, `tolerance`, `label_attached`, `carton_with_date`, `remarks_1`, `remarks_2`, `remarks_3`, `resource_edit_status`, `resource_id`, `cloned_offer_id`, `final_marketing_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (111, 224, 'ds', 'OFFER/01042022/121706', '', '2022-04-01', 12, '', 1, 1, 1, 0, '', '', '', '', '', '', '', '', 'fedfd', '1', '', '', '', 'Yes', 'Yes', '1', '', '', 0, 51, NULL, 0, 51, '2022-04-01 12:17:48', '2022-04-03 15:38:21', 1);


#
# TABLE STRUCTURE FOR: packing_sizes
#

DROP TABLE IF EXISTS `packing_sizes`;

CREATE TABLE `packing_sizes` (
  `ps_id` int(11) NOT NULL AUTO_INCREMENT,
  `packing_size` varchar(120) NOT NULL,
  `information` varchar(300) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`ps_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf16;

INSERT INTO `packing_sizes` (`ps_id`, `packing_size`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (1, '10 Kg Box', '', 0, '2021-08-04 19:05:15', '2021-08-12 16:10:40', 1);
INSERT INTO `packing_sizes` (`ps_id`, `packing_size`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (4, '12 Kg Box', '', 0, '2021-08-12 16:09:39', '2021-08-12 16:09:39', 1);
INSERT INTO `packing_sizes` (`ps_id`, `packing_size`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (5, '15 Kg Box', '', 0, '2021-08-12 16:10:05', '2021-08-12 16:10:05', 1);
INSERT INTO `packing_sizes` (`ps_id`, `packing_size`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (6, '18 Kg Box', '', 0, '2021-08-12 16:10:18', '2021-08-12 16:10:18', 1);
INSERT INTO `packing_sizes` (`ps_id`, `packing_size`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (7, '20 Kg Box', '', 0, '2021-08-12 16:10:30', '2021-08-12 16:10:30', 1);
INSERT INTO `packing_sizes` (`ps_id`, `packing_size`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (8, '22 Kg Box', '', 0, '2021-09-09 15:28:57', '2021-09-09 15:28:57', 1);
INSERT INTO `packing_sizes` (`ps_id`, `packing_size`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (9, '24 Kg Box', '', 0, '2021-09-09 15:29:07', '2021-09-09 15:29:07', 1);
INSERT INTO `packing_sizes` (`ps_id`, `packing_size`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (10, '25 Kg Box', '', 0, '2021-09-09 15:29:16', '2021-09-09 15:29:16', 1);
INSERT INTO `packing_sizes` (`ps_id`, `packing_size`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (11, '6 Kg Box', '', 0, '2021-09-09 15:29:43', '2021-09-09 15:29:43', 1);


#
# TABLE STRUCTURE FOR: packing_types
#

DROP TABLE IF EXISTS `packing_types`;

CREATE TABLE `packing_types` (
  `pt_id` int(11) NOT NULL AUTO_INCREMENT,
  `packing_category` enum('Primary packing','Secondary packing') NOT NULL,
  `packing_type` varchar(120) NOT NULL,
  `information` varchar(300) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`pt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf16;

INSERT INTO `packing_types` (`pt_id`, `packing_category`, `packing_type`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (1, 'Primary packing', 'Plastic Bag', '', 0, '2021-08-04 19:05:15', '2021-08-12 16:06:55', 1);
INSERT INTO `packing_types` (`pt_id`, `packing_category`, `packing_type`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (3, 'Secondary packing', 'Corrogated Box', '', 0, '2021-08-12 16:08:23', '2021-08-12 16:08:23', 1);
INSERT INTO `packing_types` (`pt_id`, `packing_category`, `packing_type`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (4, 'Secondary packing', 'Metal Tin Can', '', 0, '2021-08-12 16:08:57', '2021-08-12 16:08:57', 1);
INSERT INTO `packing_types` (`pt_id`, `packing_category`, `packing_type`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (5, 'Secondary packing', 'Styrofoam Boxes', '', 0, '2021-08-17 17:45:06', '2021-08-17 17:45:06', 1);


#
# TABLE STRUCTURE FOR: ports
#

DROP TABLE IF EXISTS `ports`;

CREATE TABLE `ports` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT,
  `port_name` varchar(100) NOT NULL,
  `info` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf16;

INSERT INTO `ports` (`p_id`, `port_name`, `info`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (1, 'Tema, Ghana', '', 0, '2021-08-14 09:17:44', '2021-08-17 15:55:40', 1);
INSERT INTO `ports` (`p_id`, `port_name`, `info`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (2, 'Abidjan, Ivory Coast', '', 0, '2021-08-16 16:59:36', '2021-08-17 15:55:56', 1);
INSERT INTO `ports` (`p_id`, `port_name`, `info`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (3, 'Nouadhibou, Mauritania', '', 0, '2021-08-17 15:56:13', '2021-08-17 15:56:13', 1);
INSERT INTO `ports` (`p_id`, `port_name`, `info`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (4, 'Douala, Cameroon', '', 0, '2021-08-17 15:56:30', '2021-08-17 15:56:30', 1);
INSERT INTO `ports` (`p_id`, `port_name`, `info`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (5, 'Nelson, New Zealand', '', 0, '2021-08-17 15:56:57', '2021-08-17 15:56:57', 1);
INSERT INTO `ports` (`p_id`, `port_name`, `info`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (6, 'Aden, Yemen', '', 0, '2021-08-17 16:53:57', '2021-08-17 16:55:54', 1);
INSERT INTO `ports` (`p_id`, `port_name`, `info`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (7, 'Tokyo, Japan', '', 0, '2021-08-17 16:54:11', '2021-08-17 16:54:11', 1);
INSERT INTO `ports` (`p_id`, `port_name`, `info`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (8, 'Accra, Ghana', '', 0, '2021-09-09 15:26:01', '2021-10-23 15:32:01', 1);
INSERT INTO `ports` (`p_id`, `port_name`, `info`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (9, 'Monrovia, Liberia', '', 0, '2021-09-09 15:26:22', '2021-10-23 15:32:13', 1);
INSERT INTO `ports` (`p_id`, `port_name`, `info`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (10, 'Nouakchott, Mauritania', '', 0, '2021-09-09 15:26:43', '2021-10-23 15:32:25', 1);
INSERT INTO `ports` (`p_id`, `port_name`, `info`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (11, 'Sohar, Oman', '', 0, '2021-09-09 15:27:06', '2021-10-23 15:32:38', 1);
INSERT INTO `ports` (`p_id`, `port_name`, `info`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (12, 'Salalah, Oman', '', 0, '2021-09-09 15:27:18', '2021-10-23 15:32:48', 1);
INSERT INTO `ports` (`p_id`, `port_name`, `info`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (13, 'Busan, South Korea', '', 0, '2021-09-09 15:27:45', '2021-10-23 15:32:59', 1);
INSERT INTO `ports` (`p_id`, `port_name`, `info`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (14, 'Mombasa, Kenya', '', 0, '2021-10-23 13:26:35', '2021-10-23 13:26:35', 1);
INSERT INTO `ports` (`p_id`, `port_name`, `info`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (15, 'Rotterdam, The Netherlands', '', 0, '2021-10-25 18:13:52', '2021-10-25 18:13:52', 1);
INSERT INTO `ports` (`p_id`, `port_name`, `info`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (16, 'Pointe Noire, Congo', '', 0, '2021-10-28 16:09:44', '2021-10-28 16:09:44', 1);
INSERT INTO `ports` (`p_id`, `port_name`, `info`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (17, 'Mundra, India', '', 0, '2021-10-28 16:26:20', '2021-10-28 16:26:20', 1);
INSERT INTO `ports` (`p_id`, `port_name`, `info`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (18, 'Pipavav, India', '', 0, '2021-10-28 16:26:34', '2021-10-28 16:26:34', 1);


#
# TABLE STRUCTURE FOR: products
#

DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `pr_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(150) NOT NULL,
  `scientific_name` varchar(220) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`pr_id`),
  KEY `prod_usr_fr` (`user_id`),
  CONSTRAINT `prod_usr_fr` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf16;

INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (1, 'TILAPIA WHOLE', 'OREOCHROMIS NILOTICUS', 1, '2021-08-04 17:26:34', '2021-10-27 13:21:04', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (2, 'Jack Mackerel', 'Trachurus Spp', 1, '2021-08-04 17:26:34', '2021-10-27 13:20:39', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (3, 'FISH TUNA IN OIL CANNED', 'KATSUWONUS PELAMIS', 1, '2021-08-04 17:26:34', '2021-10-27 13:21:39', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (4, 'Fish Merluza ', 'Merluccius Senegalensis', 1, '2021-08-04 17:26:34', '2021-08-04 17:26:34', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (5, 'Horse Mackerel ', 'Trachurus Trachurus', 1, '2021-08-04 17:26:34', '2021-08-04 17:26:34', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (6, 'Grey mullet', 'Mugil Cephalus', 1, '2021-08-04 17:26:34', '2021-08-04 17:26:34', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (7, 'Nile Perch Fillet Skinless IWP TZ', 'Lates Niloticus', 1, '2021-08-04 17:26:34', '2021-08-04 17:26:34', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (8, 'Bonito ', 'Sarda Sarda', 1, '2021-08-04 17:26:34', '2021-08-04 17:26:34', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (9, 'Mackerel Whole ', 'Scomber Scombrus', 1, '2021-08-04 17:26:34', '2021-08-04 17:26:34', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (10, 'Sardine Whole Round ', 'Sardina Pilchardus ', 1, '2021-08-04 17:26:34', '2021-08-04 17:26:34', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (11, 'Pargo', 'Pagellus bellottii', 1, '2021-08-04 17:26:34', '2021-08-04 17:26:34', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (12, 'Dentex', 'Dentex Angolensis', 1, '2021-08-04 17:26:34', '2021-08-04 17:26:34', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (13, 'Sardinella Eba', 'Sardinella Maderensis', 1, '2021-08-04 17:26:34', '2021-08-04 17:26:34', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (14, 'Sardinella Aurita', 'Sardinella Aurita', 1, '2021-08-04 17:26:34', '2021-08-04 17:26:34', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (15, 'Liche', 'Canpogramma Glaycos', 1, '2021-08-04 17:26:34', '2021-08-04 17:26:34', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (16, 'Croaker', 'Johnius Spp', 1, '2021-08-04 17:26:34', '2021-08-04 17:26:34', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (17, 'Pacific Herring', 'CLUPEA PALLASII', 1, '2021-08-04 17:26:34', '2021-08-04 17:26:34', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (18, 'Yellow Tail Scad', 'Atule Mate', 1, '2021-09-09 15:23:41', '2021-09-09 15:23:41', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (19, 'Japanese Yellow Tail', 'SERIOLA QUINQUERADIATA', 1, '2021-10-20 19:45:05', '2021-10-20 19:45:05', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (20, 'Pacific Mackerel', 'Scomber Japonicus', 1, '2021-10-22 15:35:52', '2021-10-22 15:35:52', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (21, 'Baltic Sprats', 'Spratus Spratus', 1, '2021-10-25 18:22:09', '2021-10-25 18:22:09', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (22, 'Frigate Tuna', '', 1, '2021-10-27 11:49:26', '2021-10-27 11:49:26', 1);
INSERT INTO `products` (`pr_id`, `product_name`, `scientific_name`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (23, 'Cat Fish', 'Arius Spp', 1, '2021-10-27 13:19:49', '2021-10-27 13:19:49', 1);


#
# TABLE STRUCTURE FOR: proforma_invoices
#

DROP TABLE IF EXISTS `proforma_invoices`;

CREATE TABLE `proforma_invoices` (
  `pi_id` int(11) NOT NULL AUTO_INCREMENT,
  `pi_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pi_date` date NOT NULL,
  `offer` int(11) NOT NULL,
  `sold_to_party` int(11) NOT NULL,
  `consignee_name` int(11) NOT NULL,
  `destination_port` int(11) NOT NULL,
  `port_of_shipment` int(11) NOT NULL,
  `footer_contract` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`pi_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: remark1_offer_validity
#

DROP TABLE IF EXISTS `remark1_offer_validity`;

CREATE TABLE `remark1_offer_validity` (
  `rov_id` int(11) NOT NULL AUTO_INCREMENT,
  `remark` varchar(299) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`rov_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf16;

INSERT INTO `remark1_offer_validity` (`rov_id`, `remark`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (1, 'Offer Valid for 5 Days', 1, '2021-08-14 10:08:44', '2021-08-14 10:08:44', 1);
INSERT INTO `remark1_offer_validity` (`rov_id`, `remark`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (2, 'Offer Valid for 10 Days', 1, '2021-08-14 10:08:44', '2021-08-14 10:08:44', 1);
INSERT INTO `remark1_offer_validity` (`rov_id`, `remark`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (3, 'Offer Valid for 2 Days', 0, '2021-08-17 15:52:19', '2021-08-17 15:52:19', 1);
INSERT INTO `remark1_offer_validity` (`rov_id`, `remark`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (4, 'Offer Valid for 3 Days', 0, '2021-08-17 15:52:31', '2021-08-17 15:52:31', 1);
INSERT INTO `remark1_offer_validity` (`rov_id`, `remark`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (5, 'Offer Valid for 7 Days', 0, '2021-08-17 15:52:42', '2021-08-17 15:52:42', 1);
INSERT INTO `remark1_offer_validity` (`rov_id`, `remark`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (6, 'Offer is Subject to Sale', 0, '2021-08-17 17:47:15', '2021-08-17 17:47:15', 1);
INSERT INTO `remark1_offer_validity` (`rov_id`, `remark`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (7, 'First In First Out', 0, '2021-08-17 17:48:10', '2021-08-17 17:48:10', 1);
INSERT INTO `remark1_offer_validity` (`rov_id`, `remark`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (8, 'Offer Subject to Highest Bid', 0, '2021-08-17 17:47:48', '2021-08-17 17:47:48', 1);


#
# TABLE STRUCTURE FOR: responsible_logistic
#

DROP TABLE IF EXISTS `responsible_logistic`;

CREATE TABLE `responsible_logistic` (
  `responsible_logistic_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `information` varchar(255) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`responsible_logistic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `responsible_logistic` (`responsible_logistic_id`, `name`, `information`, `user_id`, `status`, `created_at`, `modified_at`) VALUES (2, 'fdffd', NULL, 1, 1, '2022-02-19 06:41:01', '2022-02-19 06:41:01');


#
# TABLE STRUCTURE FOR: responsible_purchase
#

DROP TABLE IF EXISTS `responsible_purchase`;

CREATE TABLE `responsible_purchase` (
  `responsible_purchase_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `information` varchar(255) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`responsible_purchase_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `responsible_purchase` (`responsible_purchase_id`, `name`, `information`, `user_id`, `status`, `created_at`, `modified_at`) VALUES (2, 'sds', 'ssd', 1, 1, '2022-02-19 06:05:53', '2022-02-19 06:09:14');


#
# TABLE STRUCTURE FOR: responsible_sales
#

DROP TABLE IF EXISTS `responsible_sales`;

CREATE TABLE `responsible_sales` (
  `responsible_sales_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `information` varchar(255) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`responsible_sales_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `responsible_sales` (`responsible_sales_id`, `name`, `information`, `user_id`, `status`, `created_at`, `modified_at`) VALUES (1, 'dsd', NULL, 1, 1, '2022-02-19 06:35:56', '2022-02-19 06:35:56');


#
# TABLE STRUCTURE FOR: sell_price_details
#

DROP TABLE IF EXISTS `sell_price_details`;

CREATE TABLE `sell_price_details` (
  `spd_id` int(11) NOT NULL AUTO_INCREMENT,
  `sp_id` int(11) NOT NULL,
  `offer_id` int(11) NOT NULL,
  `od_id` int(11) NOT NULL,
  `country_id` int(11) DEFAULT NULL,
  `am_id` int(11) DEFAULT NULL,
  `currency_id` int(11) NOT NULL,
  `exchange_rate` double NOT NULL,
  `operator` varchar(22) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`spd_id`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf16;

INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (26, 0, 127, 85, 81, 38, 2, '1', '/', 1, '2022-04-04 13:31:30', '2022-04-04 13:31:30', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (30, 0, 135, 95, 0, 37, 2, '1.16', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (31, 0, 134, 94, 0, 37, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (32, 0, 133, 93, 58, 0, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (33, 0, 143, 121, 58, 0, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (35, 0, 143, 121, 160, 0, 11, '0.86061735', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (36, 0, 143, 121, 0, 38, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (37, 0, 143, 121, 0, 37, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (38, 0, 192, 283, 2, 0, 1, '30', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (44, 0, 193, 284, 1, 37, 6, '700', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (47, 0, 194, 285, 44, 0, 2, '5', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (48, 0, 195, 286, 0, 37, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (49, 0, 195, 286, 0, 38, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (50, 0, 198, 290, 162, 0, 53, '2.33', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (51, 0, 198, 289, 162, 0, 53, '2.33', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (52, 0, 199, 291, 81, 0, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (53, 0, 199, 291, 81, 42, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (54, 0, 199, 291, 81, 37, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (56, 0, 199, 292, 81, 0, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (57, 0, 199, 292, 81, 42, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (58, 0, 199, 293, 81, 0, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (59, 0, 199, 293, 81, 42, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (60, 0, 200, 294, 81, 37, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (61, 0, 200, 294, 81, 38, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (62, 0, 200, 295, 0, 37, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (63, 0, 200, 295, 0, 38, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (64, 296, 194, 296, 44, 0, 2, '5', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (68, 305, 213, 305, 81, 38, 6, '1.1495845', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (69, 305, 213, 305, 37, 39, 11, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (71, 306, 214, 306, 37, 39, 11, '1.13', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (72, 307, 214, 307, 37, 39, 11, '1.13', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (73, 306, 214, 306, 37, 0, 11, '1.13', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (74, 307, 214, 307, 37, 0, 11, '1.13', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (75, 308, 214, 308, 37, 39, 11, '1.13', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (76, 309, 214, 309, 37, 39, 11, '1.13', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (77, 308, 214, 308, 37, 0, 11, '1.13', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (78, 309, 214, 309, 37, 0, 11, '1.13', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (79, 310, 215, 310, 120, 0, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (89, 310, 215, 310, 0, 38, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (90, 311, 215, 311, 120, 0, 2, '1', '/', 1, '2022-04-02 14:44:55', '2022-04-02 14:44:55', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (91, 311, 215, 311, 0, 38, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (93, 319, 221, 319, 37, 0, 11, '0.9', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (94, 322, 221, 322, 37, 0, 11, '0.9', '/', 1, '2022-04-02 14:44:27', '2022-04-02 14:44:27', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (96, 323, 221, 323, 37, 0, 30, '0.9', '/', 1, '2022-04-02 14:44:45', '2022-04-02 14:44:45', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (98, 319, 221, 319, 81, 0, 2, '1', '/', 1, '2022-04-02 14:43:00', '2022-04-02 14:43:00', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (99, 322, 221, 322, 81, 0, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (100, 323, 221, 323, 81, 0, 2, '1', '/', 1, '2022-04-02 14:45:02', '2022-04-02 14:45:02', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (105, 321, 221, 321, 37, 0, 11, '0.9', '/', 1, '2022-04-02 13:36:54', '2022-04-02 13:36:54', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (106, 321, 221, 321, 81, 0, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (107, 321, 221, 321, 162, 0, 2, '1', '/', 1, '2022-04-02 13:43:55', '2022-04-02 13:43:55', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (108, 321, 221, 321, 162, 0, 2, '5', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 0);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (112, 72, 221, 331, 37, 0, 11, '0.9', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 1);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (113, 72, 221, 331, 81, 0, 2, '1', '/', 1, '2022-04-02 17:56:06', '2022-04-02 17:56:06', 1);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (115, 73, 221, 331, 37, 0, 11, '0.9', '/', 1, '2022-04-02 17:57:16', '2022-04-02 17:57:16', 1);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (116, 73, 221, 331, 81, 0, 2, '1', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 1);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (117, 73, 221, 331, 162, 0, 2, '1', '/', 1, '2022-04-02 17:57:16', '2022-04-02 17:57:16', 1);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (119, 75, 221, 332, 37, 0, 11, '0.9', '/', 1, '2022-04-04 13:32:01', '2022-04-04 13:32:01', 1);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (120, 75, 221, 332, 81, 0, 2, '1', '/', 1, '2022-04-03 16:22:27', '2022-04-03 16:22:27', 1);
INSERT INTO `sell_price_details` (`spd_id`, `sp_id`, `offer_id`, `od_id`, `country_id`, `am_id`, `currency_id`, `exchange_rate`, `operator`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (121, 333, 221, 333, 44, 0, 2, '12', '/', 1, '2022-04-04 13:44:52', '2022-04-04 13:44:52', 1);


#
# TABLE STRUCTURE FOR: selling_price
#

DROP TABLE IF EXISTS `selling_price`;

CREATE TABLE `selling_price` (
  `sp_id` int(11) NOT NULL AUTO_INCREMENT,
  `od_id` int(11) NOT NULL,
  `selling_incoterm_id` int(11) NOT NULL,
  `country_id` int(11) DEFAULT NULL COMMENT 'all countries are taken',
  `currency_id` int(11) DEFAULT NULL,
  `am_id` varchar(120) DEFAULT NULL COMMENT 'all clients are talen',
  `li_id` int(11) DEFAULT NULL COMMENT 'line_items',
  `other_price` double DEFAULT NULL,
  `other_price_comment` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `li_id2` int(11) NOT NULL,
  `other_price2` double NOT NULL,
  `other_price_comment2` varchar(255) NOT NULL,
  `li_id3` int(11) NOT NULL,
  `other_price3` double NOT NULL,
  `other_price_comment3` varchar(255) NOT NULL,
  `li_id4` int(11) NOT NULL,
  `other_price4` double NOT NULL,
  `other_price_comment4` varchar(255) NOT NULL,
  `freight` double DEFAULT NULL,
  `margin_flat` double NOT NULL,
  `margin_percentage` double NOT NULL,
  `final_selling_price` double NOT NULL,
  `mar_selling_rate` double NOT NULL,
  `mar_selling_status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 = not sent to approve',
  `mar_selling_approval_status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 = not approved',
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`sp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf16;

INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (12, 85, 3, NULL, NULL, '', 8, '2', '', 0, '0', '', 0, '0', '', 0, '0', '', '0', '93.01', '6.55', '1420', '1410', 0, 1, 1, '2021-10-22 17:47:20', '2021-11-23 19:19:48', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (14, 95, 3, NULL, NULL, '', NULL, '0', '', 0, '0', '', 0, '0', '', 0, '0', '', '0.2', '0', '0', '0.8', '0', 0, 0, 1, '2021-10-23 16:03:39', '2021-10-23 16:07:27', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (15, 94, 3, NULL, NULL, '', 0, '0', '', 0, '0', '', 0, '0', '', 0, '0', '', '0.1', '0.02', '1.43', '1.4000000000000001', '0', 0, 0, 1, '2021-10-23 16:13:47', '2021-10-23 16:13:47', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (16, 93, 2, NULL, NULL, '', 0, '0', '', 0, '0', '', 0, '0', '', 0, '0', '', '0', '0.1', '1.45', '6.8999999999999995', '0', 0, 0, 1, '2021-10-23 16:19:46', '2021-10-23 16:19:46', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (17, 121, 2, NULL, NULL, '', 0, '0', '', 0, '0', '', 0, '0', '', 0, '0', '', '0', '0.25', '3.6', '6.95', '0', 0, 0, 1, '2021-10-26 19:32:26', '2021-10-26 19:32:26', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (18, 121, 3, NULL, NULL, '', 8, '0', '', 0, '0', '', 0, '0', '', 0, '0', '', '0', '0.3', '4.26', '7.05', '0', 0, 0, 1, '2021-10-27 19:00:41', '2021-10-27 19:04:13', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (19, 121, 2, NULL, NULL, '', 8, '0', '', 0, '0', '', 0, '0', '', 0, '0', '', '0', '0.3', '4.29', '7', '0', 0, 0, 1, '2021-10-27 19:03:48', '2021-10-27 19:05:57', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (20, 150, 1, NULL, NULL, '', 4, '75', '', 0, '0', '', 0, '0', '', 0, '0', '', '100', '100', '24.93', '401.15', '0', 0, 0, 1, '2021-11-02 13:18:09', '2021-11-02 13:18:09', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (21, 150, 1, NULL, NULL, '', 5, '85', '', 0, '0', '', 0, '0', '', 0, '0', '', '100', '100', '24.93', '401.15', '0', 0, 0, 1, '2021-11-02 13:18:44', '2021-11-02 13:19:10', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (22, 149, 4, NULL, NULL, '', 0, '10', '', 3, '47', '', 0, '0', '', 0, '0', '', '25', '20', '9.85', '203.05', '0', 0, 0, 1, '2021-11-02 13:23:49', '2021-11-02 13:23:49', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (24, 284, 2, NULL, NULL, '', 0, '0', '', 0, '0', '', 0, '0', '', 0, '0', '', '20', '391.11', '10', '3520', '2462000', 0, 1, 1, '2021-11-06 12:13:06', '2021-11-06 12:33:45', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (25, 285, 3, NULL, NULL, '', 3, '10', '', 5, '20', '', 6, '50', '', 0, '0', '', '100', '50', '18.52', '270', '1500', 0, 1, 1, '2021-11-10 18:59:59', '2021-11-10 19:05:35', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (26, 286, 2, NULL, NULL, '', 0, '20', '', 11, '50', '', 0, '0', '', 0, '0', '', '150', '9', '5', '220.925', '0', 0, 0, 1, '2021-11-23 21:22:28', '2021-11-23 21:22:28', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (27, 286, 3, NULL, NULL, '', 0, '20', '', 11, '70', '', 0, '0', '', 0, '0', '', '150', '18.99', '10', '220.925', '0', 0, 0, 1, '2021-11-23 21:23:00', '2021-11-23 21:23:00', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (28, 290, 1, NULL, NULL, '', 4, '200', '', 5, '100', '', 8, '50', '', 0, '0', '', '50', '50', '10', '628.11', '650.11', 0, 1, 1, '2021-12-16 11:41:13', '2021-12-16 11:56:55', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (29, 289, 2, NULL, NULL, '', 5, '200', '', 0, '0', '', 0, '0', '', 0, '0', '', '150', '100', '14.29', '700', '0', 0, 0, 1, '2021-12-16 11:46:22', '2021-12-16 11:46:22', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (30, 291, 3, NULL, NULL, '', 3, '0.02', '', 0, '0', '', 0, '0', '', 0, '0', '', '0', '0.54', '30', '1.27', '0', 0, 0, 1, '2022-02-08 13:28:07', '2022-02-08 13:28:07', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (31, 291, 3, NULL, NULL, '', 3, '0.02', '', 2, '0.03', '', 0, '0', '', 0, '0', '', '0', '0.54', '30', '1.27', '0', 0, 0, 1, '2022-02-08 13:31:48', '2022-02-08 13:31:48', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (32, 292, 3, NULL, NULL, '', 3, '0.02', '', 0, '0', '', 0, '0', '', 0, '0', '', '0', '0.74', '30', '0', '0', 0, 0, 1, '2022-02-08 13:43:37', '2022-02-08 13:43:37', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (33, 292, 3, NULL, NULL, '', 3, '0.02', '', 2, '0.03', '', 0, '0', '', 0, '0', '', '0', '0.74', '30', '0', '0', 0, 0, 1, '2022-02-08 13:44:07', '2022-02-08 13:44:07', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (34, 293, 3, NULL, NULL, '', 3, '0.02', '', 0, '0', '', 0, '0', '', 0, '0', '', '0', '0.78', '30', '0', '0', 0, 0, 1, '2022-02-08 13:45:11', '2022-02-08 13:45:11', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (35, 293, 3, NULL, NULL, '', 3, '0.02', '', 2, '0.03', '', 0, '0', '', 0, '0', '', '0', '0.78', '30', '0', '0', 0, 0, 1, '2022-02-08 13:45:36', '2022-02-08 13:45:36', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (36, 294, 3, NULL, NULL, '', 3, '0.02', 'Inspection Cost at Origin', 15, '0.03', 'Commission', 0, '0', '', 0, '0', '', '0', '675.03', '30', '0', '0', 0, 0, 1, '2022-03-02 19:59:42', '2022-03-02 19:59:42', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (37, 295, 3, NULL, NULL, '', 3, '0.05', '', 15, '0.03', '', 0, '0', '', 0, '0', '', '0', '803.61', '30', '1875.1299999999999', '0', 0, 0, 1, '2022-03-02 20:05:27', '2022-03-02 20:05:27', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (38, 296, 1, NULL, NULL, '', 0, '2', 'na', 10, '2', 'na', 0, '2', 'na', 0, '2', 'na', '12', '3.37', '5', '73.37', '0', 0, 0, 1, '2022-03-16 12:34:33', '2022-03-16 12:34:33', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (41, 305, 3, NULL, NULL, '', NULL, '0', 'cma ', 0, '5', 'covered by us', 0, '0', '', 0, '0', '', '122', '30', '12.63', '722', '0', 0, 0, 1, '2022-03-22 19:38:12', '2022-03-22 19:38:12', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (42, 306, 3, NULL, NULL, '', 8, '0.0044247787610619', '', 0, '0', '', 0, '0', '', 0, '0', '', '0.2300884955752212', '0.04', '3.9', '1.0245132743363', '0', 0, 0, 1, '2022-03-26 01:13:35', '2022-03-26 01:18:01', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (43, 307, 3, NULL, NULL, '', 8, '0.0044247787610619', '', 0, '0', '', 0, '0', '', 0, '0', '', '0.2300884955752212', '0.04', '3.9', '1.0245132743363', '0', 0, 0, 1, '2022-03-26 01:20:20', '2022-03-26 01:20:20', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (44, 308, 3, NULL, NULL, '', 8, '0.0044247787610619', '', 0, '0', '', 0, '0', '', 0, '0', '', '0.2300884955752212', '0.04', '3.9', '1.0245132743363', '0', 0, 0, 1, '2022-03-26 01:20:27', '2022-03-26 01:20:27', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (45, 309, 3, NULL, NULL, '', 8, '0.0044247787610619', '', 0, '0', '', 0, '0', '', 0, '0', '', '0.2300884955752212', '0.04', '3.9', '1.0245132743363', '0', 0, 0, 1, '2022-03-26 01:20:33', '2022-03-26 01:20:33', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (46, 310, 3, NULL, NULL, '', 8, '5', '', 0, '0', '', 0, '0', '', 0, '0', '', '0', '45', '3.1', '1450', '0', 0, 0, 1, '2022-03-26 10:41:50', '2022-03-26 10:42:31', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (47, 311, 3, NULL, NULL, '', 8, '5', '', 0, '0', '', 0, '0', '', 0, '0', '', '0', '45', '3.1', '1450', '0', 0, 0, 1, '2022-03-26 10:43:30', '2022-03-26 10:43:30', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (49, 310, 3, NULL, NULL, '', 8, '5', '', 0, '0', '', 0, '0', '', 0, '0', '', '0', '70', '4.75', '1475', '0', 0, 0, 1, '2022-03-28 13:13:34', '2022-03-28 13:13:34', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (50, 310, 3, NULL, NULL, '', 8, '5', '', 0, '0', '', 0, '0', '', 0, '0', '', '0', '100', '6.64', '1505', '0', 0, 0, 1, '2022-03-28 13:18:59', '2022-03-28 13:18:59', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (52, 311, 3, NULL, NULL, '', 8, '5', '', 0, '0', '', 0, '0', '', 0, '0', '', '0', '70', '4.75', '1475', '0', 0, 0, 1, '2022-03-28 13:41:01', '2022-03-28 13:41:01', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (53, 311, 3, NULL, NULL, '', 8, '5', '', 0, '0', '', 0, '0', '', 0, '0', '', '0', '100', '6.64', '1505', '0', 0, 0, 1, '2022-03-28 13:41:01', '2022-03-28 13:41:01', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (57, 312, 3, NULL, NULL, '', 8, '5', '', 0, '0', '', 0, '0', '', 0, '0', '', '0', '45', '3.1', '1350', '0', 0, 0, 1, '2022-03-28 13:46:54', '2022-03-28 14:47:16', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (58, 312, 3, NULL, NULL, '', 8, '5', '', 0, '0', '', 0, '0', '', 0, '0', '', '0', '70', '4.75', '1375', '0', 0, 0, 1, '2022-03-28 13:46:54', '2022-03-28 14:47:09', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (59, 312, 3, NULL, NULL, '', 8, '5', '', 0, '0', '', 0, '0', '', 0, '0', '', '0', '100', '6.64', '1405', '0', 0, 0, 1, '2022-03-28 13:46:54', '2022-03-28 14:47:20', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (60, 319, 3, NULL, NULL, '', 8, '5', '', 0, '7', '', 0, '3', '', 0, '0', '', '125', '25', '3.45', '725', '0', 0, 0, 1, '2022-03-30 14:34:40', '2022-03-30 14:36:15', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (61, 321, 3, NULL, NULL, '', 8, '5', '', 0, '7', '', 0, '3', '', 0, '0', '', '125', '25', '3.45', '725', '1', 0, 0, 1, '2022-03-30 14:48:40', '2022-04-02 12:50:56', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (62, 322, 3, NULL, NULL, '', 8, '5', '', 0, '7', '', 0, '3', '', 0, '0', '', '125', '25', '3.45', '1450', '0', 0, 0, 1, '2022-03-30 14:48:45', '2022-03-30 14:52:23', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (63, 323, 3, NULL, NULL, '', 8, '5', '', 0, '7', '', 0, '3', '', 0, '0', '', '125', '25', '3.45', '725', '0', 0, 0, 1, '2022-03-30 14:48:49', '2022-03-30 14:48:49', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (64, 321, 2, NULL, NULL, '', 11, '2', '', 14, '5', '', 15, '3', '', 14, '12', '', '0', '0', '0', '612', '0', 0, 0, 1, '2022-04-02 13:21:01', '2022-04-02 13:21:01', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (65, 330, 3, NULL, NULL, '', 8, '5', '', 0, '7', '', 0, '3', '', 0, '0', '', '125', '25', '3.45', '725', '0', 0, 0, 1, '2022-04-02 14:59:25', '2022-04-02 14:59:25', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (72, 331, 3, NULL, NULL, '', 8, '5', '', 0, '7', '', 0, '3', '', 0, '0', '', '125', '25', '3.45', '725', '0', 0, 0, 1, '2022-04-02 17:56:06', '2022-04-02 17:56:06', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (73, 331, 3, NULL, NULL, '', 8, '5', '', 0, '7', '', 0, '3', '', 0, '0', '', '125', '25', '3.45', '725', '1', 0, 0, 1, '2022-04-02 17:57:16', '2022-04-02 17:57:16', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (74, 331, 2, NULL, NULL, '', 11, '2', '', 14, '5', '', 15, '3', '', 14, '12', '', '0', '0', '0', '612', '0', 0, 0, 1, '2022-04-02 17:57:16', '2022-04-02 17:57:16', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (75, 332, 3, NULL, NULL, '', 8, '5', '', 0, '7', '', 0, '3', '', 0, '0', '', '125', '25', '3.45', '725', '0', 0, 0, 1, '2022-04-03 16:22:27', '2022-04-03 16:22:27', 1);
INSERT INTO `selling_price` (`sp_id`, `od_id`, `selling_incoterm_id`, `country_id`, `currency_id`, `am_id`, `li_id`, `other_price`, `other_price_comment`, `li_id2`, `other_price2`, `other_price_comment2`, `li_id3`, `other_price3`, `other_price_comment3`, `li_id4`, `other_price4`, `other_price_comment4`, `freight`, `margin_flat`, `margin_percentage`, `final_selling_price`, `mar_selling_rate`, `mar_selling_status`, `mar_selling_approval_status`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (76, 333, 2, NULL, NULL, '', 11, '12', 'It is a long established fact that a reader will be distracted', 0, '5', 'It is a long established fact that a reader will be distracted', 0, '7', 'It is a long established fact that a reader will be distracted', 0, '8', 'It is a long established fact that a reader will be distracted', '2', '12', '1.43', '841', '0', 0, 0, 1, '2022-04-04 13:43:20', '2022-04-04 13:44:18', 1);


#
# TABLE STRUCTURE FOR: sizes
#

DROP TABLE IF EXISTS `sizes`;

CREATE TABLE `sizes` (
  `size_id` int(11) NOT NULL AUTO_INCREMENT,
  `size` varchar(120) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `information` varchar(300) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`size_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf16;

INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (3, '200-400', 10, '', 1, '2021-08-04 19:16:53', '2021-08-12 16:12:04', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (4, '200-500', 10, '', 0, '2021-08-12 16:12:18', '2021-08-12 16:12:18', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (5, '300-500', 10, '', 0, '2021-08-12 16:12:32', '2021-08-12 16:12:32', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (6, '400-600', 10, '', 0, '2021-08-12 16:12:43', '2021-08-12 16:12:43', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (7, '500', 10, '', 0, '2021-08-12 16:12:56', '2021-08-12 16:12:56', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (8, '600-800', 10, '', 0, '2021-08-12 16:13:32', '2021-08-12 16:13:32', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (9, '800-1000', 10, '', 0, '2021-08-12 16:13:41', '2021-08-12 16:13:41', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (10, '<1 Kg', 9, '', 0, '2021-08-17 15:54:07', '2021-08-17 15:54:07', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (11, '200-300', 10, '', 0, '2021-09-09 15:33:41', '2021-09-09 15:33:41', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (12, '50-100', 10, '', 0, '2021-09-09 15:34:02', '2021-09-09 15:34:02', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (13, '100-200', 10, '', 0, '2021-09-09 15:34:15', '2021-09-09 15:34:15', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (14, '300-400', 10, '', 0, '2021-09-09 15:34:40', '2021-09-09 15:34:40', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (15, '500-1000', 10, '', 0, '2021-09-09 15:35:09', '2021-09-09 15:35:09', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (16, '<500', 10, '', 0, '2021-09-09 15:36:02', '2021-09-09 15:36:02', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (17, '>500', 10, '', 0, '2021-09-09 15:36:34', '2021-09-09 15:36:34', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (18, '>1000', 10, '', 0, '2021-09-09 15:36:51', '2021-09-09 15:36:51', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (19, '2/4', 3, '', 0, '2021-09-09 15:37:14', '2021-09-09 15:37:14', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (20, '4/6', 3, '', 0, '2021-09-09 15:37:26', '2021-09-09 15:37:26', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (21, '6/8', 3, '', 0, '2021-09-09 15:37:37', '2021-09-09 15:37:37', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (22, '8/10', 3, '', 0, '2021-09-09 15:37:47', '2021-09-09 15:37:47', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (23, '8/12', 3, '', 0, '2021-09-09 15:37:58', '2021-09-09 15:37:58', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (24, '12/14', 3, '', 0, '2021-09-09 15:38:44', '2021-09-09 15:38:44', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (25, '12/15', 3, '', 0, '2021-09-09 15:38:58', '2021-09-09 15:38:58', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (26, '750-1000', 10, '', 0, '2021-10-23 12:10:43', '2021-10-23 12:10:43', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (27, '1200-1300', 10, '', 0, '2021-10-23 12:10:58', '2021-10-23 12:10:58', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (28, '250-350', 10, '', 0, '2021-10-23 12:11:10', '2021-10-23 12:11:10', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (29, '1-2 Kg', 9, '', 0, '2021-10-23 15:48:22', '2021-10-23 15:48:22', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (30, '2-3 Kg', 9, '', 0, '2021-10-23 15:48:47', '2021-10-23 15:48:47', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (31, '3 Kg Up', 9, '', 0, '2021-10-23 15:48:59', '2021-10-23 15:48:59', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (32, '7 CM +', 15, '', 0, '2021-10-25 18:22:55', '2021-10-25 18:22:55', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (33, '2500 3300', 10, '', 0, '2021-10-26 14:43:36', '2021-10-26 14:43:36', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (34, '3-5 Kg', 9, '', 0, '2021-10-27 16:49:20', '2021-10-27 16:49:20', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (35, '16 CM+', 15, '', 0, '2021-10-28 18:01:01', '2021-10-28 18:01:01', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (36, '18 CM+', 15, '', 0, '2021-10-28 18:01:16', '2021-10-28 18:01:16', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (37, '20 CM+', 15, '', 0, '2021-10-28 18:01:34', '2021-10-28 18:01:34', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (38, '25 CM+', 15, '', 0, '2021-10-28 18:01:51', '2021-10-28 18:01:51', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (39, '500-700', 10, '', 0, '2021-10-28 18:27:07', '2021-10-28 18:27:07', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (40, '700-1000', 10, '', 0, '2021-10-28 18:27:21', '2021-10-28 18:27:21', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (41, '1000-2000', 10, '', 0, '2021-10-28 18:27:52', '2021-10-28 18:27:52', 1);
INSERT INTO `sizes` (`size_id`, `size`, `unit_id`, `information`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (42, '400-1000', 10, '', 0, '2021-10-28 19:13:04', '2021-10-28 19:13:04', 1);


#
# TABLE STRUCTURE FOR: units
#

DROP TABLE IF EXISTS `units`;

CREATE TABLE `units` (
  `u_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(99) NOT NULL,
  `info` varchar(99) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modify_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `units` (`u_id`, `unit`, `info`, `status`, `user_id`, `create_date`, `modify_date`) VALUES (3, 'PCS', 'Pieces', 1, 1, '2020-04-05 13:58:30', '2021-08-12 16:00:48');
INSERT INTO `units` (`u_id`, `unit`, `info`, `status`, `user_id`, `create_date`, `modify_date`) VALUES (8, 'PAIR', '', 1, 1, '2021-02-20 11:07:57', '2021-02-20 11:07:57');
INSERT INTO `units` (`u_id`, `unit`, `info`, `status`, `user_id`, `create_date`, `modify_date`) VALUES (9, 'KG', 'Kilogram', 1, 1, '2021-03-23 11:55:58', '2021-08-12 16:00:30');
INSERT INTO `units` (`u_id`, `unit`, `info`, `status`, `user_id`, `create_date`, `modify_date`) VALUES (10, 'GM', 'Gram', 1, 1, '2021-03-23 11:56:06', '2021-08-12 16:00:12');
INSERT INTO `units` (`u_id`, `unit`, `info`, `status`, `user_id`, `create_date`, `modify_date`) VALUES (12, 'MT', 'Metric Ton', 1, 1, '2021-04-04 10:03:27', '2021-04-04 10:03:27');
INSERT INTO `units` (`u_id`, `unit`, `info`, `status`, `user_id`, `create_date`, `modify_date`) VALUES (15, 'CM', 'Centimeter', 1, 1, '2021-08-12 16:03:04', '2021-08-12 16:03:04');


#
# TABLE STRUCTURE FOR: user_change_mails
#

DROP TABLE IF EXISTS `user_change_mails`;

CREATE TABLE `user_change_mails` (
  `cm_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `otp` varchar(99) DEFAULT NULL,
  `new_email` varchar(99) DEFAULT NULL,
  `used` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`cm_id`),
  KEY `user_change_mails_ibfk_1` (`user_id`),
  CONSTRAINT `user_change_mails_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `user_change_mails` (`cm_id`, `user_id`, `otp`, `new_email`, `used`) VALUES (1, 1, 'CM6119286854D26', 'saby@seafoodmiddleeast.com', 0);


#
# TABLE STRUCTURE FOR: user_details
#

DROP TABLE IF EXISTS `user_details`;

CREATE TABLE `user_details` (
  `ud_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `firstname` varchar(99) DEFAULT NULL,
  `lastname` varchar(99) DEFAULT NULL,
  `contact` varchar(30) DEFAULT NULL,
  `img` varchar(999) DEFAULT NULL,
  PRIMARY KEY (`ud_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_details_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

INSERT INTO `user_details` (`ud_id`, `user_id`, `firstname`, `lastname`, `contact`, `img`) VALUES (1, 1, 'Mr.', 'Trader', '+971501551059', '0bec25e568078e01afe2dcd48050d79b.jpg');
INSERT INTO `user_details` (`ud_id`, `user_id`, `firstname`, `lastname`, `contact`, `img`) VALUES (14, 31, 'Saby', '', '0501551059', NULL);
INSERT INTO `user_details` (`ud_id`, `user_id`, `firstname`, `lastname`, `contact`, `img`) VALUES (15, 32, 'Brian', '', '0501256110', NULL);
INSERT INTO `user_details` (`ud_id`, `user_id`, `firstname`, `lastname`, `contact`, `img`) VALUES (16, 33, 'Saby', '', '0501551059', NULL);
INSERT INTO `user_details` (`ud_id`, `user_id`, `firstname`, `lastname`, `contact`, `img`) VALUES (17, 34, 'Brian', '', '0501256110', NULL);
INSERT INTO `user_details` (`ud_id`, `user_id`, `firstname`, `lastname`, `contact`, `img`) VALUES (18, 35, 'Saby', 'Dutt', '0501551059', NULL);
INSERT INTO `user_details` (`ud_id`, `user_id`, `firstname`, `lastname`, `contact`, `img`) VALUES (25, 50, '', 'Raju', '', NULL);
INSERT INTO `user_details` (`ud_id`, `user_id`, `firstname`, `lastname`, `contact`, `img`) VALUES (26, 51, 'R', 'Das', '', NULL);
INSERT INTO `user_details` (`ud_id`, `user_id`, `firstname`, `lastname`, `contact`, `img`) VALUES (27, 52, 'Bipul', 'Samanta', '', NULL);
INSERT INTO `user_details` (`ud_id`, `user_id`, `firstname`, `lastname`, `contact`, `img`) VALUES (28, 53, 'Biswayan', '', '', NULL);
INSERT INTO `user_details` (`ud_id`, `user_id`, `firstname`, `lastname`, `contact`, `img`) VALUES (29, 56, 'Bishwayan', '', '', NULL);


#
# TABLE STRUCTURE FOR: user_logs
#

DROP TABLE IF EXISTS `user_logs`;

CREATE TABLE `user_logs` (
  `ul_id` int(11) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(100) NOT NULL,
  `pk_id` int(11) NOT NULL,
  `action_taken` enum('add','edit','delete','other') NOT NULL,
  `old_data` longtext NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ul_id`)
) ENGINE=MyISAM AUTO_INCREMENT=195 DEFAULT CHARSET=latin1;

INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (188, 'acc_master', 38, 'edit', '{\"name\":\"African Everest Limited Company\",\"am_code\":\"African Everest\",\"phone\":\"-\",\"email_id\":\"brian@fsmiddleeast.ae\",\"official_address\":\"<p>\\n\\tOfficial Address<\\/p>\\n\",\"shipping_address\":\"<p>\\n\\tShipping address<\\/p>\\n\",\"place_of_supply\":\"<p>\\n\\tSupply address<\\/p>\\n\",\"supplier_buyer\":\"1\",\"city\":\"Tema\",\"country_id\":\"81\",\"insured_amount\":\"\",\"credit_limit\":\"\",\"payment_term\":\"\",\"owner_name\":\"Mr. Robert Ocran\",\"owner_nationality\":\"\",\"owner_email\":\"\",\"manager_name\":\"\",\"manager_nationality\":\"\",\"manager_email\":\"\",\"status\":\"1\"}', 1, 'master', 1, '2021-11-29 17:20:28');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (186, 'offer_comments', 40, 'edit', '{\"offer_id\":\"193\",\"comment\":\"<p>\\n\\tsource country is not afganisthan is differennt almenia<\\/p>\\n\",\"action\":\"Solved\",\"resource_id\":\"1\",\"type\":\"comment\",\"status\":\"1\"}', 1, '-', 1, '2021-11-06 11:56:34');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (187, 'offer_comments', 42, 'edit', '{\"offer_id\":\"194\",\"comment\":\"<p>\\n\\tprice is 30 not 20<\\/p>\\n\",\"action\":\"Solved\",\"resource_id\":\"1\",\"type\":\"comment\",\"status\":\"1\"}', 1, '-', 1, '2021-11-10 18:26:17');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (184, 'offer_comments', 39, 'edit', '{\"offer_id\":\"193\",\"comment\":\"<p>\\n\\tchange rate 200 to 300<\\/p>\\n\",\"action\":\"Solved\",\"resource_id\":\"1\",\"type\":\"comment\",\"status\":\"1\"}', 1, '-', 1, '2021-11-06 11:46:23');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (185, 'offer_comments', 39, 'edit', '{\"offer_id\":\"193\",\"comment\":\"<p>\\n\\tchange rate 2000 to 3000<\\/p>\\n\",\"action\":\"Solved\",\"resource_id\":\"1\",\"type\":\"comment\",\"status\":\"1\"}', 1, '-', 1, '2021-11-06 11:56:09');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (183, 'acc_master', 82, 'edit', '{\"name\":\"raja\",\"am_code\":\"001\",\"phone\":\"\",\"email_id\":\"\",\"official_address\":\"\",\"shipping_address\":\"\",\"place_of_supply\":\"\",\"supplier_buyer\":\"0\",\"city\":\"\",\"country_id\":\"3\",\"insured_amount\":\"\",\"credit_limit\":\"\",\"payment_term\":\"\",\"owner_name\":\"\",\"owner_nationality\":\"\",\"owner_email\":\"\",\"manager_name\":\"\",\"manager_nationality\":\"\",\"manager_email\":\"\",\"status\":\"1\"}', 1, 'master', 1, '2021-11-05 15:56:58');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (180, 'products', 2, 'edit', '{\"product_name\":\"Jack Mackerel\",\"scientific_name\":\"Trachurus Spp\",\"status\":\"1\",\"user_id\":\"1\"}', 1, 'master', 1, '2021-10-27 13:20:39');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (181, 'products', 1, 'edit', '{\"product_name\":\"TILAPIA WHOLE\",\"scientific_name\":\"OREOCHROMIS NILOTICUS\",\"status\":\"1\",\"user_id\":\"1\"}', 1, 'master', 1, '2021-10-27 13:21:04');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (182, 'products', 3, 'edit', '{\"product_name\":\"FISH TUNA IN OIL CANNED\",\"scientific_name\":\"KATSUWONUS PELAMIS\",\"status\":\"1\",\"user_id\":\"1\"}', 1, 'master', 1, '2021-10-27 13:21:39');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (179, 'acc_master', 76, 'edit', '{\"name\":\"Marine Foods B.V.\",\"am_code\":\"Marine Foods Holland\",\"phone\":\"\",\"email_id\":\"\",\"official_address\":\"\",\"shipping_address\":\"\",\"place_of_supply\":\"\",\"supplier_buyer\":\"0\",\"city\":\"Scheveningen\",\"country_id\":\"150\",\"insured_amount\":\"\",\"credit_limit\":\"\",\"payment_term\":\"\",\"owner_name\":\"\",\"owner_nationality\":\"\",\"owner_email\":\"\",\"manager_name\":\"\",\"manager_nationality\":\"\",\"manager_email\":\"\",\"status\":\"1\"}', 1, 'master', 1, '2021-10-26 16:23:09');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (178, 'acc_master', 39, 'edit', '{\"name\":\"Congelcam SA\",\"am_code\":\"Congelcam\",\"phone\":\"-\",\"email_id\":\"saby@seafoodmiddleeast.com\",\"official_address\":\"\",\"shipping_address\":\"\",\"place_of_supply\":\"\",\"supplier_buyer\":\"1\",\"city\":\"Douala\",\"country_id\":\"37\",\"insured_amount\":\"\",\"credit_limit\":\"\",\"payment_term\":\"\",\"owner_name\":\"\",\"owner_nationality\":\"\",\"owner_email\":\"\",\"manager_name\":\"\",\"manager_nationality\":\"\",\"manager_email\":\"\",\"status\":\"1\"}', 1, 'master', 1, '2021-10-26 14:30:43');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (177, 'acc_master', 38, 'edit', '{\"name\":\"African Everest Limited Company\",\"am_code\":\"African Everest\",\"phone\":\"-\",\"email_id\":\"brian@fsmiddleeast.com\",\"official_address\":\"<p>\\n\\tOfficial Address<\\/p>\\n\",\"shipping_address\":\"<p>\\n\\tShipping address<\\/p>\\n\",\"place_of_supply\":\"<p>\\n\\tSupply address<\\/p>\\n\",\"supplier_buyer\":\"1\",\"city\":\"Tema\",\"country_id\":\"81\",\"insured_amount\":\"\",\"credit_limit\":\"\",\"payment_term\":\"\",\"owner_name\":\"Mr. Robert Ocran\",\"owner_nationality\":\"\",\"owner_email\":\"\",\"manager_name\":\"\",\"manager_nationality\":\"\",\"manager_email\":\"\",\"status\":\"1\"}', 1, 'master', 1, '2021-10-26 14:30:07');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (173, 'ports', 12, 'edit', '{\"port_name\":\"Salalah, Oman\",\"info\":\"\",\"status\":\"1\"}', 1, 'master', 1, '2021-10-23 15:32:48');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (174, 'ports', 13, 'edit', '{\"port_name\":\"Busan, South Korea\",\"info\":\"\",\"status\":\"1\"}', 1, 'master', 1, '2021-10-23 15:32:59');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (175, 'acc_master', 37, 'edit', '{\"name\":\"Trust Link Ventures Ltd\",\"am_code\":\"Trustlink\",\"phone\":\"-\",\"email_id\":\"saby@seafoodmiddleeast.com\",\"official_address\":\"\",\"shipping_address\":\"\",\"place_of_supply\":\"\",\"supplier_buyer\":\"1\",\"city\":\"Tema\",\"country_id\":\"81\",\"insured_amount\":\"\",\"credit_limit\":\"\",\"payment_term\":\"\",\"owner_name\":\"\",\"owner_nationality\":\"\",\"owner_email\":\"\",\"manager_name\":\"\",\"manager_nationality\":\"\",\"manager_email\":\"\",\"status\":\"1\"}', 1, 'master', 1, '2021-10-26 14:28:49');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (176, 'acc_master', 38, 'edit', '{\"name\":\"African Everest Limited Company\",\"am_code\":\"African Everest\",\"phone\":\"-\",\"email_id\":\"-\",\"official_address\":\"<p>\\n\\tOfficial Address<\\/p>\\n\",\"shipping_address\":\"<p>\\n\\tShipping address<\\/p>\\n\",\"place_of_supply\":\"<p>\\n\\tSupply address<\\/p>\\n\",\"supplier_buyer\":\"1\",\"city\":\"Tema\",\"country_id\":\"81\",\"insured_amount\":\"\",\"credit_limit\":\"\",\"payment_term\":\"\",\"owner_name\":\"Mr. Robert Ocran\",\"owner_nationality\":\"\",\"owner_email\":\"\",\"manager_name\":\"\",\"manager_nationality\":\"\",\"manager_email\":\"\",\"status\":\"1\"}', 1, 'master', 1, '2021-10-26 14:29:30');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (172, 'ports', 11, 'edit', '{\"port_name\":\"Sohar, Oman\",\"info\":\"\",\"status\":\"1\"}', 1, 'master', 1, '2021-10-23 15:32:38');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (168, 'offer_comments', 34, 'edit', '{\"offer_id\":\"125\",\"comment\":\"<p>\\n\\tSelect template<\\/p>\\n\",\"action\":\"Solved\",\"resource_id\":\"1\",\"type\":\"comment\",\"status\":\"0\"}', 1, '-', 1, '2021-10-20 11:27:47');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (169, 'ports', 8, 'edit', '{\"port_name\":\"Accra, Ghana\",\"info\":\"\",\"status\":\"1\"}', 1, 'master', 1, '2021-10-23 15:32:01');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (170, 'ports', 9, 'edit', '{\"port_name\":\"Monrovia, Liberia\",\"info\":\"\",\"status\":\"1\"}', 1, 'master', 1, '2021-10-23 15:32:13');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (171, 'ports', 10, 'edit', '{\"port_name\":\"Nouakchott, Mauritania\",\"info\":\"\",\"status\":\"1\"}', 1, 'master', 1, '2021-10-23 15:32:25');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (189, 'acc_master', 83, 'edit', '{\"name\":\"def\",\"am_code\":\"002\",\"phone\":\"123456789\",\"email_id\":\"pritamkhan936@gmail.com\",\"official_address\":\"\",\"shipping_address\":\"\",\"place_of_supply\":\"\",\"supplier_buyer\":\"1\",\"city\":\"\",\"country_id\":\"44\",\"insured_amount\":\"\",\"credit_limit\":\"\",\"payment_term\":\"\",\"owner_name\":\"\",\"owner_nationality\":\"\",\"owner_email\":\"\",\"manager_name\":\"\",\"manager_nationality\":\"\",\"manager_email\":\"\",\"status\":\"1\"}', 1, 'master', 1, '2022-03-16 12:26:04');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (190, 'acc_master', 83, 'edit', '{\"name\":\"def\",\"am_code\":\"002\",\"phone\":\"123456789\",\"email_id\":\"ratot63142@snece.com\",\"official_address\":\"\",\"shipping_address\":\"\",\"place_of_supply\":\"\",\"supplier_buyer\":\"1\",\"city\":\"\",\"country_id\":\"44\",\"insured_amount\":\"\",\"credit_limit\":\"\",\"payment_term\":\"\",\"owner_name\":\"\",\"owner_nationality\":\"\",\"owner_email\":\"\",\"manager_name\":\"\",\"manager_nationality\":\"\",\"manager_email\":\"\",\"status\":\"1\"}', 1, 'master', 1, '2022-03-16 12:36:18');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (191, 'acc_master', 39, 'edit', '{\"name\":\"Congelcam SA\",\"am_code\":\"Congelcam\",\"phone\":\"-\",\"email_id\":\"saby@seafoodmiddleeast.com; brian@fsmiddleeast.ae\",\"official_address\":\"\",\"shipping_address\":\"\",\"place_of_supply\":\"\",\"supplier_buyer\":\"1\",\"city\":\"Douala\",\"country_id\":\"37\",\"insured_amount\":\"\",\"credit_limit\":\"\",\"payment_term\":\"\",\"owner_name\":\"\",\"owner_nationality\":\"\",\"owner_email\":\"\",\"manager_name\":\"\",\"manager_nationality\":\"\",\"manager_email\":\"\",\"status\":\"1\"}', 1, 'master', 1, '2022-03-26 01:40:16');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (192, 'acc_master', 52, 'edit', '{\"name\":\"West Africa Enterprise INC\",\"am_code\":\"West Africa\",\"phone\":\"\",\"email_id\":\"saby@seafoodmiddleeast.com; brian@fsmiddleeast.ae\",\"official_address\":\"\",\"shipping_address\":\"\",\"place_of_supply\":\"\",\"supplier_buyer\":\"1\",\"city\":\"0\",\"country_id\":\"120\",\"insured_amount\":\"\",\"credit_limit\":\"\",\"payment_term\":\"\",\"owner_name\":\"\",\"owner_nationality\":\"\",\"owner_email\":\"\",\"manager_name\":\"\",\"manager_nationality\":\"\",\"manager_email\":\"\",\"status\":\"1\"}', 1, 'master', 1, '2022-03-26 10:48:48');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (193, 'acc_master', 38, 'edit', '{\"name\":\"African Everest Limited Company\",\"am_code\":\"African Everest\",\"phone\":\"-\",\"email_id\":\"brian@fsmiddleeast.ae, saby@seafoodmiddleeast.com\",\"official_address\":\"<p>\\r\\n\\tOfficial Address<\\/p>\\r\\n\",\"shipping_address\":\"<p>\\r\\n\\tShipping address<\\/p>\\r\\n\",\"place_of_supply\":\"<p>\\r\\n\\tSupply address<\\/p>\\r\\n\",\"supplier_buyer\":\"1\",\"city\":\"Tema\",\"country_id\":\"81\",\"insured_amount\":\"\",\"credit_limit\":\"\",\"payment_term\":\"\",\"owner_name\":\"Mr. Robert Ocran\",\"owner_nationality\":\"\",\"owner_email\":\"\",\"manager_name\":\"\",\"manager_nationality\":\"\",\"manager_email\":\"\",\"status\":\"1\"}', 1, 'master', 1, '2022-03-28 14:51:29');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES (194, 'acc_master', 83, 'edit', '{\"name\":\"def\",\"am_code\":\"002\",\"phone\":\"123456789\",\"email_id\":\"pritamkhanofficial@gmail.com\",\"official_address\":\"\",\"shipping_address\":\"\",\"place_of_supply\":\"\",\"supplier_buyer\":\"1\",\"city\":\"\",\"country_id\":\"44\",\"insured_amount\":\"\",\"credit_limit\":\"\",\"payment_term\":\"\",\"owner_name\":\"\",\"owner_nationality\":\"\",\"owner_email\":\"\",\"manager_name\":\"\",\"manager_nationality\":\"\",\"manager_email\":\"\",\"status\":\"1\"}', 1, 'master', 1, '2022-04-04 13:47:29');


#
# TABLE STRUCTURE FOR: user_permission
#

DROP TABLE IF EXISTS `user_permission`;

CREATE TABLE `user_permission` (
  `up_id` int(11) NOT NULL AUTO_INCREMENT,
  `m_id` int(11) NOT NULL COMMENT 'menu id',
  `user_id` int(11) NOT NULL,
  `view_permission` tinyint(1) NOT NULL DEFAULT 1,
  `add_permission` tinyint(1) NOT NULL DEFAULT 1,
  `edit_permission` tinyint(1) NOT NULL DEFAULT 1,
  `delete_permission` tinyint(1) NOT NULL DEFAULT 1,
  `print_permission` tinyint(1) NOT NULL DEFAULT 1,
  `download_permission` tinyint(1) NOT NULL DEFAULT 1,
  `block_permission` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'menu block',
  `custom1` tinyint(1) DEFAULT 1,
  `custom2` tinyint(1) DEFAULT 1,
  `custom3` tinyint(1) DEFAULT 1,
  `custom4` tinyint(1) DEFAULT 1,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modify_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`up_id`),
  KEY `menu_id` (`m_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES (1, 3, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, '2020-04-18 21:43:27', '2020-04-18 23:24:43');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES (2, 5, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, '2020-04-18 21:43:27', '2020-04-18 23:34:55');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES (3, 7, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, '2020-04-18 21:43:27', '2020-04-18 23:43:40');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES (4, 8, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, '2020-04-18 21:43:27', '2020-04-18 23:52:12');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES (5, 9, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, '2020-04-18 21:43:27', '2020-04-18 23:58:41');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES (6, 10, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, '2020-04-18 21:43:27', '2020-04-18 23:58:41');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES (7, 12, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, '2020-04-18 21:43:27', '2020-04-18 23:58:41');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES (8, 13, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, '2020-04-18 21:43:27', '2020-04-18 23:58:41');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES (9, 14, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, '2020-04-18 21:43:27', '2020-04-18 23:58:41');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES (10, 15, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, '2020-04-18 21:43:27', '2020-04-19 00:21:38');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES (11, 16, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, '2020-04-18 21:43:27', '2020-04-19 00:21:38');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES (12, 17, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, '2020-04-18 21:43:27', '2020-04-19 00:21:38');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES (13, 18, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, '2020-04-18 21:43:27', '2020-04-19 00:21:38');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES (14, 11, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, '2020-04-18 21:43:27', '2020-04-18 23:58:41');


#
# TABLE STRUCTURE FOR: user_reset_passwords
#

DROP TABLE IF EXISTS `user_reset_passwords`;

CREATE TABLE `user_reset_passwords` (
  `rp_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `otp` varchar(99) DEFAULT NULL,
  `time` varchar(30) DEFAULT NULL,
  `used` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`rp_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_reset_passwords_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `usertype` int(1) DEFAULT NULL COMMENT '1=admin,2=resource,3=marketing, 4=exporter',
  `username` varchar(30) DEFAULT NULL,
  `email` varchar(99) DEFAULT NULL,
  `pass` varchar(64) DEFAULT NULL,
  `acc_masters` varchar(255) DEFAULT NULL COMMENT 'for permission',
  `offer_ids` varchar(255) DEFAULT NULL COMMENT 'for exporter',
  `verified` tinyint(1) NOT NULL DEFAULT 0,
  `blocked` tinyint(1) NOT NULL DEFAULT 0,
  `registration_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`user_id`, `usertype`, `username`, `email`, `pass`, `acc_masters`, `offer_ids`, `verified`, `blocked`, `registration_date`) VALUES (1, 1, 'trader', 'saby@seafoodmiddleeast.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '12,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80', NULL, 1, 0, '2020-02-18 14:44:05');
INSERT INTO `users` (`user_id`, `usertype`, `username`, `email`, `pass`, `acc_masters`, `offer_ids`, `verified`, `blocked`, `registration_date`) VALUES (31, 2, 'RESOURCE_SABY', 'saby@seafoodmiddleeast.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '12,31,32,33,34,35,36,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,74,76,77,78,79,80,81,82', NULL, 1, 0, '2021-10-21 16:10:52');
INSERT INTO `users` (`user_id`, `usertype`, `username`, `email`, `pass`, `acc_masters`, `offer_ids`, `verified`, `blocked`, `registration_date`) VALUES (32, 2, 'RESOURCE_BRIAN', 'brian@fsmiddleeast.ae', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '12,31,32,33,34,35,36,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,74,76,77,78,79,80,81,82', NULL, 1, 0, '2021-10-21 16:13:05');
INSERT INTO `users` (`user_id`, `usertype`, `username`, `email`, `pass`, `acc_masters`, `offer_ids`, `verified`, `blocked`, `registration_date`) VALUES (33, 1, 'TRADER_SABY', 'saby@seafoodmiddleeast.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '12,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83', NULL, 1, 0, '2021-10-21 16:55:25');
INSERT INTO `users` (`user_id`, `usertype`, `username`, `email`, `pass`, `acc_masters`, `offer_ids`, `verified`, `blocked`, `registration_date`) VALUES (34, 3, 'MARKETING_BRIAN', 'brian@fsmiddleeast.ae', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,73,75,83', NULL, 1, 0, '2021-10-21 17:13:18');
INSERT INTO `users` (`user_id`, `usertype`, `username`, `email`, `pass`, `acc_masters`, `offer_ids`, `verified`, `blocked`, `registration_date`) VALUES (35, 3, 'MARKETING_SABY', 'saby@seafoodmiddleeast.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,73,75,83', NULL, 1, 0, '2021-10-21 17:17:02');
INSERT INTO `users` (`user_id`, `usertype`, `username`, `email`, `pass`, `acc_masters`, `offer_ids`, `verified`, `blocked`, `registration_date`) VALUES (50, 3, 'raju', '', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '37', '', 1, 0, '2021-11-10 17:42:36');
INSERT INTO `users` (`user_id`, `usertype`, `username`, `email`, `pass`, `acc_masters`, `offer_ids`, `verified`, `blocked`, `registration_date`) VALUES (51, 2, 'raja', '', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '12,33', '', 1, 0, '2021-11-10 17:45:15');
INSERT INTO `users` (`user_id`, `usertype`, `username`, `email`, `pass`, `acc_masters`, `offer_ids`, `verified`, `blocked`, `registration_date`) VALUES (52, 4, 'smg_exporter', '', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', NULL, '213,215,221', 1, 0, '2021-12-16 12:42:41');
INSERT INTO `users` (`user_id`, `usertype`, `username`, `email`, `pass`, `acc_masters`, `offer_ids`, `verified`, `blocked`, `registration_date`) VALUES (53, 4, 'Exporter_Bis', 'bish@seafoodmiddleeast.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', NULL, NULL, 1, 0, '2022-03-31 14:41:26');
INSERT INTO `users` (`user_id`, `usertype`, `username`, `email`, `pass`, `acc_masters`, `offer_ids`, `verified`, `blocked`, `registration_date`) VALUES (56, 2, 'Resource_Bis', 'bish@seafoodmiddleeast.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '31,32,33,34,35,36,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,74,76,77,78,79,80,81', NULL, 1, 0, '2022-03-31 14:44:23');


#
# TABLE STRUCTURE FOR: view_templates
#

DROP TABLE IF EXISTS `view_templates`;

CREATE TABLE `view_templates` (
  `vt_id` int(11) NOT NULL AUTO_INCREMENT,
  `vt_category` enum('DRT','DMT') DEFAULT NULL,
  `template_name` varchar(999) NOT NULL,
  `offer_header_fields` varchar(999) DEFAULT NULL,
  `offer_details_fields` varchar(999) DEFAULT NULL,
  `selling_prices_fields` varchar(999) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`vt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf16;

INSERT INTO `view_templates` (`vt_id`, `vt_category`, `template_name`, `offer_header_fields`, `offer_details_fields`, `selling_prices_fields`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (16, NULL, 'T1', 'offer_name,offer_number,offer_date,am_id,destination_c_id,country_id,c_id,incoterm_id,no_of_container,size_of_container,quantity_each_container,shipping_line,supplier_payment_terms,document_clause,inspection_clause,lab_report_clause,shipment_timing,etd,port_of_loading,production_date,shelf_life,tolerance,label_attached,carton_with_date,remarks_1,remarks_2,remarks_3', 'product_id,freezing_id,freezing_method_id,primary_packing_type_id,secondary_packing_type_id,packing_size_id,glazing_id,block_id,size_id,product_description,pieces,grade,size_before_glaze,size_after_glaze,quantity_offered,unit_id,cartons_offered,product_price,comment', 'selling_incoterm_id,selling-country_id,selling-currency_id,selling-am_id,selling-li_id,other_price,other_price_comment,freight,margin_flat,margin_percentage,final_selling_price', 0, '2021-08-25 10:52:26', '2021-08-25 10:52:26', 1);
INSERT INTO `view_templates` (`vt_id`, `vt_category`, `template_name`, `offer_header_fields`, `offer_details_fields`, `selling_prices_fields`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (20, NULL, 'T2', 'offer_name', 'product_name', 'final_selling_price', 0, '2021-08-25 18:22:33', '2021-10-20 11:55:05', 1);
INSERT INTO `view_templates` (`vt_id`, `vt_category`, `template_name`, `offer_header_fields`, `offer_details_fields`, `selling_prices_fields`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (24, 'DRT', 'Default Resource Template', 'offer_name,offer_number,offer_date,am_id,destination_c_id,country_id,c_id,incoterm_id,no_of_container,size_of_container,quantity_each_container,shipping_line,supplier_payment_terms,document_clause,inspection_clause,lab_report_clause,shipment_timing,etd,port_of_loading,production_date,shelf_life,tolerance,label_attached,carton_with_date,remarks_1,remarks_2,remarks_3', 'product_id,freezing_id,freezing_method_id,primary_packing_type_id,secondary_packing_type_id,packing_size_id,glazing_id,block_id,size_id,product_description,pieces,grade,size_before_glaze,size_after_glaze,quantity_offered,unit_id,cartons_offered,product_price,comment', 'selling_incoterm_id,selling-country_id,selling-currency_id,selling-am_id,selling-li_id,other_price,other_price_comment,freight,margin_flat,margin_percentage,final_selling_price', 1, '2021-08-25 10:52:26', '2021-10-31 21:08:33', 1);


#
# TABLE STRUCTURE FOR: view_templates_report
#

DROP TABLE IF EXISTS `view_templates_report`;

CREATE TABLE `view_templates_report` (
  `vt_id` int(11) NOT NULL,
  `vt_category` enum('DT','DMT') DEFAULT NULL,
  `template_name` varchar(999) NOT NULL,
  `export_header_fields` varchar(999) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

INSERT INTO `view_templates_report` (`vt_id`, `vt_category`, `template_name`, `export_header_fields`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (3, 'DT', 'Default Template', 'offer_id', 0, '2021-12-22 14:23:56', '2021-12-22 14:39:18', 1);
INSERT INTO `view_templates_report` (`vt_id`, `vt_category`, `template_name`, `export_header_fields`, `user_id`, `created_date`, `modified_date`, `status`) VALUES (0, NULL, 'T1', 'offer_id,company,fz_ref_no,actual_sale_amt,admin_appr,adv_amt_from_cust,rlink_for_bl_to_appear,advise_received_from_bank,adv_paid_to_vendor,adv_amt_to_vendor,adv_recd_from_cust,ata,atd', 0, '2022-04-04 13:23:44', '2022-04-04 13:23:44', 1);


