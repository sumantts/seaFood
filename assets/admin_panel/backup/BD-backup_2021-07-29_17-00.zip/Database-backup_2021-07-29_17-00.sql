#
# TABLE STRUCTURE FOR: acc_master
#

DROP TABLE IF EXISTS `acc_master`;

CREATE TABLE `acc_master` (
  `am_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(99) NOT NULL,
  `short_name` varchar(30) NOT NULL,
  `am_code` varchar(30) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email_id` varchar(99) NOT NULL,
  `vat_no` varchar(99) NOT NULL,
  `address` text NOT NULL,
  `place_of_supply` text,
  `proprietor` varchar(99) NOT NULL,
  `mill_id` int(11) NOT NULL COMMENT 'PK of mill',
  `supplier_buyer` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=Supplier,1=Buyer',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`am_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

INSERT INTO `acc_master` (`am_id`, `name`, `short_name`, `am_code`, `phone`, `email_id`, `vat_no`, `address`, `place_of_supply`, `proprietor`, `mill_id`, `supplier_buyer`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('12', 'ROY TRADERS - KOLKATA', 'ROYTRADERS', 'ROYTRADERS', '', '', '', '<p>\n	KOLKATA</p>\n', '<p>\n	KOLKATA</p>\n', 'TEJAS', '1', '0', '1', '1', '2020-06-24 14:54:08', '2021-07-29 10:30:26');
INSERT INTO `acc_master` (`am_id`, `name`, `short_name`, `am_code`, `phone`, `email_id`, `vat_no`, `address`, `place_of_supply`, `proprietor`, `mill_id`, `supplier_buyer`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('27', 'SUNRAYS ', 'S P', 'NEEL', '9879883902', '', '24ABECS4753B1ZX', '<p>\n	SATYA&nbsp; COMPLEX , OPP IOC PETROL PUMP,&nbsp; &nbsp;AHMEDABAD , GUJRAT -24</p>\n', '<p>\n	SATYA&nbsp; COMPLEX , OPP IOC PETROL PUMP,&nbsp; &nbsp;AHMEDABAD , GUJRAT -24</p>\n', '', '1', '1', '1', '1', '2020-08-06 13:07:00', '2021-07-27 19:35:43');
INSERT INTO `acc_master` (`am_id`, `name`, `short_name`, `am_code`, `phone`, `email_id`, `vat_no`, `address`, `place_of_supply`, `proprietor`, `mill_id`, `supplier_buyer`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('28', 'Ganesh', 'GN', '', '', '', '', '', NULL, '', '0', '1', '1', '1', '2021-07-10 11:13:05', '2021-07-10 11:13:05');
INSERT INTO `acc_master` (`am_id`, `name`, `short_name`, `am_code`, `phone`, `email_id`, `vat_no`, `address`, `place_of_supply`, `proprietor`, `mill_id`, `supplier_buyer`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('29', 'RAVI UDYOG', 'SIL/RU', '', '9332255551', '', '', '<p>\n	WARD NO-13 ,&nbsp;NEAR SHIB MANDIR,<br />\n	PUNJABI PARA ,&nbsp;SILIGURI, WEST BENGAL,<br />\n	PIN - 734001</p>\n', '<p>\n	WB (19)<br />\n	PAN no ACSPD8047Q,<br />\n	TIN: 19891338563,<br />\n	GSTIN: 19ACSPD8047Q1ZN</p>\n', 'Ravi', '1', '1', '1', '1', '2021-07-19 13:34:30', '2021-07-19 15:03:13');
INSERT INTO `acc_master` (`am_id`, `name`, `short_name`, `am_code`, `phone`, `email_id`, `vat_no`, `address`, `place_of_supply`, `proprietor`, `mill_id`, `supplier_buyer`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('30', 'SURE CARE  PVT LTD', 'SCP', 'SCP', '7000390373', '', '', '<div>\n	TOPSIA FLOOR NO 3</div>\n<div>\n	&nbsp;</div>\n', '<div>\n	TOPSIA FLOOR NO 3</div>\n<div>\n	&nbsp;</div>\n', 'TEJAS', '1', '1', '1', '1', '2021-07-29 07:56:57', '2021-07-29 09:45:31');


#
# TABLE STRUCTURE FOR: check_in
#

DROP TABLE IF EXISTS `check_in`;

CREATE TABLE `check_in` (
  `checkin_id` int(11) NOT NULL AUTO_INCREMENT,
  `checkin_number` varchar(50) NOT NULL,
  `checkin_date` date NOT NULL,
  `remarks` text NOT NULL,
  `terms` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`checkin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `check_in` (`checkin_id`, `checkin_number`, `checkin_date`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('4', 'CHK-IN/21072021/064000', '2021-07-21', '', '', '1', '1', '2021-07-21 18:40:20', '2021-07-21 18:40:20');
INSERT INTO `check_in` (`checkin_id`, `checkin_number`, `checkin_date`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('6', 'CHK-IN/24072021/085008', '2021-07-23', '', '', '1', '1', '2021-07-24 20:50:18', '2021-07-29 15:18:18');
INSERT INTO `check_in` (`checkin_id`, `checkin_number`, `checkin_date`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('7', 'CHK-IN/28072021/080341', '2021-07-28', '', '', '1', '1', '2021-07-28 20:03:57', '2021-07-29 15:18:39');
INSERT INTO `check_in` (`checkin_id`, `checkin_number`, `checkin_date`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('9', 'CHK-IN/29072021/010233', '2021-07-29', '', '', '1', '1', '2021-07-29 13:02:38', '2021-07-29 15:18:55');


#
# TABLE STRUCTURE FOR: checkin_detail
#

DROP TABLE IF EXISTS `checkin_detail`;

CREATE TABLE `checkin_detail` (
  `checkin_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `checkin_id` int(11) NOT NULL COMMENT 'PK of checkin',
  `e_id` int(11) NOT NULL COMMENT 'PK of employees',
  `pod_id` int(11) NOT NULL COMMENT 'PK of purchase_order_details	',
  `roll_handel` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=Roll, 1=Handel',
  `sz_id` int(11) NOT NULL COMMENT 'PK of sizes',
  `u_id` int(11) NOT NULL COMMENT 'PK of units',
  `received_quantity` double NOT NULL,
  `terms` text NOT NULL,
  `remarks` text NOT NULL,
  `rate_per_bag` decimal(10,2) NOT NULL COMMENT 'reference from employees',
  `todays_payable` decimal(10,2) NOT NULL,
  `due_amount` decimal(10,2) NOT NULL,
  `net_payable` decimal(10,2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`checkin_detail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=latin1;

INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('3', '4', '35', '8', '0', '47', '3', '500', ' ', ' ', '0.35', '175.00', '0.00', '175.00', '1', '1', '2021-07-21 18:44:07', '2021-07-21 18:44:07');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('4', '4', '38', '8', '0', '47', '3', '398', ' ', ' ', '0.35', '139.30', '0.00', '139.30', '1', '1', '2021-07-21 18:52:51', '2021-07-21 18:52:51');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('5', '4', '40', '8', '0', '47', '3', '460', ' ', ' ', '0.35', '161.00', '0.00', '161.00', '1', '1', '2021-07-21 18:55:16', '2021-07-21 18:55:16');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('6', '4', '43', '8', '0', '47', '3', '499', ' ', ' ', '0.35', '174.65', '0.00', '174.65', '1', '1', '2021-07-21 19:04:39', '2021-07-21 19:04:39');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('7', '4', '27', '8', '0', '47', '3', '507', ' ', ' ', '0.35', '177.45', '0.00', '177.45', '1', '1', '2021-07-21 19:06:16', '2021-07-21 19:06:16');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('8', '4', '45', '8', '0', '47', '3', '497', ' ', ' ', '0.35', '173.95', '0.00', '173.95', '1', '1', '2021-07-21 19:06:59', '2021-07-21 19:06:59');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('9', '4', '47', '8', '0', '47', '3', '473', ' ', ' ', '0.35', '165.55', '0.00', '165.55', '1', '1', '2021-07-21 19:07:59', '2021-07-21 19:07:59');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('10', '4', '48', '8', '0', '47', '3', '495', ' ', ' ', '0.35', '173.25', '0.00', '173.25', '1', '1', '2021-07-21 19:08:31', '2021-07-21 19:08:31');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('11', '4', '49', '8', '0', '47', '3', '343', ' ', ' ', '0.35', '120.05', '0.00', '120.05', '1', '1', '2021-07-21 19:08:57', '2021-07-21 19:08:57');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('12', '4', '28', '8', '0', '47', '3', '489', ' ', ' ', '0.35', '171.15', '0.00', '171.15', '1', '1', '2021-07-21 19:09:25', '2021-07-21 19:09:25');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('13', '4', '32', '8', '0', '47', '3', '501', ' ', ' ', '0.35', '175.35', '0.00', '175.35', '1', '1', '2021-07-21 19:10:08', '2021-07-21 19:10:08');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('14', '4', '33', '8', '0', '47', '3', '500', ' ', ' ', '0.35', '175.00', '0.00', '175.00', '1', '1', '2021-07-21 19:10:51', '2021-07-21 19:10:51');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('15', '4', '34', '8', '0', '47', '3', '701', ' ', ' ', '0.35', '245.35', '0.00', '245.35', '1', '1', '2021-07-21 19:11:25', '2021-07-21 19:11:25');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('16', '6', '37', '8', '0', '47', '3', '491', ' ', ' ', '0.35', '171.85', '0.00', '171.85', '1', '1', '2021-07-24 21:04:08', '2021-07-24 21:04:08');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('17', '6', '36', '8', '0', '47', '3', '503', ' ', ' ', '0.35', '176.05', '0.00', '176.05', '1', '1', '2021-07-24 21:08:46', '2021-07-24 21:08:46');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('18', '6', '39', '8', '0', '47', '3', '605', ' ', ' ', '0.35', '211.75', '0.00', '211.75', '1', '1', '2021-07-24 21:09:28', '2021-07-24 21:09:28');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('19', '6', '46', '8', '0', '47', '3', '512', ' ', ' ', '0.35', '179.20', '0.00', '179.20', '1', '1', '2021-07-24 21:10:01', '2021-07-24 21:10:01');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('20', '6', '33', '8', '0', '47', '3', '543', ' ', ' ', '0.35', '190.05', '0.00', '190.05', '1', '1', '2021-07-24 21:11:19', '2021-07-24 21:11:19');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('21', '6', '34', '8', '0', '47', '3', '268', ' ', ' ', '0.35', '93.80', '0.00', '93.80', '1', '1', '2021-07-24 21:21:56', '2021-07-24 21:21:56');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('22', '6', '26', '23', '0', '49', '13', '529', ' ', ' ', '0.35', '185.15', '0.00', '185.15', '1', '1', '2021-07-24 21:47:13', '2021-07-24 21:47:13');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('23', '6', '26', '21', '0', '49', '13', '600', ' ', ' ', '0.35', '210.00', '0.00', '210.00', '1', '1', '2021-07-24 21:49:46', '2021-07-24 21:49:46');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('26', '6', '41', '23', '0', '49', '13', '503', ' ', ' ', '0.35', '176.05', '0.00', '176.05', '1', '1', '2021-07-24 21:53:23', '2021-07-24 21:53:23');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('27', '6', '44', '23', '0', '49', '13', '467', ' ', ' ', '0.35', '163.45', '0.00', '163.45', '1', '1', '2021-07-24 21:54:58', '2021-07-24 21:54:58');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('28', '6', '27', '23', '0', '49', '13', '524', ' ', ' ', '0.35', '183.40', '0.00', '183.40', '1', '1', '2021-07-24 21:55:33', '2021-07-24 21:55:33');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('29', '6', '50', '23', '0', '49', '13', '498', ' ', ' ', '0.35', '174.30', '0.00', '174.30', '1', '1', '2021-07-24 21:56:13', '2021-07-24 21:56:13');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('30', '6', '28', '23', '0', '49', '13', '414', ' ', ' ', '0.35', '144.90', '0.00', '144.90', '1', '1', '2021-07-24 21:57:09', '2021-07-24 21:57:09');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('31', '6', '29', '23', '0', '49', '13', '496', ' ', ' ', '0.35', '173.60', '0.00', '173.60', '1', '1', '2021-07-24 21:57:41', '2021-07-24 21:57:41');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('32', '6', '31', '23', '0', '49', '13', '500', ' ', ' ', '0.35', '175.00', '0.00', '175.00', '1', '1', '2021-07-24 21:58:03', '2021-07-24 21:58:03');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('33', '6', '31', '21', '0', '49', '13', '484', ' ', ' ', '0.35', '169.40', '0.00', '169.40', '1', '1', '2021-07-24 21:59:07', '2021-07-24 21:59:07');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('34', '6', '51', '23', '0', '49', '13', '518', ' ', ' ', '0.35', '181.30', '0.00', '181.30', '1', '1', '2021-07-24 21:59:49', '2021-07-24 21:59:49');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('35', '6', '56', '23', '0', '49', '13', '508', ' ', ' ', '0.35', '177.80', '0.00', '177.80', '1', '1', '2021-07-24 22:00:14', '2021-07-24 22:00:14');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('38', '7', '27', '27', '0', '47', '3', '517', ' ', ' ', '0.35', '180.95', '0.00', '180.95', '1', '1', '2021-07-28 20:41:51', '2021-07-28 20:41:51');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('39', '7', '30', '8', '0', '47', '3', '514', ' ', ' ', '0.35', '179.90', '0.00', '179.90', '1', '1', '2021-07-28 20:44:56', '2021-07-28 20:44:56');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('40', '7', '31', '8', '0', '47', '3', '505', ' ', ' ', '0.35', '176.75', '0.00', '176.75', '1', '1', '2021-07-28 20:46:21', '2021-07-28 20:46:21');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('41', '7', '26', '8', '0', '47', '3', '522', ' ', ' ', '0.35', '182.70', '0.00', '182.70', '1', '1', '2021-07-28 20:47:45', '2021-07-28 20:47:45');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('42', '7', '51', '27', '0', '47', '3', '493', ' ', ' ', '0.35', '172.55', '0.00', '172.55', '1', '1', '2021-07-28 20:48:54', '2021-07-28 20:48:54');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('43', '7', '58', '27', '0', '47', '3', '486', ' ', ' ', '0.35', '170.10', '0.00', '170.10', '1', '1', '2021-07-28 20:50:58', '2021-07-28 20:50:58');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('44', '7', '62', '27', '0', '47', '3', '472', ' ', ' ', '0.35', '165.20', '0.00', '165.20', '1', '1', '2021-07-28 20:51:51', '2021-07-28 20:51:51');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('46', '7', '50', '8', '0', '47', '3', '494', ' ', ' ', '0.35', '172.90', '0.00', '172.90', '1', '1', '2021-07-28 20:53:42', '2021-07-28 20:53:42');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('47', '7', '57', '27', '0', '47', '3', '472', ' ', ' ', '0.35', '165.20', '0.00', '165.20', '1', '1', '2021-07-28 20:54:53', '2021-07-28 20:54:53');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('48', '7', '27', '21', '0', '49', '13', '540', ' ', ' ', '0.35', '189.00', '0.00', '189.00', '1', '1', '2021-07-28 21:33:05', '2021-07-28 21:33:05');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('51', '9', '34', '8', '0', '47', '3', '268', ' ', ' ', '0.35', '93.80', '0.00', '93.80', '1', '1', '2021-07-29 13:04:19', '2021-07-29 13:04:19');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('52', '9', '41', '8', '0', '47', '3', '534', ' ', ' ', '0.35', '186.90', '0.00', '186.90', '1', '1', '2021-07-29 13:04:59', '2021-07-29 13:04:59');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('53', '9', '44', '8', '0', '47', '3', '492', ' ', ' ', '0.35', '172.20', '0.00', '172.20', '1', '1', '2021-07-29 13:05:25', '2021-07-29 13:05:25');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('55', '9', '26', '27', '0', '47', '3', '629', ' ', ' ', '0.35', '220.15', '0.00', '220.15', '1', '1', '2021-07-29 13:09:23', '2021-07-29 13:09:23');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('56', '9', '50', '27', '0', '47', '3', '522', ' ', ' ', '0.35', '182.70', '0.00', '182.70', '1', '1', '2021-07-29 13:09:57', '2021-07-29 13:09:57');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('57', '9', '31', '27', '0', '47', '3', '484', ' ', ' ', '0.35', '169.40', '0.00', '169.40', '1', '1', '2021-07-29 13:10:23', '2021-07-29 13:10:23');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('58', '9', '29', '8', '0', '47', '3', '488', ' ', ' ', '0.35', '170.80', '0.00', '170.80', '1', '1', '2021-07-29 13:17:12', '2021-07-29 13:17:12');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('60', '7', '26', '19', '0', '49', '13', '498', ' ', ' ', '0.35', '174.30', '0.00', '174.30', '1', '1', '2021-07-29 13:53:11', '2021-07-29 13:53:11');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('61', '7', '58', '21', '0', '49', '13', '449', ' ', ' ', '0.35', '157.15', '0.00', '157.15', '1', '1', '2021-07-29 13:55:29', '2021-07-29 13:55:29');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('62', '7', '34', '19', '0', '49', '13', '500', ' ', ' ', '0.35', '175.00', '0.00', '175.00', '1', '1', '2021-07-29 13:56:50', '2021-07-29 13:56:50');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('63', '7', '28', '21', '0', '49', '13', '515', ' ', ' ', '0.35', '180.25', '0.00', '180.25', '1', '1', '2021-07-29 14:06:02', '2021-07-29 14:06:02');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('64', '7', '28', '19', '0', '49', '13', '530', ' ', ' ', '0.35', '185.50', '0.00', '185.50', '1', '1', '2021-07-29 14:06:36', '2021-07-29 14:06:36');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('65', '7', '38', '21', '0', '49', '13', '515', ' ', ' ', '0.35', '180.25', '0.00', '180.25', '1', '1', '2021-07-29 14:07:33', '2021-07-29 14:07:33');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('66', '7', '60', '19', '0', '49', '13', '500', ' ', ' ', '0.35', '175.00', '0.00', '175.00', '1', '1', '2021-07-29 14:09:19', '2021-07-29 14:09:19');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('67', '7', '60', '21', '0', '49', '13', '509', ' ', ' ', '0.35', '178.15', '0.00', '178.15', '1', '1', '2021-07-29 14:09:54', '2021-07-29 14:09:54');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('68', '7', '32', '23', '0', '49', '13', '500', ' ', ' ', '0.35', '175.00', '0.00', '175.00', '1', '1', '2021-07-29 14:12:10', '2021-07-29 14:12:10');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('69', '7', '32', '21', '0', '49', '13', '296', ' ', ' ', '0.35', '103.60', '0.00', '103.60', '1', '1', '2021-07-29 14:12:41', '2021-07-29 14:12:41');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('70', '7', '54', '23', '0', '49', '13', '451', ' ', ' ', '0.35', '157.85', '0.00', '157.85', '1', '1', '2021-07-29 14:13:50', '2021-07-29 14:13:50');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('71', '7', '63', '19', '0', '49', '13', '847', ' ', ' ', '0.35', '296.45', '0.00', '296.45', '1', '1', '2021-07-29 14:14:27', '2021-07-29 14:14:27');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('72', '7', '50', '21', '0', '49', '13', '491', ' ', ' ', '0.35', '171.85', '0.00', '171.85', '1', '1', '2021-07-29 14:16:33', '2021-07-29 14:16:33');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('73', '7', '51', '19', '0', '49', '13', '501', ' ', ' ', '0.35', '175.35', '0.00', '175.35', '1', '1', '2021-07-29 14:19:03', '2021-07-29 14:19:03');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('74', '7', '44', '21', '0', '49', '13', '500', ' ', ' ', '0.35', '175.00', '0.00', '175.00', '1', '1', '2021-07-29 14:20:33', '2021-07-29 14:20:33');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('75', '7', '44', '19', '0', '49', '13', '495', ' ', ' ', '0.35', '173.25', '0.00', '173.25', '1', '1', '2021-07-29 14:21:01', '2021-07-29 14:21:01');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('76', '7', '29', '21', '0', '49', '13', '500', ' ', ' ', '0.35', '175.00', '0.00', '175.00', '1', '1', '2021-07-29 14:21:55', '2021-07-29 14:21:55');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('77', '7', '29', '19', '0', '49', '13', '474', ' ', ' ', '0.35', '165.90', '0.00', '165.90', '1', '1', '2021-07-29 14:22:38', '2021-07-29 14:22:38');
INSERT INTO `checkin_detail` (`checkin_detail_id`, `checkin_id`, `e_id`, `pod_id`, `roll_handel`, `sz_id`, `u_id`, `received_quantity`, `terms`, `remarks`, `rate_per_bag`, `todays_payable`, `due_amount`, `net_payable`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('78', '7', '31', '19', '0', '49', '13', '500', ' ', ' ', '0.35', '175.00', '0.00', '175.00', '1', '1', '2021-07-29 15:56:55', '2021-07-29 15:56:55');


#
# TABLE STRUCTURE FOR: colors
#

DROP TABLE IF EXISTS `colors`;

CREATE TABLE `colors` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `color` varchar(99) NOT NULL,
  `c_code` varchar(15) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

INSERT INTO `colors` (`c_id`, `color`, `c_code`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('13', 'LOYAL GOLD BROWN', 'LGB', '1', '1', '2020-04-07 13:20:04', '2021-07-16 13:12:42');
INSERT INTO `colors` (`c_id`, `color`, `c_code`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('14', 'GREEN', 'GREEN', '1', '1', '2020-04-07 13:20:23', '2021-02-20 21:41:46');
INSERT INTO `colors` (`c_id`, `color`, `c_code`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('27', 'RED', 'RED', '1', '1', '2020-04-08 20:57:22', '2021-02-20 21:41:26');
INSERT INTO `colors` (`c_id`, `color`, `c_code`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('28', 'KRAFT', 'KRAFT', '1', '1', '2021-04-02 11:54:15', '2021-04-02 11:54:15');
INSERT INTO `colors` (`c_id`, `color`, `c_code`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('29', 'TEXTURE', 'TXT', '1', '1', '2021-07-22 11:00:05', '2021-07-22 11:00:05');


#
# TABLE STRUCTURE FOR: customer_invoice
#

DROP TABLE IF EXISTS `customer_invoice`;

CREATE TABLE `customer_invoice` (
  `cus_inv_id` int(11) NOT NULL AUTO_INCREMENT,
  `co_id` int(11) NOT NULL COMMENT 'PK of customer_order',
  `cus_inv_number` varchar(50) NOT NULL,
  `cus_inv_e_way_bill_no` varchar(50) NOT NULL,
  `am_id` int(11) NOT NULL COMMENT 'PK of acc_master Reference of customer_order acc_master_id',
  `transporter_id` int(11) NOT NULL COMMENT 'PK of transporter',
  `transporter_cn_number` varchar(50) NOT NULL,
  `cus_inv_number_of_cartons` int(11) NOT NULL,
  `cus_inv_total_weight` decimal(10,2) NOT NULL,
  `invoice_create_date` date NOT NULL,
  `packing_rate` double DEFAULT NULL,
  `packing_tax` int(11) NOT NULL,
  `remarks` text NOT NULL,
  `terms` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`cus_inv_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `customer_invoice` (`cus_inv_id`, `co_id`, `cus_inv_number`, `cus_inv_e_way_bill_no`, `am_id`, `transporter_id`, `transporter_cn_number`, `cus_inv_number_of_cartons`, `cus_inv_total_weight`, `invoice_create_date`, `packing_rate`, `packing_tax`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('2', '1', 'INV/17072021/095216', '1111111111', '27', '2', '3000298411', '16', '441.00', '2021-07-26', '100', '12', '', '', '1', '1', '2021-07-26 17:44:19', '2021-07-26 21:41:59');


#
# TABLE STRUCTURE FOR: customer_invoice_detail
#

DROP TABLE IF EXISTS `customer_invoice_detail`;

CREATE TABLE `customer_invoice_detail` (
  `cus_inv_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `cus_inv_id` int(11) NOT NULL COMMENT 'PK of customer_invoice',
  `co_id` int(11) NOT NULL COMMENT 'Pk of customer_order',
  `cod_id` int(11) NOT NULL COMMENT 'PK of customer_order_dtl',
  `sz_id` int(11) NOT NULL COMMENT 'PK of sizes Reference of customer_order_dtl',
  `paper_gsm` int(11) NOT NULL,
  `paper_bf` int(11) NOT NULL,
  `c_id` int(11) NOT NULL COMMENT 'Pk of colors Reference of customer_order_dtl',
  `cus_order_quantity` int(11) NOT NULL COMMENT 'reference of cus_order_detail',
  `rate_per_unit` decimal(10,2) NOT NULL COMMENT 'Reference of sizes',
  `delivered_quantity` int(11) NOT NULL,
  `due_quantity` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`cus_inv_detail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `customer_invoice_detail` (`cus_inv_detail_id`, `cus_inv_id`, `co_id`, `cod_id`, `sz_id`, `paper_gsm`, `paper_bf`, `c_id`, `cus_order_quantity`, `rate_per_unit`, `delivered_quantity`, `due_quantity`, `total_amount`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('7', '2', '1', '3', '49', '120', '20', '13', '1500', '5.80', '1500', '0', '8700.00', '1', '1', '2021-07-26 17:47:37', '2021-07-26 17:47:37');
INSERT INTO `customer_invoice_detail` (`cus_inv_detail_id`, `cus_inv_id`, `co_id`, `cod_id`, `sz_id`, `paper_gsm`, `paper_bf`, `c_id`, `cus_order_quantity`, `rate_per_unit`, `delivered_quantity`, `due_quantity`, `total_amount`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('8', '2', '1', '4', '47', '120', '20', '13', '6000', '4.30', '6000', '0', '25800.00', '1', '1', '2021-07-26 17:47:37', '2021-07-26 17:47:37');


#
# TABLE STRUCTURE FOR: customer_order
#

DROP TABLE IF EXISTS `customer_order`;

CREATE TABLE `customer_order` (
  `co_id` int(11) NOT NULL AUTO_INCREMENT,
  `co_no` varchar(100) NOT NULL,
  `acc_master_id` int(11) NOT NULL,
  `buyer_reference_no` varchar(100) NOT NULL,
  `co_date` date NOT NULL,
  `co_delivery_date` date NOT NULL,
  `co_remarks` text,
  `co_total_amount` double NOT NULL DEFAULT '0',
  `co_total_quantity` double NOT NULL DEFAULT '0',
  `img` varchar(255) DEFAULT NULL,
  `invoice_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=Invoice Initiate',
  `invoice_pending_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=Not Pending, 1=Pending',
  `invoice_final_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=Invoice Finalize',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`co_id`),
  KEY `acc_master_id` (`acc_master_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `customer_order` (`co_id`, `co_no`, `acc_master_id`, `buyer_reference_no`, `co_date`, `co_delivery_date`, `co_remarks`, `co_total_amount`, `co_total_quantity`, `img`, `invoice_status`, `invoice_pending_status`, `invoice_final_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('1', 'SUNRAYS/17072021/095216', '27', 'NEEL AHMEDABAD', '2021-07-22', '2021-07-26', '', '0', '0', NULL, '1', '0', '1', '1', '1', '2021-07-17 09:52:40', '2021-07-27 19:41:41');
INSERT INTO `customer_order` (`co_id`, `co_no`, `acc_master_id`, `buyer_reference_no`, `co_date`, `co_delivery_date`, `co_remarks`, `co_total_amount`, `co_total_quantity`, `img`, `invoice_status`, `invoice_pending_status`, `invoice_final_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('4', 'SCPP/27072021/073627', '30', 'TEJAS KOLKATA', '2021-07-27', '2021-07-27', '', '0', '0', NULL, '0', '0', '0', '1', '1', '2021-07-27 19:37:57', '2021-07-29 11:08:16');


#
# TABLE STRUCTURE FOR: customer_order_dtl
#

DROP TABLE IF EXISTS `customer_order_dtl`;

CREATE TABLE `customer_order_dtl` (
  `cod_id` int(11) NOT NULL AUTO_INCREMENT,
  `co_id` int(11) NOT NULL COMMENT 'customer order',
  `sz_id` int(11) NOT NULL COMMENT 'PK of sizes',
  `cus_order_quantity` double NOT NULL,
  `c_id` int(11) NOT NULL COMMENT 'PK of colors',
  `paper_gsm` int(11) DEFAULT NULL,
  `paper_bf` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`cod_id`),
  KEY `co_id` (`co_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `customer_order_dtl` (`cod_id`, `co_id`, `sz_id`, `cus_order_quantity`, `c_id`, `paper_gsm`, `paper_bf`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('3', '1', '49', '1500', '13', '120', '20', '1', '1', '2021-07-26 17:36:17', '2021-07-26 17:36:17');
INSERT INTO `customer_order_dtl` (`cod_id`, `co_id`, `sz_id`, `cus_order_quantity`, `c_id`, `paper_gsm`, `paper_bf`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('4', '1', '47', '6000', '13', '120', '20', '1', '1', '2021-07-26 17:36:47', '2021-07-26 17:36:47');
INSERT INTO `customer_order_dtl` (`cod_id`, `co_id`, `sz_id`, `cus_order_quantity`, `c_id`, `paper_gsm`, `paper_bf`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('5', '4', '47', '6000', '13', '120', '20', '1', '1', '2021-07-27 19:38:32', '2021-07-27 19:38:32');


#
# TABLE STRUCTURE FOR: customer_payment
#

DROP TABLE IF EXISTS `customer_payment`;

CREATE TABLE `customer_payment` (
  `cp_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `amount` double NOT NULL,
  `remarks` text,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`cp_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `customer_payment` (`cp_id`, `invoice_id`, `payment_date`, `amount`, `remarks`, `user_id`, `created_date`, `modified_date`, `status`) VALUES ('7', '2', '2021-07-26', '38752', '', '1', '2021-07-28 18:03:16', '2021-07-28 18:03:16', '1');


#
# TABLE STRUCTURE FOR: departments
#

DROP TABLE IF EXISTS `departments`;

CREATE TABLE `departments` (
  `d_id` int(11) NOT NULL AUTO_INCREMENT,
  `department` varchar(99) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`d_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `departments` (`d_id`, `department`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('1', 'FACTORY - BAG', '1', '1', '2020-04-12 10:22:34', '2020-04-12 10:22:56');
INSERT INTO `departments` (`d_id`, `department`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('3', 'OFFICE', '1', '1', '2020-04-12 10:22:46', '2020-04-12 10:22:46');


#
# TABLE STRUCTURE FOR: distribute
#

DROP TABLE IF EXISTS `distribute`;

CREATE TABLE `distribute` (
  `dis_id` int(11) NOT NULL AUTO_INCREMENT,
  `dis_number` varchar(50) NOT NULL,
  `dis_date` date NOT NULL,
  `dis_return_date` date NOT NULL,
  `remarks` text NOT NULL,
  `terms` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`dis_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: distribute_detail
#

DROP TABLE IF EXISTS `distribute_detail`;

CREATE TABLE `distribute_detail` (
  `dis_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `dis_id` int(11) NOT NULL COMMENT 'PK of distribute',
  `e_id` int(11) NOT NULL COMMENT 'PK of employees',
  `pod_id` int(11) NOT NULL COMMENT 'PK of purchase_order_details',
  `prod_detail_id` int(11) NOT NULL COMMENT 'PK of production_detail',
  `roll_handel` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=Roll, 1=Handel',
  `sz_id` int(11) NOT NULL COMMENT 'PK of sizes',
  `u_id` int(11) NOT NULL COMMENT 'PK of units',
  `distribute_pod_quantity` double NOT NULL,
  `remarks` text NOT NULL,
  `terms` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`dis_detail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=latin1;

INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('1', '1', '9', '1', '1', '0', '33', '3', '500', '', '', '1', '1', '2021-07-17 09:58:14', '2021-07-17 09:58:14');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('2', '1', '6', '1', '2', '0', '36', '3', '400', '', '', '1', '1', '2021-07-17 09:59:01', '2021-07-17 09:59:01');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('3', '1', '26', '8', '3', '0', '47', '3', '500', '', '', '1', '1', '2021-07-19 18:56:38', '2021-07-19 18:56:38');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('4', '1', '27', '8', '4', '0', '47', '3', '500', '', '', '1', '1', '2021-07-19 18:59:40', '2021-07-19 18:59:40');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('5', '1', '28', '8', '5', '0', '47', '3', '500', '', '', '1', '1', '2021-07-19 19:01:04', '2021-07-19 19:01:04');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('7', '1', '29', '8', '7', '0', '47', '3', '500', '', '', '1', '1', '2021-07-19 19:02:03', '2021-07-19 19:02:03');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('8', '1', '30', '8', '8', '0', '47', '3', '500', '', '', '1', '1', '2021-07-19 19:02:46', '2021-07-19 19:02:46');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('9', '1', '31', '8', '9', '0', '47', '3', '500', '', '', '1', '1', '2021-07-19 19:03:24', '2021-07-19 19:03:24');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('10', '1', '32', '8', '10', '0', '47', '3', '500', '', '', '1', '1', '2021-07-19 19:04:02', '2021-07-19 19:04:02');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('12', '1', '33', '8', '12', '0', '47', '3', '1000', '', '', '1', '1', '2021-07-19 19:06:52', '2021-07-19 19:06:52');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('13', '1', '34', '8', '13', '0', '47', '3', '1000', '', '', '1', '1', '2021-07-19 19:07:45', '2021-07-19 19:07:45');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('14', '1', '35', '8', '14', '0', '47', '3', '500', '', '', '1', '1', '2021-07-19 19:08:37', '2021-07-19 19:08:37');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('15', '1', '36', '8', '15', '0', '47', '3', '500', '', '', '1', '1', '2021-07-19 19:09:05', '2021-07-19 19:09:05');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('16', '1', '37', '8', '16', '0', '47', '3', '500', '', '', '1', '1', '2021-07-19 19:17:41', '2021-07-24 20:54:50');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('17', '1', '38', '8', '17', '0', '47', '3', '500', '', '', '1', '1', '2021-07-19 19:25:36', '2021-07-19 19:25:36');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('18', '1', '39', '8', '18', '0', '47', '3', '500', '', '', '1', '1', '2021-07-19 19:26:20', '2021-07-19 19:26:20');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('19', '1', '40', '8', '19', '0', '47', '3', '500', '', '', '1', '1', '2021-07-19 19:26:57', '2021-07-19 19:26:57');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('20', '1', '41', '8', '20', '0', '47', '3', '500', '', '', '1', '1', '2021-07-19 19:27:29', '2021-07-19 19:27:29');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('21', '1', '43', '8', '21', '0', '47', '3', '500', '', '', '1', '1', '2021-07-19 19:28:02', '2021-07-19 19:28:02');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('22', '1', '44', '8', '22', '0', '47', '3', '500', '', '', '1', '1', '2021-07-19 19:28:34', '2021-07-19 19:28:34');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('23', '1', '45', '8', '23', '0', '47', '3', '500', '', '', '1', '1', '2021-07-19 19:29:06', '2021-07-19 19:29:06');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('24', '1', '46', '8', '24', '0', '47', '3', '500', '', '', '1', '1', '2021-07-19 19:29:47', '2021-07-19 19:29:47');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('25', '1', '47', '8', '25', '0', '47', '3', '500', '', '', '1', '1', '2021-07-19 19:30:19', '2021-07-19 19:30:19');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('26', '1', '48', '8', '26', '0', '47', '3', '500', '', '', '1', '1', '2021-07-19 19:31:05', '2021-07-19 19:31:05');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('27', '1', '50', '8', '27', '0', '47', '3', '500', '', '', '1', '1', '2021-07-19 19:37:42', '2021-07-19 19:37:42');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('28', '1', '49', '8', '28', '0', '47', '3', '342', '', '', '1', '1', '2021-07-19 19:39:30', '2021-07-19 19:39:30');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('30', '1', '51', '23', '30', '0', '49', '13', '500', '', '', '1', '1', '2021-07-20 19:04:17', '2021-07-20 19:04:17');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('31', '1', '52', '23', '31', '0', '49', '13', '500', '', '', '1', '1', '2021-07-20 19:07:32', '2021-07-20 19:07:32');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('32', '1', '53', '23', '32', '0', '49', '13', '500', '', '', '1', '1', '2021-07-20 19:08:40', '2021-07-20 19:08:40');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('33', '1', '27', '23', '33', '0', '49', '13', '500', '', '', '1', '1', '2021-07-20 19:09:37', '2021-07-20 19:09:37');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('34', '1', '54', '23', '34', '0', '49', '13', '500', '', '', '1', '1', '2021-07-20 19:10:14', '2021-07-20 19:10:14');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('35', '1', '29', '23', '35', '0', '49', '13', '500', '', '', '1', '1', '2021-07-20 19:11:06', '2021-07-20 19:11:06');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('36', '1', '28', '23', '36', '0', '49', '13', '500', '', '', '1', '1', '2021-07-20 19:11:44', '2021-07-20 19:11:44');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('37', '1', '55', '23', '37', '0', '49', '13', '500', '', '', '1', '1', '2021-07-20 19:12:31', '2021-07-20 19:12:31');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('38', '1', '43', '23', '38', '0', '49', '13', '500', '', '', '1', '1', '2021-07-20 19:13:10', '2021-07-20 19:13:10');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('39', '1', '32', '23', '39', '0', '49', '13', '500', '', '', '1', '1', '2021-07-20 19:13:47', '2021-07-20 19:13:47');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('40', '1', '41', '23', '40', '0', '49', '13', '500', '', '', '1', '1', '2021-07-20 19:14:24', '2021-07-20 19:14:24');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('41', '1', '31', '23', '41', '0', '49', '13', '500', '', '', '1', '1', '2021-07-20 19:15:08', '2021-07-20 19:15:08');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('42', '1', '44', '23', '42', '0', '49', '13', '500', '', '', '1', '1', '2021-07-20 19:15:56', '2021-07-20 19:15:56');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('43', '1', '50', '23', '43', '0', '49', '13', '500', '', '', '1', '1', '2021-07-20 19:16:29', '2021-07-20 19:16:29');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('44', '1', '26', '23', '44', '0', '49', '13', '500', '', '', '1', '1', '2021-07-20 19:17:17', '2021-07-20 19:17:17');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('45', '1', '56', '23', '45', '0', '49', '13', '500', '', '', '1', '1', '2021-07-20 19:18:14', '2021-07-20 19:18:14');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('46', '1', '57', '23', '46', '0', '49', '13', '500', '', '', '1', '1', '2021-07-20 19:19:09', '2021-07-20 19:19:09');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('47', '1', '49', '23', '47', '0', '49', '13', '500', '', '', '1', '1', '2021-07-20 19:20:53', '2021-07-20 19:20:53');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('48', '1', '48', '23', '48', '0', '49', '13', '500', '', '', '1', '1', '2021-07-20 19:21:31', '2021-07-20 19:21:31');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('49', '1', '47', '23', '49', '0', '49', '13', '500', '', '', '1', '1', '2021-07-20 19:22:13', '2021-07-20 19:22:13');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('50', '1', '45', '23', '50', '0', '49', '13', '500', '', '', '1', '1', '2021-07-20 19:22:52', '2021-07-20 19:22:52');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('51', '1', '49', '23', '51', '0', '49', '13', '182', '', '', '1', '1', '2021-07-20 19:23:43', '2021-07-20 19:23:43');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('55', '1', '27', '21', '55', '0', '49', '13', '500', '', '', '1', '1', '2021-07-21 18:33:36', '2021-07-21 18:33:36');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('56', '1', '29', '21', '56', '0', '49', '13', '500', '', '', '1', '1', '2021-07-21 18:38:15', '2021-07-21 18:38:15');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('57', '1', '58', '21', '57', '0', '49', '13', '500', '', '', '1', '1', '2021-07-21 19:49:18', '2021-07-21 19:49:18');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('58', '1', '32', '21', '58', '0', '49', '13', '500', '', '', '1', '1', '2021-07-21 19:50:16', '2021-07-21 19:50:16');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('59', '1', '40', '21', '59', '0', '49', '13', '500', '', '', '1', '1', '2021-07-21 19:50:57', '2021-07-21 19:50:57');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('60', '1', '59', '21', '60', '0', '49', '13', '500', '', '', '1', '1', '2021-07-21 19:51:47', '2021-07-21 19:51:47');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('61', '1', '51', '21', '61', '0', '49', '13', '500', '', '', '1', '1', '2021-07-21 19:53:44', '2021-07-21 19:53:44');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('62', '1', '35', '21', '62', '0', '49', '13', '500', '', '', '1', '1', '2021-07-21 19:54:21', '2021-07-21 19:54:21');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('63', '1', '38', '21', '63', '0', '49', '13', '500', '', '', '1', '1', '2021-07-21 19:57:54', '2021-07-21 19:57:54');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('64', '1', '31', '21', '64', '0', '49', '13', '500', '', '', '1', '1', '2021-07-21 19:58:39', '2021-07-21 19:58:39');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('65', '1', '41', '21', '65', '0', '49', '13', '500', '', '', '1', '1', '2021-07-21 19:59:21', '2021-07-21 19:59:21');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('66', '1', '26', '21', '66', '0', '49', '13', '500', '', '', '1', '1', '2021-07-21 20:00:08', '2021-07-21 20:00:08');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('67', '1', '44', '21', '67', '0', '49', '13', '500', '', '', '1', '1', '2021-07-21 20:01:10', '2021-07-21 20:01:10');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('68', '1', '28', '21', '68', '0', '49', '13', '500', '', '', '1', '1', '2021-07-21 20:01:52', '2021-07-21 20:01:52');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('69', '1', '61', '21', '69', '0', '49', '13', '500', '', '', '1', '1', '2021-07-21 20:11:34', '2021-07-21 20:11:34');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('70', '1', '43', '21', '70', '0', '49', '13', '500', '', '', '1', '1', '2021-07-21 20:12:36', '2021-07-21 20:12:36');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('71', '1', '50', '21', '71', '0', '49', '13', '500', '', '', '1', '1', '2021-07-21 20:13:50', '2021-07-21 20:13:50');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('72', '1', '60', '21', '72', '0', '49', '13', '500', '', '', '1', '1', '2021-07-21 20:14:57', '2021-07-21 20:14:57');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('73', '1', '56', '21', '73', '0', '49', '13', '500', '', '', '1', '1', '2021-07-21 20:15:31', '2021-07-21 20:15:31');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('74', '1', '48', '21', '74', '0', '49', '13', '500', '', '', '1', '1', '2021-07-21 20:16:33', '2021-07-21 20:16:33');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('75', '1', '49', '21', '75', '0', '49', '13', '620', '', '', '1', '1', '2021-07-21 20:17:28', '2021-07-21 20:17:28');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('76', '1', '51', '19', '76', '0', '49', '13', '500', '', '', '1', '1', '2021-07-22 20:29:04', '2021-07-22 20:29:04');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('77', '1', '58', '19', '77', '0', '49', '13', '500', '', '', '1', '1', '2021-07-22 20:29:34', '2021-07-22 20:29:34');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('78', '1', '60', '19', '78', '0', '49', '13', '500', '', '', '1', '1', '2021-07-22 20:30:06', '2021-07-22 20:30:06');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('79', '1', '41', '19', '79', '0', '49', '13', '500', '', '', '1', '1', '2021-07-22 20:31:31', '2021-07-22 20:31:31');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('80', '1', '44', '19', '80', '0', '49', '13', '500', '', '', '1', '1', '2021-07-22 20:32:10', '2021-07-22 20:32:10');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('81', '1', '31', '19', '81', '0', '49', '13', '500', '', '', '1', '1', '2021-07-22 20:32:52', '2021-07-22 20:32:52');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('82', '1', '28', '19', '82', '0', '49', '13', '500', '', '', '1', '1', '2021-07-22 20:33:42', '2021-07-22 20:33:42');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('83', '1', '26', '19', '83', '0', '49', '13', '500', '', '', '1', '1', '2021-07-22 20:36:41', '2021-07-22 20:36:41');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('84', '1', '50', '19', '84', '0', '49', '13', '500', '', '', '1', '1', '2021-07-22 20:37:10', '2021-07-22 20:37:10');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('85', '1', '29', '19', '85', '0', '49', '13', '500', '', '', '1', '1', '2021-07-22 20:38:02', '2021-07-22 20:38:02');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('86', '1', '56', '19', '86', '0', '49', '13', '500', '', '', '1', '1', '2021-07-22 20:38:43', '2021-07-22 20:38:43');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('87', '1', '40', '19', '87', '0', '49', '13', '500', '', '', '1', '1', '2021-07-22 20:39:15', '2021-07-22 20:39:15');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('88', '1', '45', '19', '88', '0', '49', '13', '500', '', '', '1', '1', '2021-07-22 20:40:47', '2021-07-22 20:40:47');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('91', '1', '47', '19', '91', '0', '49', '13', '1000', '', '', '1', '1', '2021-07-22 20:46:19', '2021-07-22 20:46:19');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('92', '1', '62', '19', '92', '0', '49', '13', '500', '', '', '1', '1', '2021-07-22 20:54:01', '2021-07-22 20:54:01');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('95', '1', '34', '19', '95', '0', '49', '13', '500', '', '', '1', '1', '2021-07-22 21:07:55', '2021-07-22 21:07:55');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('96', '1', '47', '19', '96', '0', '49', '13', '500', '', '', '1', '1', '2021-07-22 21:08:40', '2021-07-22 21:08:40');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('97', '1', '48', '19', '97', '0', '49', '13', '500', '', '', '1', '1', '2021-07-22 21:09:18', '2021-07-22 21:09:18');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('98', '1', '63', '19', '98', '0', '49', '13', '1170', '', '', '1', '1', '2021-07-22 21:12:34', '2021-07-22 21:12:34');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('101', '1', '32', '27', '101', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 19:58:39', '2021-07-23 19:58:39');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('102', '1', '60', '27', '102', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:00:00', '2021-07-23 20:00:00');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('103', '1', '27', '27', '103', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:00:38', '2021-07-23 20:00:38');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('104', '1', '58', '27', '104', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:01:47', '2021-07-23 20:01:47');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('105', '1', '52', '27', '105', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:02:29', '2021-07-23 20:02:29');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('106', '1', '51', '27', '106', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:03:45', '2021-07-23 20:03:45');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('107', '1', '33', '27', '107', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:04:22', '2021-07-23 20:04:22');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('108', '1', '35', '27', '108', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:05:01', '2021-07-23 20:05:01');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('109', '1', '48', '27', '109', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:05:30', '2021-07-23 20:05:30');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('110', '1', '49', '27', '110', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:06:08', '2021-07-23 20:06:08');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('111', '1', '34', '27', '111', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:06:51', '2021-07-23 20:06:51');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('112', '1', '50', '27', '112', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:07:30', '2021-07-23 20:07:30');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('113', '1', '56', '27', '113', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:08:12', '2021-07-23 20:08:12');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('114', '1', '46', '27', '114', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:08:45', '2021-07-23 20:08:45');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('115', '1', '64', '27', '115', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:15:40', '2021-07-23 20:15:40');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('116', '1', '57', '27', '116', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:16:05', '2021-07-23 20:16:05');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('117', '1', '62', '27', '117', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:16:42', '2021-07-23 20:16:42');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('118', '1', '26', '27', '118', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:22:14', '2021-07-23 20:22:14');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('119', '1', '41', '27', '119', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:22:45', '2021-07-23 20:22:45');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('120', '1', '28', '27', '120', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:23:10', '2021-07-23 20:23:10');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('121', '1', '31', '27', '121', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:23:57', '2021-07-23 20:23:57');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('123', '1', '29', '27', '123', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:25:36', '2021-07-23 20:25:36');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('124', '1', '44', '27', '124', '0', '47', '3', '500', '', '', '1', '1', '2021-07-23 20:26:11', '2021-07-23 20:26:11');
INSERT INTO `distribute_detail` (`dis_detail_id`, `dis_id`, `e_id`, `pod_id`, `prod_detail_id`, `roll_handel`, `sz_id`, `u_id`, `distribute_pod_quantity`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('125', '1', '53', '27', '125', '0', '47', '3', '700', '', '', '1', '1', '2021-07-23 20:27:01', '2021-07-23 20:27:01');


#
# TABLE STRUCTURE FOR: employees
#

DROP TABLE IF EXISTS `employees`;

CREATE TABLE `employees` (
  `e_id` int(11) NOT NULL AUTO_INCREMENT,
  `e_code` varchar(30) NOT NULL,
  `employee_category` enum('Permanent','Temporary') NOT NULL DEFAULT 'Temporary',
  `name` varchar(99) NOT NULL,
  `emp_adhar_card_number` varchar(20) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `rate_per_bag` decimal(10,2) NOT NULL,
  `due_amount` decimal(10,2) NOT NULL COMMENT 'Updating from check-in detail',
  `father_name` varchar(99) NOT NULL,
  `address` text NOT NULL,
  `dob` date NOT NULL COMMENT 'Birth Date',
  `contact_phone` varchar(10) NOT NULL,
  `employee_email` varchar(50) NOT NULL,
  `doj` date NOT NULL COMMENT 'Joining Date',
  `d_id` int(11) NOT NULL COMMENT 'Department',
  `picture` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`e_id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;

INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('26', 'E1', 'Permanent', 'RINKU KHATUN ', '11111111111', 'Female', '0.35', '0.00', 'AJYAR MIYA ', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 18:02:42', '2021-07-19 18:02:42');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('27', 'E2', '', 'SOMA BARMAN DEBNATH', '579413583397', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1991-07-07', '', '', '2021-07-19', '0', '', '1', '1', '2021-07-19 18:05:46', '2021-07-20 15:29:57');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('28', 'E3', 'Permanent', 'BEAUTY  BIBI', '111111111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 18:07:35', '2021-07-19 18:07:35');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('29', 'E4', 'Permanent', 'MAJIMAN BIBI', '1111111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 18:11:24', '2021-07-19 18:11:24');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('30', 'E5', 'Permanent', 'PRAMILA  DUTTA', '11111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 18:13:02', '2021-07-19 18:13:02');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('31', 'E6', 'Permanent', 'ARPINA PARVIN', '111111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 18:15:28', '2021-07-19 18:15:28');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('32', 'E7', '', 'BHARATI BARMAN', '111111', 'Female', '0.35', '0.00', 'BIMAL BARMAN', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 18:17:44', '2021-07-19 18:17:44');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('33', 'E8', 'Permanent', 'NISHA  DEY', '11111111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 18:19:51', '2021-07-19 18:19:51');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('34', 'E9', 'Permanent', 'SOMA DEY ROY', '111111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 18:21:01', '2021-07-19 18:21:01');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('35', 'E10', 'Permanent', 'MANTI DAS', '11111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 18:22:23', '2021-07-19 18:22:23');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('36', 'E11', 'Permanent', 'JHUMA DAS', '1111111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 18:23:59', '2021-07-19 18:23:59');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('37', 'E12', 'Permanent', 'BIPLAB SARKAR', '11111111', 'Male', '0.35', '0.00', 'BIJAY SARKAR', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 18:25:20', '2021-07-19 18:25:20');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('38', 'E13', 'Permanent', 'SUBAL BARMAN', '111111111', 'Male', '0.35', '0.00', 'NONE', '<p>\n	KALI TOLA</p>\n', '1953-07-07', '', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 18:26:46', '2021-07-19 18:26:46');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('39', 'E14', '', 'JAYA GHOSH', '666281720410', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1972-01-01', '8972388980', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 18:30:10', '2021-07-19 18:30:10');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('40', 'E15', '', 'BIJAYA  DEY', '111111', 'Male', '0.35', '0.00', 'BIMAL  DEY', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 18:31:39', '2021-07-21 19:32:46');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('41', 'E16', 'Permanent', 'RASIDUL ISLAM', '1111111', 'Male', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 18:33:17', '2021-07-19 18:33:17');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('43', 'E18', 'Permanent', 'TUMPA BARMAN ', '11111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-19', '0', '', '1', '1', '2021-07-19 18:35:46', '2021-07-19 18:35:46');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('44', 'E19', 'Permanent', 'MANIR UDDIN MIYA ', '560906219132', 'Male', '0.35', '0.00', 'FAJAR UDDIN MIYA', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 18:38:07', '2021-07-19 18:38:07');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('45', 'E20', 'Permanent', 'MAMATA DEY', '1111111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 18:40:17', '2021-07-19 18:40:17');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('46', 'E21', 'Permanent', 'MOLI DEY', '582742437449', 'Female', '0.35', '0.00', 'PARITOSH DEY', '<p>\n	CHHARARKUTHI</p>\n', '2004-01-01', '8388092396', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 18:42:28', '2021-07-19 18:47:14');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('47', 'E22', 'Permanent', 'TARAMANI DUTTA', '11111111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 18:44:04', '2021-07-19 18:44:04');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('48', 'E23', 'Permanent', 'SHIBANI BANIK', '1111111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 18:45:28', '2021-07-19 18:45:28');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('49', 'E24', 'Permanent', 'RIYA BANIK', '1111111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 18:46:32', '2021-07-19 18:46:32');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('50', 'E25', 'Permanent', 'PINKY KHATUN', '1111111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-19', '1', '', '1', '1', '2021-07-19 19:34:29', '2021-07-19 19:34:29');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('51', 'E25', 'Permanent', 'JHILAN PAUL', '11111', 'Male', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-20', '1', '', '1', '1', '2021-07-20 18:35:35', '2021-07-22 10:40:15');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('52', 'E26', 'Permanent', 'AROTI DAS', '1111111111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARAR KUTHI</p>\n', '1953-07-07', '', '', '2021-07-20', '1', '', '1', '1', '2021-07-20 18:37:51', '2021-07-22 10:40:18');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('53', 'E27', 'Permanent', 'JANOKI BARMAN', '11111111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-20', '1', '', '1', '1', '2021-07-20 18:39:57', '2021-07-22 10:40:21');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('54', 'E28', 'Permanent', 'KULSUM BIBI', '111111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-20', '1', '', '1', '1', '2021-07-20 18:41:54', '2021-07-22 10:40:24');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('55', 'E29', 'Permanent', 'SUSHANTA KAR', '11111', 'Male', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-20', '1', '', '1', '1', '2021-07-20 18:43:49', '2021-07-22 10:40:27');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('56', 'E30', 'Permanent', 'MAHAMUDA BAGOM', '111111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-20', '1', '', '1', '1', '2021-07-20 18:46:26', '2021-07-22 10:40:32');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('57', 'E31', 'Permanent', 'MOHINI ROY', '1111111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARARKUTHI</p>\n', '1953-07-07', '', '', '2021-07-20', '1', '', '1', '1', '2021-07-20 18:48:09', '2021-07-22 10:40:36');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('58', 'E32', 'Permanent', 'MOUMITA BARMAN ', '111111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARAR KUTHI</p>\n', '1953-07-07', '', '', '2021-07-21', '1', '', '1', '1', '2021-07-21 19:29:59', '2021-07-22 10:40:47');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('59', 'E33', 'Permanent', 'KALPANA  BARMAN ', '11111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARAR KUTHI</p>\n', '1953-07-07', '', '', '2021-07-21', '0', '', '1', '1', '2021-07-21 19:38:17', '2021-07-22 10:40:52');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('60', 'E34', 'Permanent', 'JITEN CHANDRA SARKAR', '11111', 'Male', '0.35', '0.00', 'NONE', '<p>\n	CHHARAR KUTHI</p>\n', '1953-07-07', '', '', '2021-07-21', '1', '', '1', '1', '2021-07-21 19:41:34', '2021-07-22 10:40:55');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('61', 'E35', 'Permanent', 'KHALEJA JIYA ', '11111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARAR KUTHI</p>\n', '1953-07-07', '', '', '2021-07-21', '1', '', '1', '1', '2021-07-21 20:09:31', '2021-07-22 10:40:59');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('62', 'E36', 'Permanent', 'KABITA  DEY  ', '11111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARAR KUTHI</p>\n', '1953-07-07', '', '', '2021-07-22', '1', '', '1', '1', '2021-07-22 20:51:27', '2021-07-22 20:51:27');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('63', 'E37', 'Permanent', 'MONIKA BARMAN', '11111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARAR KUTHI</p>\n', '1953-07-07', '', '', '2021-07-22', '1', '', '1', '1', '2021-07-22 21:11:20', '2021-07-22 21:11:20');
INSERT INTO `employees` (`e_id`, `e_code`, `employee_category`, `name`, `emp_adhar_card_number`, `gender`, `rate_per_bag`, `due_amount`, `father_name`, `address`, `dob`, `contact_phone`, `employee_email`, `doj`, `d_id`, `picture`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('64', 'E38', 'Permanent', 'AKHIRINA KHATUN ', '1111', 'Female', '0.35', '0.00', 'NONE', '<p>\n	CHHARAR KUTHI</p>\n', '1953-07-07', '', '', '2021-07-23', '1', '', '1', '1', '2021-07-23 20:13:55', '2021-07-23 20:13:55');


#
# TABLE STRUCTURE FOR: menu_setting
#

DROP TABLE IF EXISTS `menu_setting`;

CREATE TABLE `menu_setting` (
  `menu_setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(20) NOT NULL,
  `users_id` varchar(200) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`menu_setting_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `menu_setting` (`menu_setting_id`, `menu_name`, `users_id`, `user_id`, `create_date`, `modify_date`) VALUES ('1', 'Colours', '1,2', '1', '2021-03-30 23:36:28', '2021-03-30 23:47:43');


#
# TABLE STRUCTURE FOR: mill
#

DROP TABLE IF EXISTS `mill`;

CREATE TABLE `mill` (
  `mill_id` int(11) NOT NULL AUTO_INCREMENT,
  `mill_name` varchar(250) NOT NULL,
  `mill_short_code` varchar(5) NOT NULL,
  `mill_address` text NOT NULL,
  `mill_contact_person` varchar(20) NOT NULL,
  `mill_contact_phone` varchar(10) NOT NULL,
  `mill_contact_cell` varchar(10) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`mill_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `mill` (`mill_id`, `mill_name`, `mill_short_code`, `mill_address`, `mill_contact_person`, `mill_contact_phone`, `mill_contact_cell`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('1', 'BALLAVPUR', 'BLVPR', '<p>\n	DURGAPUR</p>\n<p>\n	&nbsp;</p>\n', '', '7654890890', '', '1', '1', '2021-03-09 23:50:20', '2021-04-01 09:35:32');
INSERT INTO `mill` (`mill_id`, `mill_name`, `mill_short_code`, `mill_address`, `mill_contact_person`, `mill_contact_phone`, `mill_contact_cell`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('3', 'KRISHNA TISSU', 'KRNT', '<p>\n	BURWANI</p>\n<p>\n	&nbsp;</p>\n', '', '8908765545', '', '1', '1', '2021-03-09 23:57:22', '2021-04-01 09:36:12');


#
# TABLE STRUCTURE FOR: production
#

DROP TABLE IF EXISTS `production`;

CREATE TABLE `production` (
  `prod_id` int(11) NOT NULL AUTO_INCREMENT,
  `prod_number` varchar(100) NOT NULL,
  `pod_id` int(11) NOT NULL COMMENT 'PK of purchase_order_details',
  `prod_date` date NOT NULL,
  `prod_bag_produced` decimal(10,2) NOT NULL,
  `total_roll_weight` decimal(10,2) NOT NULL,
  `prod_avg_weight` varchar(20) NOT NULL,
  `expected_production` decimal(10,2) NOT NULL,
  `prod_wastage_pcs` decimal(10,2) DEFAULT NULL,
  `prod_wastage_kg` decimal(10,2) DEFAULT NULL,
  `remarks` text NOT NULL,
  `terms` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`prod_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `production` (`prod_id`, `prod_number`, `pod_id`, `prod_date`, `prod_bag_produced`, `total_roll_weight`, `prod_avg_weight`, `expected_production`, `prod_wastage_pcs`, `prod_wastage_kg`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('2', 'PROD/19072021/064952', '8', '2021-07-19', '12842.00', '381.00', '29', '13137.93', '295.93', '0.09', 'WASTAGE - 297', '', '1', '1', '2021-07-19 18:53:20', '2021-07-21 13:57:59');
INSERT INTO `production` (`prod_id`, `prod_number`, `pod_id`, `prod_date`, `prod_bag_produced`, `total_roll_weight`, `prod_avg_weight`, `expected_production`, `prod_wastage_pcs`, `prod_wastage_kg`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('3', 'PROD/20072021/064856', '23', '2021-07-20', '10682.00', '627.00', '59', '10627.12', '-54.88', '-323792.00', '', '', '1', '1', '2021-07-20 18:51:47', '2021-07-21 13:58:09');
INSERT INTO `production` (`prod_id`, `prod_number`, `pod_id`, `prod_date`, `prod_bag_produced`, `total_roll_weight`, `prod_avg_weight`, `expected_production`, `prod_wastage_pcs`, `prod_wastage_kg`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('4', 'PROD/21072021/061423', '21', '2021-07-21', '10620.00', '598.00', '57', '10491.23', '-128.77', '-0.07', '', '', '1', '1', '2021-07-21 18:16:47', '2021-07-21 20:17:28');
INSERT INTO `production` (`prod_id`, `prod_number`, `pod_id`, `prod_date`, `prod_bag_produced`, `total_roll_weight`, `prod_avg_weight`, `expected_production`, `prod_wastage_pcs`, `prod_wastage_kg`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('5', 'PROD/22-07-2021/08-23-17', '19', '2021-07-22', '10670.00', '619.00', '59', '10491.53', '-178.47', '-0.11', '', '', '1', '1', '2021-07-22 20:27:41', '2021-07-22 21:12:34');
INSERT INTO `production` (`prod_id`, `prod_number`, `pod_id`, `prod_date`, `prod_bag_produced`, `total_roll_weight`, `prod_avg_weight`, `expected_production`, `prod_wastage_pcs`, `prod_wastage_kg`, `remarks`, `terms`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('6', 'PROD/23-07-2021/07-49-54', '27', '2021-07-23', '12200.00', '364.00', '29', '12551.72', '351.72', '0.10', '', '', '1', '1', '2021-07-23 19:52:09', '2021-07-23 20:27:01');


#
# TABLE STRUCTURE FOR: production_detail
#

DROP TABLE IF EXISTS `production_detail`;

CREATE TABLE `production_detail` (
  `prod_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `prod_id` int(11) NOT NULL COMMENT 'PK of production',
  `pod_id` int(11) NOT NULL COMMENT 'PK of purchase_order_details',
  `prod_detail_date` date NOT NULL,
  `sz_id` int(11) NOT NULL COMMENT 'PK of sizes',
  `prod_detail_quantity` decimal(10,2) NOT NULL,
  `miter_start_reading` double NOT NULL,
  `miter_end_reading` double NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`prod_detail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=latin1;

INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('3', '2', '8', '2021-07-19', '47', '500.00', '126430', '126930', '1', '1', '2021-07-19 18:56:38', '2021-07-19 18:56:38');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('4', '2', '8', '2021-07-19', '47', '500.00', '126930', '127430', '1', '1', '2021-07-19 18:59:40', '2021-07-19 18:59:40');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('5', '2', '8', '2021-07-19', '47', '500.00', '127430', '127930', '1', '1', '2021-07-19 19:01:04', '2021-07-19 19:01:04');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('7', '2', '8', '2021-07-19', '47', '500.00', '127930', '128430', '1', '1', '2021-07-19 19:02:03', '2021-07-19 19:02:03');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('8', '2', '8', '2021-07-19', '47', '500.00', '128430', '128930', '1', '1', '2021-07-19 19:02:46', '2021-07-19 19:02:46');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('9', '2', '8', '2021-07-19', '47', '500.00', '128930', '129430', '1', '1', '2021-07-19 19:03:24', '2021-07-19 19:03:24');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('10', '2', '8', '2021-07-19', '47', '500.00', '129430', '129930', '1', '1', '2021-07-19 19:04:01', '2021-07-19 19:04:01');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('12', '2', '8', '2021-07-19', '47', '1000.00', '129930', '130930', '1', '1', '2021-07-19 19:06:52', '2021-07-19 19:06:52');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('13', '2', '8', '2021-07-19', '47', '1000.00', '130930', '131930', '1', '1', '2021-07-19 19:07:45', '2021-07-19 19:07:45');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('14', '2', '8', '2021-07-19', '47', '500.00', '131930', '132430', '1', '1', '2021-07-19 19:08:37', '2021-07-19 19:08:37');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('15', '2', '8', '2021-07-19', '47', '500.00', '132430', '132930', '1', '1', '2021-07-19 19:09:05', '2021-07-19 19:09:05');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('16', '2', '8', '2021-07-19', '47', '500.00', '132930', '133430', '1', '1', '2021-07-19 19:17:41', '2021-07-24 20:54:34');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('17', '2', '8', '2021-07-19', '47', '500.00', '133430', '133930', '1', '1', '2021-07-19 19:25:36', '2021-07-19 19:25:36');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('18', '2', '8', '2021-07-19', '47', '500.00', '133930', '134430', '1', '1', '2021-07-19 19:26:20', '2021-07-19 19:26:20');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('19', '2', '8', '2021-07-19', '47', '500.00', '134430', '134930', '1', '1', '2021-07-19 19:26:57', '2021-07-19 19:26:57');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('20', '2', '8', '2021-07-19', '47', '500.00', '134930', '135430', '1', '1', '2021-07-19 19:27:29', '2021-07-19 19:27:29');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('21', '2', '8', '2021-07-19', '47', '500.00', '135430', '135930', '1', '1', '2021-07-19 19:28:02', '2021-07-19 19:28:02');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('22', '2', '8', '2021-07-19', '47', '500.00', '135930', '136430', '1', '1', '2021-07-19 19:28:34', '2021-07-19 19:28:34');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('23', '2', '8', '2021-07-19', '47', '500.00', '136430', '136930', '1', '1', '2021-07-19 19:29:06', '2021-07-19 19:29:06');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('24', '2', '8', '2021-07-19', '47', '500.00', '136930', '137430', '1', '1', '2021-07-19 19:29:47', '2021-07-19 19:29:47');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('25', '2', '8', '2021-07-19', '47', '500.00', '137430', '137930', '1', '1', '2021-07-19 19:30:19', '2021-07-19 19:30:19');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('26', '2', '8', '2021-07-19', '47', '500.00', '137930', '138430', '1', '1', '2021-07-19 19:31:05', '2021-07-19 19:31:05');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('27', '2', '8', '2021-07-19', '47', '500.00', '138430', '138930', '1', '1', '2021-07-19 19:37:42', '2021-07-19 19:37:42');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('28', '2', '8', '2021-07-19', '47', '342.00', '138930', '139272', '1', '1', '2021-07-19 19:39:30', '2021-07-19 19:39:30');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('30', '3', '23', '2021-07-20', '49', '500.00', '139270', '139770', '1', '1', '2021-07-20 19:04:17', '2021-07-20 19:04:17');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('31', '3', '23', '2021-07-20', '49', '500.00', '139770', '140270', '1', '1', '2021-07-20 19:07:32', '2021-07-20 19:07:32');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('32', '3', '23', '2021-07-20', '49', '500.00', '140270', '140770', '1', '1', '2021-07-20 19:08:40', '2021-07-20 19:08:40');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('33', '3', '23', '2021-07-20', '49', '500.00', '140770', '141270', '1', '1', '2021-07-20 19:09:37', '2021-07-20 19:09:37');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('34', '3', '23', '2021-07-20', '49', '500.00', '141270', '141770', '1', '1', '2021-07-20 19:10:14', '2021-07-20 19:10:14');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('35', '3', '23', '2021-07-20', '49', '500.00', '141770', '142270', '1', '1', '2021-07-20 19:11:06', '2021-07-20 19:11:06');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('36', '3', '23', '2021-07-20', '49', '500.00', '142270', '142770', '1', '1', '2021-07-20 19:11:44', '2021-07-20 19:11:44');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('37', '3', '23', '2021-07-20', '49', '500.00', '142770', '143270', '1', '1', '2021-07-20 19:12:31', '2021-07-20 19:12:31');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('38', '3', '23', '2021-07-20', '49', '500.00', '143270', '143770', '1', '1', '2021-07-20 19:13:10', '2021-07-20 19:13:10');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('39', '3', '23', '2021-07-20', '49', '500.00', '143770', '144270', '1', '1', '2021-07-20 19:13:47', '2021-07-20 19:13:47');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('40', '3', '23', '2021-07-20', '49', '500.00', '144270', '144770', '1', '1', '2021-07-20 19:14:24', '2021-07-20 19:14:24');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('41', '3', '23', '2021-07-20', '49', '500.00', '144770', '145270', '1', '1', '2021-07-20 19:15:08', '2021-07-20 19:15:08');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('42', '3', '23', '2021-07-20', '49', '500.00', '145270', '145770', '1', '1', '2021-07-20 19:15:56', '2021-07-20 19:15:56');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('43', '3', '23', '2021-07-20', '49', '500.00', '145770', '146270', '1', '1', '2021-07-20 19:16:29', '2021-07-20 19:16:29');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('44', '3', '23', '2021-07-20', '49', '500.00', '146270', '146770', '1', '1', '2021-07-20 19:17:17', '2021-07-20 19:17:17');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('45', '3', '23', '2021-07-20', '49', '500.00', '146770', '147270', '1', '1', '2021-07-20 19:18:14', '2021-07-20 19:18:14');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('46', '3', '23', '2021-07-20', '49', '500.00', '147270', '147770', '1', '1', '2021-07-20 19:19:09', '2021-07-20 19:19:09');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('47', '3', '23', '2021-07-20', '49', '500.00', '147770', '148270', '1', '1', '2021-07-20 19:20:53', '2021-07-20 19:20:53');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('48', '3', '23', '2021-07-20', '49', '500.00', '148270', '148770', '1', '1', '2021-07-20 19:21:31', '2021-07-20 19:21:31');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('49', '3', '23', '2021-07-20', '49', '500.00', '148770', '149270', '1', '1', '2021-07-20 19:22:13', '2021-07-20 19:22:13');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('50', '3', '23', '2021-07-20', '49', '500.00', '149270', '149770', '1', '1', '2021-07-20 19:22:52', '2021-07-20 19:22:52');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('51', '3', '23', '2021-07-20', '49', '182.00', '149770', '149952', '1', '1', '2021-07-20 19:23:43', '2021-07-20 19:23:43');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('55', '4', '21', '2021-07-21', '49', '500.00', '149950', '150450', '1', '1', '2021-07-21 18:33:36', '2021-07-21 18:33:36');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('56', '4', '21', '2021-07-21', '49', '500.00', '150450', '150950', '1', '1', '2021-07-21 18:38:15', '2021-07-21 18:38:15');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('57', '4', '21', '2021-07-21', '49', '500.00', '150950', '151450', '1', '1', '2021-07-21 19:49:18', '2021-07-21 19:49:18');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('58', '4', '21', '2021-07-21', '49', '500.00', '151450', '151950', '1', '1', '2021-07-21 19:50:16', '2021-07-21 19:50:16');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('59', '4', '21', '2021-07-21', '49', '500.00', '151950', '152450', '1', '1', '2021-07-21 19:50:57', '2021-07-21 19:50:57');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('60', '4', '21', '2021-07-21', '49', '500.00', '152450', '152950', '1', '1', '2021-07-21 19:51:47', '2021-07-21 19:51:47');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('61', '4', '21', '2021-07-21', '49', '500.00', '152950', '153450', '1', '1', '2021-07-21 19:53:44', '2021-07-21 19:53:44');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('62', '4', '21', '2021-07-21', '49', '500.00', '153450', '153950', '1', '1', '2021-07-21 19:54:21', '2021-07-21 19:54:21');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('63', '4', '21', '2021-07-21', '49', '500.00', '153950', '154450', '1', '1', '2021-07-21 19:57:54', '2021-07-21 19:57:54');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('64', '4', '21', '2021-07-21', '49', '500.00', '154450', '154950', '1', '1', '2021-07-21 19:58:39', '2021-07-21 19:58:39');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('65', '4', '21', '2021-07-21', '49', '500.00', '154950', '155450', '1', '1', '2021-07-21 19:59:21', '2021-07-21 19:59:21');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('66', '4', '21', '2021-07-21', '49', '500.00', '155450', '155950', '1', '1', '2021-07-21 20:00:08', '2021-07-21 20:00:08');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('67', '4', '21', '2021-07-21', '49', '500.00', '155950', '156450', '1', '1', '2021-07-21 20:01:10', '2021-07-21 20:01:10');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('68', '4', '21', '2021-07-21', '49', '500.00', '156450', '156950', '1', '1', '2021-07-21 20:01:52', '2021-07-21 20:01:52');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('69', '4', '21', '2021-07-21', '49', '500.00', '156950', '157450', '1', '1', '2021-07-21 20:11:34', '2021-07-21 20:11:34');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('70', '4', '21', '2021-07-21', '49', '500.00', '157450', '157950', '1', '1', '2021-07-21 20:12:36', '2021-07-21 20:12:36');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('71', '4', '21', '2021-07-21', '49', '500.00', '157950', '158450', '1', '1', '2021-07-21 20:13:50', '2021-07-21 20:13:50');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('72', '4', '21', '2021-07-21', '49', '500.00', '158450', '158950', '1', '1', '2021-07-21 20:14:57', '2021-07-21 20:14:57');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('73', '4', '21', '2021-07-21', '49', '500.00', '158950', '159450', '1', '1', '2021-07-21 20:15:31', '2021-07-21 20:15:31');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('74', '4', '21', '2021-07-21', '49', '500.00', '159450', '159950', '1', '1', '2021-07-21 20:16:33', '2021-07-21 20:16:33');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('75', '4', '21', '2021-07-21', '49', '620.00', '159950', '160570', '1', '1', '2021-07-21 20:17:28', '2021-07-21 20:17:28');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('76', '5', '19', '2021-07-22', '49', '500.00', '160570', '161070', '1', '1', '2021-07-22 20:29:04', '2021-07-22 20:29:04');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('77', '5', '19', '2021-07-22', '49', '500.00', '161070', '161570', '1', '1', '2021-07-22 20:29:34', '2021-07-22 20:29:34');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('78', '5', '19', '2021-07-22', '49', '500.00', '161570', '162070', '1', '1', '2021-07-22 20:30:06', '2021-07-22 20:30:06');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('79', '5', '19', '2021-07-22', '49', '500.00', '162070', '162570', '1', '1', '2021-07-22 20:31:31', '2021-07-22 20:31:31');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('80', '5', '19', '2021-07-22', '49', '500.00', '162570', '163070', '1', '1', '2021-07-22 20:32:10', '2021-07-22 20:32:10');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('81', '5', '19', '2021-07-22', '49', '500.00', '163070', '163570', '1', '1', '2021-07-22 20:32:52', '2021-07-22 20:32:52');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('82', '5', '19', '2021-07-22', '49', '500.00', '163570', '164070', '1', '1', '2021-07-22 20:33:42', '2021-07-22 20:33:42');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('83', '5', '19', '2021-07-22', '49', '500.00', '164070', '164570', '1', '1', '2021-07-22 20:36:41', '2021-07-22 20:36:41');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('84', '5', '19', '2021-07-22', '49', '500.00', '164570', '165070', '1', '1', '2021-07-22 20:37:10', '2021-07-22 20:37:10');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('85', '5', '19', '2021-07-22', '49', '500.00', '165070', '165570', '1', '1', '2021-07-22 20:38:02', '2021-07-22 20:38:02');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('86', '5', '19', '2021-07-22', '49', '500.00', '165570', '166070', '1', '1', '2021-07-22 20:38:43', '2021-07-22 20:38:43');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('87', '5', '19', '2021-07-22', '49', '500.00', '166070', '166570', '1', '1', '2021-07-22 20:39:15', '2021-07-22 20:39:15');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('88', '5', '19', '2021-07-22', '49', '500.00', '166570', '167070', '1', '1', '2021-07-22 20:40:47', '2021-07-22 20:40:47');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('91', '5', '19', '2021-07-22', '49', '1000.00', '167070', '168070', '1', '1', '2021-07-22 20:46:19', '2021-07-22 20:46:19');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('92', '5', '19', '2021-07-22', '49', '500.00', '168070', '168570', '1', '1', '2021-07-22 20:54:01', '2021-07-22 20:54:01');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('95', '5', '19', '2021-07-22', '49', '500.00', '168570', '169070', '1', '1', '2021-07-22 21:07:55', '2021-07-22 21:07:55');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('96', '5', '19', '2021-07-22', '49', '500.00', '169070', '169570', '1', '1', '2021-07-22 21:08:40', '2021-07-22 21:08:40');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('97', '5', '19', '2021-07-22', '49', '500.00', '169570', '170070', '1', '1', '2021-07-22 21:09:18', '2021-07-22 21:09:18');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('98', '5', '19', '2021-07-22', '49', '1170.00', '170070', '171240', '1', '1', '2021-07-22 21:12:34', '2021-07-22 21:12:34');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('101', '6', '27', '2021-07-23', '47', '500.00', '171240', '171740', '1', '1', '2021-07-23 19:58:39', '2021-07-23 19:58:39');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('102', '6', '27', '2021-07-23', '47', '500.00', '171740', '172240', '1', '1', '2021-07-23 20:00:00', '2021-07-23 20:00:00');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('103', '6', '27', '2021-07-23', '47', '500.00', '172240', '172740', '1', '1', '2021-07-23 20:00:38', '2021-07-23 20:00:38');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('104', '6', '27', '2021-07-23', '47', '500.00', '172740', '173240', '1', '1', '2021-07-23 20:01:47', '2021-07-23 20:01:47');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('105', '6', '27', '2021-07-23', '47', '500.00', '173240', '173740', '1', '1', '2021-07-23 20:02:29', '2021-07-23 20:02:29');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('106', '6', '27', '2021-07-23', '47', '500.00', '173740', '174240', '1', '1', '2021-07-23 20:03:45', '2021-07-23 20:03:45');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('107', '6', '27', '2021-07-23', '47', '500.00', '174240', '174740', '1', '1', '2021-07-23 20:04:22', '2021-07-23 20:04:22');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('108', '6', '27', '2021-07-23', '47', '500.00', '174740', '175240', '1', '1', '2021-07-23 20:05:01', '2021-07-23 20:05:01');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('109', '6', '27', '2021-07-23', '47', '500.00', '175240', '175740', '1', '1', '2021-07-23 20:05:30', '2021-07-23 20:05:30');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('110', '6', '27', '2021-07-23', '47', '500.00', '175740', '176240', '1', '1', '2021-07-23 20:06:08', '2021-07-23 20:06:08');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('111', '6', '27', '2021-07-23', '47', '500.00', '176240', '176740', '1', '1', '2021-07-23 20:06:51', '2021-07-23 20:06:51');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('112', '6', '27', '2021-07-23', '47', '500.00', '176740', '177240', '1', '1', '2021-07-23 20:07:30', '2021-07-23 20:07:30');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('113', '6', '27', '2021-07-23', '47', '500.00', '177240', '177740', '1', '1', '2021-07-23 20:08:12', '2021-07-23 20:08:12');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('114', '6', '27', '2021-07-23', '47', '500.00', '177740', '178240', '1', '1', '2021-07-23 20:08:45', '2021-07-23 20:08:45');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('115', '6', '27', '2021-07-23', '47', '500.00', '178240', '178740', '1', '1', '2021-07-23 20:15:40', '2021-07-23 20:15:40');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('116', '6', '27', '2021-07-23', '47', '500.00', '178740', '179240', '1', '1', '2021-07-23 20:16:05', '2021-07-23 20:16:05');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('117', '6', '27', '2021-07-23', '47', '500.00', '179240', '179740', '1', '1', '2021-07-23 20:16:42', '2021-07-23 20:16:42');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('118', '6', '27', '2021-07-23', '47', '500.00', '179740', '180240', '1', '1', '2021-07-23 20:22:14', '2021-07-23 20:22:14');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('119', '6', '27', '2021-07-23', '47', '500.00', '180240', '180740', '1', '1', '2021-07-23 20:22:45', '2021-07-23 20:22:45');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('120', '6', '27', '2021-07-23', '47', '500.00', '180740', '181240', '1', '1', '2021-07-23 20:23:10', '2021-07-23 20:23:10');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('121', '6', '27', '2021-07-23', '47', '500.00', '181240', '181740', '1', '1', '2021-07-23 20:23:57', '2021-07-23 20:23:57');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('123', '6', '27', '2021-07-23', '47', '500.00', '181740', '182240', '1', '1', '2021-07-23 20:25:36', '2021-07-23 20:25:36');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('124', '6', '27', '2021-07-23', '47', '500.00', '182240', '182740', '1', '1', '2021-07-23 20:26:11', '2021-07-23 20:26:11');
INSERT INTO `production_detail` (`prod_detail_id`, `prod_id`, `pod_id`, `prod_detail_date`, `sz_id`, `prod_detail_quantity`, `miter_start_reading`, `miter_end_reading`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('125', '6', '27', '2021-07-23', '47', '700.00', '182740', '183440', '1', '1', '2021-07-23 20:27:01', '2021-07-23 20:27:01');


#
# TABLE STRUCTURE FOR: purchase_order
#

DROP TABLE IF EXISTS `purchase_order`;

CREATE TABLE `purchase_order` (
  `po_id` int(11) NOT NULL AUTO_INCREMENT,
  `po_number` varchar(100) NOT NULL,
  `am_id` int(11) NOT NULL COMMENT 'acc_master',
  `mill_id` int(11) DEFAULT NULL COMMENT 'mill',
  `po_invoice_number` varchar(20) NOT NULL,
  `po_date` date NOT NULL,
  `po_delivery_date` date NOT NULL,
  `img` varchar(200) NOT NULL,
  `remarks` text NOT NULL,
  `terms` text NOT NULL,
  `po_total` double NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`po_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `purchase_order` (`po_id`, `po_number`, `am_id`, `mill_id`, `po_invoice_number`, `po_date`, `po_delivery_date`, `img`, `remarks`, `terms`, `po_total`, `status`, `user_id`, `create_date`, `modified_date`) VALUES ('2', 'PO/19072021/112227', '12', '0', '', '2021-07-14', '2021-07-18', '', 'Mill Inv No - BPML/1068/21-22', '', '0', '1', '1', '2021-07-19 11:25:59', '2021-07-21 17:28:37');


#
# TABLE STRUCTURE FOR: purchase_order_details
#

DROP TABLE IF EXISTS `purchase_order_details`;

CREATE TABLE `purchase_order_details` (
  `pod_id` int(11) NOT NULL AUTO_INCREMENT,
  `po_id` int(11) NOT NULL COMMENT 'purchase_order id',
  `roll_handel` tinyint(1) DEFAULT NULL COMMENT '0=Roll, 1=Handel',
  `roll_weight` decimal(10,3) DEFAULT NULL,
  `c_id` int(11) DEFAULT NULL COMMENT 'PK of colors',
  `sz_id` int(11) DEFAULT NULL COMMENT 'PK of sizes',
  `size_in_text` varchar(20) DEFAULT NULL,
  `pod_quantity` double DEFAULT NULL,
  `u_id` int(11) DEFAULT NULL COMMENT 'PK of units',
  `rate_per_unit` decimal(10,3) DEFAULT NULL,
  `pod_total` decimal(10,3) DEFAULT NULL COMMENT 'virtual field',
  `pod_remarks` text,
  `consignement_number` varchar(50) NOT NULL,
  `paper_gsm` int(11) DEFAULT NULL,
  `paper_bf` int(11) DEFAULT NULL,
  `total_no_of_reel` int(11) NOT NULL DEFAULT '1',
  `production_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=No Production, 1=Production Done',
  `distribute_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=Distribute Remaining, 1=All Distributed',
  `check_in_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=No Received, 1=All received',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pod_id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

INSERT INTO `purchase_order_details` (`pod_id`, `po_id`, `roll_handel`, `roll_weight`, `c_id`, `sz_id`, `size_in_text`, `pod_quantity`, `u_id`, `rate_per_unit`, `pod_total`, `pod_remarks`, `consignement_number`, `paper_gsm`, `paper_bf`, `total_no_of_reel`, `production_status`, `distribute_status`, `check_in_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('7', '2', '0', '0.313', '13', NULL, '25', '1', '13', '36250.000', '36250.000', '', '1907112559', '120', '20', '1', '0', '0', '0', '1', '1', '2021-07-19 11:28:27', '2021-07-19 11:54:09');
INSERT INTO `purchase_order_details` (`pod_id`, `po_id`, `roll_handel`, `roll_weight`, `c_id`, `sz_id`, `size_in_text`, `pod_quantity`, `u_id`, `rate_per_unit`, `pod_total`, `pod_remarks`, `consignement_number`, `paper_gsm`, `paper_bf`, `total_no_of_reel`, `production_status`, `distribute_status`, `check_in_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('8', '2', '0', '2.144', '13', NULL, '31', '1', '13', '36250.000', '36250.000', '', '1907112827', '120', '20', '5', '1', '0', '0', '1', '1', '2021-07-19 11:32:13', '2021-07-29 11:08:45');
INSERT INTO `purchase_order_details` (`pod_id`, `po_id`, `roll_handel`, `roll_weight`, `c_id`, `sz_id`, `size_in_text`, `pod_quantity`, `u_id`, `rate_per_unit`, `pod_total`, `pod_remarks`, `consignement_number`, `paper_gsm`, `paper_bf`, `total_no_of_reel`, `production_status`, `distribute_status`, `check_in_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('9', '2', '0', '2.144', '13', NULL, '35', '1', '13', '36250.000', '77720.000', '', '1907112828', '120', '20', '5', '0', '0', '0', '1', '1', '2021-07-19 11:32:13', '2021-07-19 11:32:13');
INSERT INTO `purchase_order_details` (`pod_id`, `po_id`, `roll_handel`, `roll_weight`, `c_id`, `sz_id`, `size_in_text`, `pod_quantity`, `u_id`, `rate_per_unit`, `pod_total`, `pod_remarks`, `consignement_number`, `paper_gsm`, `paper_bf`, `total_no_of_reel`, `production_status`, `distribute_status`, `check_in_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('10', '2', '0', '2.144', '13', NULL, '35', '1', '13', '36250.000', '77720.000', '', '1907112829', '120', '20', '5', '0', '0', '0', '1', '1', '2021-07-19 11:32:13', '2021-07-19 11:32:13');
INSERT INTO `purchase_order_details` (`pod_id`, `po_id`, `roll_handel`, `roll_weight`, `c_id`, `sz_id`, `size_in_text`, `pod_quantity`, `u_id`, `rate_per_unit`, `pod_total`, `pod_remarks`, `consignement_number`, `paper_gsm`, `paper_bf`, `total_no_of_reel`, `production_status`, `distribute_status`, `check_in_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('11', '2', '0', '2.144', '13', NULL, '35', '1', '13', '36250.000', '77720.000', '', '1907112830', '120', '20', '5', '0', '0', '0', '1', '1', '2021-07-19 11:32:13', '2021-07-19 11:32:13');
INSERT INTO `purchase_order_details` (`pod_id`, `po_id`, `roll_handel`, `roll_weight`, `c_id`, `sz_id`, `size_in_text`, `pod_quantity`, `u_id`, `rate_per_unit`, `pod_total`, `pod_remarks`, `consignement_number`, `paper_gsm`, `paper_bf`, `total_no_of_reel`, `production_status`, `distribute_status`, `check_in_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('12', '2', '0', '2.144', '13', NULL, '35', '1', '13', '36250.000', '77720.000', '', '1907112831', '120', '20', '5', '0', '0', '0', '1', '1', '2021-07-19 11:32:13', '2021-07-19 11:32:13');
INSERT INTO `purchase_order_details` (`pod_id`, `po_id`, `roll_handel`, `roll_weight`, `c_id`, `sz_id`, `size_in_text`, `pod_quantity`, `u_id`, `rate_per_unit`, `pod_total`, `pod_remarks`, `consignement_number`, `paper_gsm`, `paper_bf`, `total_no_of_reel`, `production_status`, `distribute_status`, `check_in_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('13', '2', '0', '1.844', '13', NULL, '47', '1', '13', '36250.000', '66845.000', '', '1907113213', '120', '20', '3', '0', '0', '0', '1', '1', '2021-07-19 11:33:08', '2021-07-19 11:33:08');
INSERT INTO `purchase_order_details` (`pod_id`, `po_id`, `roll_handel`, `roll_weight`, `c_id`, `sz_id`, `size_in_text`, `pod_quantity`, `u_id`, `rate_per_unit`, `pod_total`, `pod_remarks`, `consignement_number`, `paper_gsm`, `paper_bf`, `total_no_of_reel`, `production_status`, `distribute_status`, `check_in_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('14', '2', '0', '1.844', '13', NULL, '47', '1', '13', '36250.000', '66845.000', '', '1907113214', '120', '20', '3', '0', '0', '0', '1', '1', '2021-07-19 11:33:08', '2021-07-19 11:33:08');
INSERT INTO `purchase_order_details` (`pod_id`, `po_id`, `roll_handel`, `roll_weight`, `c_id`, `sz_id`, `size_in_text`, `pod_quantity`, `u_id`, `rate_per_unit`, `pod_total`, `pod_remarks`, `consignement_number`, `paper_gsm`, `paper_bf`, `total_no_of_reel`, `production_status`, `distribute_status`, `check_in_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('15', '2', '0', '1.844', '13', NULL, '47', '1', '13', '36250.000', '66845.000', '', '1907113215', '120', '20', '3', '0', '0', '0', '1', '1', '2021-07-19 11:33:08', '2021-07-19 11:33:08');
INSERT INTO `purchase_order_details` (`pod_id`, `po_id`, `roll_handel`, `roll_weight`, `c_id`, `sz_id`, `size_in_text`, `pod_quantity`, `u_id`, `rate_per_unit`, `pod_total`, `pod_remarks`, `consignement_number`, `paper_gsm`, `paper_bf`, `total_no_of_reel`, `production_status`, `distribute_status`, `check_in_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('16', '2', '0', '2.221', '13', NULL, '31', '1', '13', '36250.000', '80511.250', '', '1907113308', '120', '20', '6', '0', '0', '0', '1', '1', '2021-07-19 11:34:09', '2021-07-19 11:34:09');
INSERT INTO `purchase_order_details` (`pod_id`, `po_id`, `roll_handel`, `roll_weight`, `c_id`, `sz_id`, `size_in_text`, `pod_quantity`, `u_id`, `rate_per_unit`, `pod_total`, `pod_remarks`, `consignement_number`, `paper_gsm`, `paper_bf`, `total_no_of_reel`, `production_status`, `distribute_status`, `check_in_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('17', '2', '0', '2.221', '13', NULL, '31', '1', '13', '36250.000', '80511.250', '', '1907113309', '120', '20', '6', '0', '0', '0', '1', '1', '2021-07-19 11:34:09', '2021-07-19 11:34:09');
INSERT INTO `purchase_order_details` (`pod_id`, `po_id`, `roll_handel`, `roll_weight`, `c_id`, `sz_id`, `size_in_text`, `pod_quantity`, `u_id`, `rate_per_unit`, `pod_total`, `pod_remarks`, `consignement_number`, `paper_gsm`, `paper_bf`, `total_no_of_reel`, `production_status`, `distribute_status`, `check_in_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('18', '2', '0', '2.221', '13', NULL, '31', '1', '13', '36250.000', '80511.250', '', '1907113310', '120', '20', '6', '0', '0', '0', '1', '1', '2021-07-19 11:34:09', '2021-07-19 11:34:09');
INSERT INTO `purchase_order_details` (`pod_id`, `po_id`, `roll_handel`, `roll_weight`, `c_id`, `sz_id`, `size_in_text`, `pod_quantity`, `u_id`, `rate_per_unit`, `pod_total`, `pod_remarks`, `consignement_number`, `paper_gsm`, `paper_bf`, `total_no_of_reel`, `production_status`, `distribute_status`, `check_in_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('19', '2', '0', '2.221', '13', NULL, '31', '1', '13', '36250.000', '80511.250', '', '1907113311', '120', '20', '6', '1', '0', '0', '1', '1', '2021-07-19 11:34:09', '2021-07-22 20:27:41');
INSERT INTO `purchase_order_details` (`pod_id`, `po_id`, `roll_handel`, `roll_weight`, `c_id`, `sz_id`, `size_in_text`, `pod_quantity`, `u_id`, `rate_per_unit`, `pod_total`, `pod_remarks`, `consignement_number`, `paper_gsm`, `paper_bf`, `total_no_of_reel`, `production_status`, `distribute_status`, `check_in_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('20', '2', '0', '2.221', '13', NULL, '31', '1', '13', '36250.000', '80511.250', '', '1907113312', '120', '20', '6', '0', '0', '0', '1', '1', '2021-07-19 11:34:09', '2021-07-19 11:34:09');
INSERT INTO `purchase_order_details` (`pod_id`, `po_id`, `roll_handel`, `roll_weight`, `c_id`, `sz_id`, `size_in_text`, `pod_quantity`, `u_id`, `rate_per_unit`, `pod_total`, `pod_remarks`, `consignement_number`, `paper_gsm`, `paper_bf`, `total_no_of_reel`, `production_status`, `distribute_status`, `check_in_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('21', '2', '0', '2.221', '13', NULL, '31', '1', '13', '36250.000', '80511.250', '', '1907113313', '120', '20', '6', '1', '0', '0', '1', '1', '2021-07-19 11:34:09', '2021-07-21 18:16:47');
INSERT INTO `purchase_order_details` (`pod_id`, `po_id`, `roll_handel`, `roll_weight`, `c_id`, `sz_id`, `size_in_text`, `pod_quantity`, `u_id`, `rate_per_unit`, `pod_total`, `pod_remarks`, `consignement_number`, `paper_gsm`, `paper_bf`, `total_no_of_reel`, `production_status`, `distribute_status`, `check_in_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('22', '2', '0', '3.250', '13', NULL, '41', '1', '13', '36250.000', '117812.500', '', '1907113409', '120', '20', '6', '0', '0', '0', '1', '1', '2021-07-19 11:35:14', '2021-07-19 11:35:14');
INSERT INTO `purchase_order_details` (`pod_id`, `po_id`, `roll_handel`, `roll_weight`, `c_id`, `sz_id`, `size_in_text`, `pod_quantity`, `u_id`, `rate_per_unit`, `pod_total`, `pod_remarks`, `consignement_number`, `paper_gsm`, `paper_bf`, `total_no_of_reel`, `production_status`, `distribute_status`, `check_in_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('23', '2', '0', '3.250', '13', NULL, '41', '1', '13', '36250.000', '117812.500', '', '1907113410', '120', '20', '6', '1', '0', '0', '1', '1', '2021-07-19 11:35:14', '2021-07-20 18:51:47');
INSERT INTO `purchase_order_details` (`pod_id`, `po_id`, `roll_handel`, `roll_weight`, `c_id`, `sz_id`, `size_in_text`, `pod_quantity`, `u_id`, `rate_per_unit`, `pod_total`, `pod_remarks`, `consignement_number`, `paper_gsm`, `paper_bf`, `total_no_of_reel`, `production_status`, `distribute_status`, `check_in_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('24', '2', '0', '3.250', '13', NULL, '41', '1', '13', '36250.000', '117812.500', '', '1907113411', '120', '20', '6', '0', '0', '0', '1', '1', '2021-07-19 11:35:14', '2021-07-19 11:35:14');
INSERT INTO `purchase_order_details` (`pod_id`, `po_id`, `roll_handel`, `roll_weight`, `c_id`, `sz_id`, `size_in_text`, `pod_quantity`, `u_id`, `rate_per_unit`, `pod_total`, `pod_remarks`, `consignement_number`, `paper_gsm`, `paper_bf`, `total_no_of_reel`, `production_status`, `distribute_status`, `check_in_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('25', '2', '0', '3.250', '13', NULL, '41', '1', '13', '36250.000', '117812.500', '', '1907113412', '120', '20', '6', '0', '0', '0', '1', '1', '2021-07-19 11:35:14', '2021-07-19 11:35:14');
INSERT INTO `purchase_order_details` (`pod_id`, `po_id`, `roll_handel`, `roll_weight`, `c_id`, `sz_id`, `size_in_text`, `pod_quantity`, `u_id`, `rate_per_unit`, `pod_total`, `pod_remarks`, `consignement_number`, `paper_gsm`, `paper_bf`, `total_no_of_reel`, `production_status`, `distribute_status`, `check_in_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('26', '2', '0', '3.250', '13', NULL, '41', '1', '13', '36250.000', '117812.500', '', '1907113413', '120', '20', '6', '0', '0', '0', '1', '1', '2021-07-19 11:35:14', '2021-07-19 11:35:14');
INSERT INTO `purchase_order_details` (`pod_id`, `po_id`, `roll_handel`, `roll_weight`, `c_id`, `sz_id`, `size_in_text`, `pod_quantity`, `u_id`, `rate_per_unit`, `pod_total`, `pod_remarks`, `consignement_number`, `paper_gsm`, `paper_bf`, `total_no_of_reel`, `production_status`, `distribute_status`, `check_in_status`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('27', '2', '0', '3.250', '13', NULL, '41', '1', '13', '36250.000', '117812.500', '', '1907113414', '120', '20', '6', '1', '0', '0', '1', '1', '2021-07-19 11:35:14', '2021-07-23 19:58:39');


#
# TABLE STRUCTURE FOR: sizes
#

DROP TABLE IF EXISTS `sizes`;

CREATE TABLE `sizes` (
  `sz_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(220) NOT NULL,
  `size` varchar(99) NOT NULL,
  `info` varchar(99) NOT NULL,
  `paper_gsm` int(11) NOT NULL,
  `paper_bf` int(11) NOT NULL,
  `rate_per_unit` decimal(10,2) NOT NULL COMMENT 'rate for customer Order & Customer Invoice',
  `hsn_code` int(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sz_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;

INSERT INTO `sizes` (`sz_id`, `product_name`, `size`, `info`, `paper_gsm`, `paper_bf`, `rate_per_unit`, `hsn_code`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('41', 'BROWN  BAG SB 810', 'W 8 XH 10XG 3.5', 'Inch', '120', '20', '3.80', '48195090', '1', '1', '2021-07-19 16:54:36', '2021-07-26 19:48:30');
INSERT INTO `sizes` (`sz_id`, `product_name`, `size`, `info`, `paper_gsm`, `paper_bf`, `rate_per_unit`, `hsn_code`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('43', 'BROWN  BAG SB 1113', 'W 11 XH 13 XG 4', '', '120', '20', '5.00', '48195090', '1', '1', '2021-07-19 16:55:53', '2021-07-26 19:50:09');
INSERT INTO `sizes` (`sz_id`, `product_name`, `size`, `info`, `paper_gsm`, `paper_bf`, `rate_per_unit`, `hsn_code`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('44', 'BROWN  BAG SB 1317', 'W 13 XH 17 XG 4', '', '120', '20', '5.80', '48195090', '1', '1', '2021-07-19 16:56:30', '2021-07-26 19:50:09');
INSERT INTO `sizes` (`sz_id`, `product_name`, `size`, `info`, `paper_gsm`, `paper_bf`, `rate_per_unit`, `hsn_code`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('45', 'BROWN BAG SB 1216', 'W 12 XH 16 XG 5', '', '120', '20', '5.80', '48195090', '1', '1', '2021-07-19 16:57:33', '2021-07-26 19:50:09');
INSERT INTO `sizes` (`sz_id`, `product_name`, `size`, `info`, `paper_gsm`, `paper_bf`, `rate_per_unit`, `hsn_code`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('46', 'BROWN  BAG SB 1613', 'W 16 XH 13 XG 4', '', '120', '20', '5.60', '48195090', '1', '1', '2021-07-19 16:59:49', '2021-07-26 19:50:09');
INSERT INTO `sizes` (`sz_id`, `product_name`, `size`, `info`, `paper_gsm`, `paper_bf`, `rate_per_unit`, `hsn_code`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('47', 'BROWN  BAG HG 96', 'W 9 XH 8 XG 6', '', '120', '20', '4.30', '48195090', '1', '1', '2021-07-19 17:00:52', '2021-07-26 19:50:09');
INSERT INTO `sizes` (`sz_id`, `product_name`, `size`, `info`, `paper_gsm`, `paper_bf`, `rate_per_unit`, `hsn_code`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('48', 'BROWN  BAG HG 119', 'W 11 XH 9 XG 9', '', '120', '20', '5.50', '48195090', '1', '1', '2021-07-19 17:01:52', '2021-07-26 19:46:23');
INSERT INTO `sizes` (`sz_id`, `product_name`, `size`, `info`, `paper_gsm`, `paper_bf`, `rate_per_unit`, `hsn_code`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('49', 'BROWN BAG HG 1310', 'W 13 XH 10 XG 10', '', '120', '20', '5.80', '48195090', '1', '1', '2021-07-19 17:03:08', '2021-07-26 19:50:09');
INSERT INTO `sizes` (`sz_id`, `product_name`, `size`, `info`, `paper_gsm`, `paper_bf`, `rate_per_unit`, `hsn_code`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('50', 'BROWN BAG HG 1312', 'W 13 XH 10 XG 12', '', '120', '20', '6.50', '48195090', '1', '1', '2021-07-19 17:06:09', '2021-07-26 19:50:09');


#
# TABLE STRUCTURE FOR: transporter
#

DROP TABLE IF EXISTS `transporter`;

CREATE TABLE `transporter` (
  `transporter_id` int(11) NOT NULL AUTO_INCREMENT,
  `transporter_name` varchar(250) NOT NULL,
  `transporter_cn_number` varchar(50) NOT NULL,
  `transporter_address` text NOT NULL,
  `transporter_contact_person` varchar(20) NOT NULL,
  `transporter_contact_phone` varchar(10) NOT NULL,
  `transporter_contact_cell` varchar(10) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`transporter_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `transporter` (`transporter_id`, `transporter_name`, `transporter_cn_number`, `transporter_address`, `transporter_contact_person`, `transporter_contact_phone`, `transporter_contact_cell`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('1', 'GATI ', 'TR-CN-0002', '<p>\n	COOCH BEHAR</p>\n<p>\n	&nbsp;</p>\n', '', '7876543567', '', '1', '1', '2021-03-11 21:07:35', '2021-04-01 09:34:45');
INSERT INTO `transporter` (`transporter_id`, `transporter_name`, `transporter_cn_number`, `transporter_address`, `transporter_contact_person`, `transporter_contact_phone`, `transporter_contact_cell`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('2', 'RIVIGO', 'TR-CN-0001', '<p>\n	COOCH BEHAR</p>\n<p>\n	&nbsp;</p>\n', '', '9876543677', '', '1', '1', '2021-03-11 21:16:23', '2021-04-01 09:34:14');
INSERT INTO `transporter` (`transporter_id`, `transporter_name`, `transporter_cn_number`, `transporter_address`, `transporter_contact_person`, `transporter_contact_phone`, `transporter_contact_cell`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('3', 'Sayak', '', '', '', '8787878787', '', '1', '1', '2021-07-10 10:58:15', '2021-07-10 10:58:15');


#
# TABLE STRUCTURE FOR: units
#

DROP TABLE IF EXISTS `units`;

CREATE TABLE `units` (
  `u_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(99) NOT NULL,
  `info` varchar(99) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `units` (`u_id`, `unit`, `info`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('3', 'PCS.', '', '1', '1', '2020-04-05 13:58:30', '2020-04-05 13:58:30');
INSERT INTO `units` (`u_id`, `unit`, `info`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('8', 'PAIR', '', '1', '1', '2021-02-20 11:07:57', '2021-02-20 11:07:57');
INSERT INTO `units` (`u_id`, `unit`, `info`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('9', 'KG', '', '1', '1', '2021-03-23 11:55:58', '2021-03-23 11:55:58');
INSERT INTO `units` (`u_id`, `unit`, `info`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('10', 'Gm.', '', '1', '1', '2021-03-23 11:56:06', '2021-03-23 11:56:06');
INSERT INTO `units` (`u_id`, `unit`, `info`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('11', 'Ton', '', '1', '1', '2021-03-23 11:56:13', '2021-03-23 11:56:13');
INSERT INTO `units` (`u_id`, `unit`, `info`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('12', 'MT', 'Metric Ton', '1', '1', '2021-04-04 10:03:27', '2021-04-04 10:03:27');
INSERT INTO `units` (`u_id`, `unit`, `info`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('13', 'INCH', 'Inch', '1', '1', '2021-07-16 13:15:57', '2021-07-16 13:15:57');
INSERT INTO `units` (`u_id`, `unit`, `info`, `status`, `user_id`, `create_date`, `modify_date`) VALUES ('14', 'CENTIMETER', 'CM', '1', '1', '2021-07-16 13:16:15', '2021-07-16 13:16:15');


#
# TABLE STRUCTURE FOR: user_change_mails
#

DROP TABLE IF EXISTS `user_change_mails`;

CREATE TABLE `user_change_mails` (
  `cm_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `otp` varchar(99) DEFAULT NULL,
  `new_email` varchar(99) DEFAULT NULL,
  `used` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cm_id`),
  KEY `user_change_mails_ibfk_1` (`user_id`),
  CONSTRAINT `user_change_mails_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: user_details
#

DROP TABLE IF EXISTS `user_details`;

CREATE TABLE `user_details` (
  `ud_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `firstname` varchar(99) DEFAULT NULL,
  `lastname` varchar(99) DEFAULT NULL,
  `contact` varchar(30) DEFAULT NULL,
  `img` varchar(999) DEFAULT NULL,
  PRIMARY KEY (`ud_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_details_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `user_details` (`ud_id`, `user_id`, `firstname`, `lastname`, `contact`, `img`) VALUES ('1', '1', 'Mr.', 'Admin', '8697623259', '64c4e611034851ba54a3160c338c8fa3.png');
INSERT INTO `user_details` (`ud_id`, `user_id`, `firstname`, `lastname`, `contact`, `img`) VALUES ('2', '2', 'Mr.', 'User', NULL, NULL);


#
# TABLE STRUCTURE FOR: user_logs
#

DROP TABLE IF EXISTS `user_logs`;

CREATE TABLE `user_logs` (
  `ul_id` int(11) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(100) NOT NULL,
  `pk_id` int(11) NOT NULL,
  `action_taken` enum('add','edit','delete','other') NOT NULL,
  `old_data` longtext NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ul_id`)
) ENGINE=MyISAM AUTO_INCREMENT=131 DEFAULT CHARSET=latin1;

INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('1', 'article_groups', '2', 'edit', '{\"d_id\":\"1\",\"group_name\":\"LADIES HAND BAG\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2020-05-06 09:34:11');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('2', 'item_rates', '16', 'delete', '{\"ir_id\":\"16\",\"id_id\":\"25\",\"am_id\":\"5\",\"purchase_rate\":\"87.00\",\"cost_rate\":\"100.00\",\"gst_percentage\":\"5.00\",\"effective_date\":\"2020-04-01\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-04-24 06:47:01\",\"modify_date\":\"2020-04-24 06:47:01\"}', '1', 'master', '1', '2020-06-01 12:43:43');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('3', 'item_dtl', '25', 'delete', '{\"id_id\":\"25\",\"im_id\":\"9\",\"c_id\":\"1\",\"reorder_qnty\":\"0\",\"img\":\"\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-04-24 06:46:11\",\"modify_date\":\"2020-04-24 06:46:11\"}', '1', 'master', '1', '2020-06-01 12:43:53');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('4', 'sizes', '2', 'edit', '{\"size\":\"1mm\",\"info\":\"\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2020-06-24 14:55:28');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('5', 'sizes', '3', 'edit', '{\"size\":\"2mm\",\"info\":\"\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2020-06-24 14:55:34');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('6', 'countries', '7', 'edit', '{\"country\":\"HONG KONG\",\"c_code\":\"007\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2020-07-01 11:40:53');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('7', 'currencies', '6', 'edit', '{\"c_id\":\"7\",\"currency\":\"HK$\",\"currency_sign\":\"$\",\"info\":\"HONG KONG DOLLER\",\"status\":\"1\",\"CURR_SRATE\":\"0\",\"CURR_BRATE\":\"0\",\"user_id\":\"1\"}', '1', 'master', '1', '2020-07-01 11:42:59');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('8', 'colors', '64', 'edit', '{\"color\":\"ANTIC SILVER\",\"c_code\":\"\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2020-07-01 13:02:38');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('9', 'item_dtl', '253', 'delete', '{\"id_id\":\"253\",\"im_id\":\"91\",\"c_id\":\"46\",\"opening_stock\":\"16352\",\"reorder_qnty\":\"0\",\"img\":\"\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-07-01 00:34:26\",\"modify_date\":\"2020-07-01 00:34:26\"}', '1', 'master', '1', '2020-07-01 13:04:37');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('10', 'item_rates', '252', 'delete', '{\"ir_id\":\"252\",\"id_id\":\"276\",\"am_id\":\"17\",\"purchase_rate\":\"2.80\",\"cost_rate\":\"3.50\",\"gst_percentage\":\"18.00\",\"effective_date\":\"2020-04-01\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-07-06 04:54:13\",\"modify_date\":\"2020-07-06 04:54:13\"}', '1', 'master', '1', '2020-07-06 17:24:36');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('11', 'item_dtl', '276', 'delete', '{\"id_id\":\"276\",\"im_id\":\"99\",\"c_id\":\"1\",\"opening_stock\":\"21000\",\"reorder_qnty\":\"0\",\"img\":\"\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-07-06 04:53:52\",\"modify_date\":\"2020-07-06 04:53:52\"}', '1', 'master', '1', '2020-07-06 17:24:42');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('12', 'item_dtl', '300', 'delete', '{\"id_id\":\"300\",\"im_id\":\"104\",\"c_id\":\"24\",\"opening_stock\":\"30\",\"reorder_qnty\":\"0\",\"img\":\"\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-07-06 23:15:21\",\"modify_date\":\"2020-07-06 23:15:21\"}', '1', 'master', '1', '2020-07-07 12:15:09');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('13', 'item_dtl', '297', 'delete', '{\"id_id\":\"297\",\"im_id\":\"104\",\"c_id\":\"66\",\"opening_stock\":\"2000\",\"reorder_qnty\":\"0\",\"img\":\"\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-07-06 23:14:32\",\"modify_date\":\"2020-07-06 23:14:32\"}', '1', 'master', '1', '2020-07-07 12:19:09');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('14', 'sizes', '7', 'edit', '{\"size\":\"14mm\",\"info\":\"\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2020-07-08 09:47:52');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('15', 'item_dtl', '7', 'delete', '{\"id_id\":\"7\",\"im_id\":\"2\",\"c_id\":\"33\",\"opening_stock\":\"0\",\"reorder_qnty\":\"0\",\"img\":\"\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-04-12 07:39:57\",\"modify_date\":\"2020-04-12 07:39:57\"}', '1', 'master', '1', '2020-07-13 12:00:14');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('16', 'item_dtl', '6', 'delete', '{\"id_id\":\"6\",\"im_id\":\"2\",\"c_id\":\"5\",\"opening_stock\":\"0\",\"reorder_qnty\":\"0\",\"img\":\"\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-04-12 07:39:51\",\"modify_date\":\"2020-04-12 07:39:51\"}', '1', 'master', '1', '2020-07-13 12:00:17');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('17', 'item_dtl', '5', 'delete', '{\"id_id\":\"5\",\"im_id\":\"2\",\"c_id\":\"1\",\"opening_stock\":\"0\",\"reorder_qnty\":\"0\",\"img\":\"\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-04-12 07:39:37\",\"modify_date\":\"2020-04-12 07:39:37\"}', '1', 'master', '1', '2020-07-13 12:00:21');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('18', 'item_master', '2', 'delete', '{\"im_id\":\"2\",\"ig_id\":\"1\",\"im_code\":\"LTH001-0016\",\"item\":\"D.D. CALF (16) LEATHER\",\"sz_id\":\"1\",\"sh_id\":\"1\",\"u_id\":\"0\",\"info_1\":\"\",\"info_2\":\"\",\"type\":\"Local\",\"thick\":\"\",\"buy_code\":\"\",\"sell_code\":\"\",\"enlist_jobber\":\"1\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-04-12 07:39:19\",\"modify_date\":\"2020-04-15 07:11:16\"}', '1', 'master', '1', '2020-07-13 12:00:39');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('19', 'item_rates', '6', 'delete', '{\"ir_id\":\"6\",\"id_id\":\"9\",\"am_id\":\"5\",\"purchase_rate\":\"70.00\",\"cost_rate\":\"77.00\",\"gst_percentage\":\"5.00\",\"effective_date\":\"2020-04-01\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-04-15 07:25:14\",\"modify_date\":\"2020-04-15 07:25:14\"}', '1', 'master', '1', '2020-07-13 12:01:39');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('20', 'item_dtl', '9', 'delete', '{\"id_id\":\"9\",\"im_id\":\"3\",\"c_id\":\"2\",\"opening_stock\":\"0\",\"reorder_qnty\":\"0\",\"img\":\"\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-04-15 07:24:13\",\"modify_date\":\"2020-04-15 07:24:13\"}', '1', 'master', '1', '2020-07-13 12:02:19');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('21', 'item_rates', '5', 'delete', '{\"ir_id\":\"5\",\"id_id\":\"8\",\"am_id\":\"5\",\"purchase_rate\":\"70.00\",\"cost_rate\":\"77.00\",\"gst_percentage\":\"5.00\",\"effective_date\":\"2020-04-01\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-04-15 07:24:52\",\"modify_date\":\"2020-04-15 07:24:52\"}', '1', 'master', '1', '2020-07-13 12:02:27');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('22', 'item_dtl', '8', 'delete', '{\"id_id\":\"8\",\"im_id\":\"3\",\"c_id\":\"1\",\"opening_stock\":\"0\",\"reorder_qnty\":\"0\",\"img\":\"\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-04-15 07:24:11\",\"modify_date\":\"2020-04-15 07:24:11\"}', '1', 'master', '1', '2020-07-13 12:02:34');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('23', 'item_master', '3', 'delete', '{\"im_id\":\"3\",\"ig_id\":\"1\",\"im_code\":\"LTH001-0017\",\"item\":\"SNUFF BUFF PULL UP (17) LEATHER\",\"sz_id\":\"1\",\"sh_id\":\"1\",\"u_id\":\"0\",\"info_1\":\"\",\"info_2\":\"\",\"type\":\"Local\",\"thick\":\"\",\"buy_code\":\"\",\"sell_code\":\"\",\"enlist_jobber\":\"1\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-04-15 07:23:54\",\"modify_date\":\"2020-04-15 07:23:54\"}', '1', 'master', '1', '2020-07-13 12:02:45');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('24', 'item_rates', '7', 'delete', '{\"ir_id\":\"7\",\"id_id\":\"10\",\"am_id\":\"5\",\"purchase_rate\":\"71.00\",\"cost_rate\":\"77.00\",\"gst_percentage\":\"5.00\",\"effective_date\":\"2020-04-01\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-04-15 08:18:21\",\"modify_date\":\"2020-04-15 08:18:21\"}', '1', 'master', '1', '2020-07-13 12:04:01');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('25', 'item_dtl', '10', 'delete', '{\"id_id\":\"10\",\"im_id\":\"4\",\"c_id\":\"1\",\"opening_stock\":\"0\",\"reorder_qnty\":\"0\",\"img\":\"\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-04-15 08:18:02\",\"modify_date\":\"2020-04-15 08:18:02\"}', '1', 'master', '1', '2020-07-13 12:04:07');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('26', 'item_master', '4', 'delete', '{\"im_id\":\"4\",\"ig_id\":\"1\",\"im_code\":\"LTH001-0018\",\"item\":\"BUFF MATT P.D.M SHILPA (18) LEATHER\",\"sz_id\":\"1\",\"sh_id\":\"1\",\"u_id\":\"0\",\"info_1\":\"\",\"info_2\":\"\",\"type\":\"None\",\"thick\":\"\",\"buy_code\":\"\",\"sell_code\":\"\",\"enlist_jobber\":\"1\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-04-15 08:17:52\",\"modify_date\":\"2020-04-15 08:17:52\"}', '1', 'master', '1', '2020-07-13 12:04:32');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('27', 'item_buying_codes', '11', 'delete', '{\"ibc_id\":\"11\",\"im_id\":\"42\",\"am_id\":\"2\",\"buying_code\":\"110M\",\"user_id\":\"1\",\"status\":\"1\",\"create_date\":\"2020-06-09 22:42:53\",\"modify_date\":\"2020-06-09 22:42:53\"}', '1', 'master', '1', '2020-07-13 15:50:12');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('28', 'item_rates', '76', 'delete', '{\"ir_id\":\"76\",\"id_id\":\"95\",\"am_id\":\"5\",\"purchase_rate\":\"85.00\",\"cost_rate\":\"95.00\",\"gst_percentage\":\"5.00\",\"effective_date\":\"2020-04-01\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-05-08 22:36:38\",\"modify_date\":\"2020-05-08 22:36:38\"}', '1', 'master', '1', '2020-07-16 09:53:57');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('29', 'item_rates', '75', 'delete', '{\"ir_id\":\"75\",\"id_id\":\"94\",\"am_id\":\"5\",\"purchase_rate\":\"85.00\",\"cost_rate\":\"95.00\",\"gst_percentage\":\"5.00\",\"effective_date\":\"2020-04-01\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-05-08 22:36:24\",\"modify_date\":\"2020-05-08 22:36:24\"}', '1', 'master', '1', '2020-07-16 09:54:04');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('30', 'item_rates', '74', 'delete', '{\"ir_id\":\"74\",\"id_id\":\"93\",\"am_id\":\"5\",\"purchase_rate\":\"85.00\",\"cost_rate\":\"95.00\",\"gst_percentage\":\"5.00\",\"effective_date\":\"2020-04-01\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-05-08 22:36:11\",\"modify_date\":\"2020-05-08 22:36:11\"}', '1', 'master', '1', '2020-07-16 09:54:10');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('31', 'item_dtl', '95', 'delete', '{\"id_id\":\"95\",\"im_id\":\"29\",\"c_id\":\"4\",\"opening_stock\":\"0\",\"reorder_qnty\":\"0\",\"img\":\"\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-05-08 22:34:28\",\"modify_date\":\"2020-05-08 22:34:28\"}', '1', 'master', '1', '2020-07-16 09:54:13');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('32', 'item_dtl', '94', 'delete', '{\"id_id\":\"94\",\"im_id\":\"29\",\"c_id\":\"3\",\"opening_stock\":\"0\",\"reorder_qnty\":\"0\",\"img\":\"\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-05-08 22:34:23\",\"modify_date\":\"2020-05-08 22:34:23\"}', '1', 'master', '1', '2020-07-16 09:54:15');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('33', 'item_dtl', '93', 'delete', '{\"id_id\":\"93\",\"im_id\":\"29\",\"c_id\":\"1\",\"opening_stock\":\"0\",\"reorder_qnty\":\"0\",\"img\":\"\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-05-08 22:34:20\",\"modify_date\":\"2020-05-08 22:34:20\"}', '1', 'master', '1', '2020-07-16 09:54:22');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('34', 'item_buying_codes', '3', 'delete', '{\"ibc_id\":\"3\",\"im_id\":\"29\",\"am_id\":\"4\",\"buying_code\":\"78\",\"user_id\":\"1\",\"status\":\"1\",\"create_date\":\"2020-05-08 22:34:08\",\"modify_date\":\"2020-05-08 22:34:08\"}', '1', 'master', '1', '2020-07-16 09:54:35');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('35', 'item_buying_codes', '2', 'delete', '{\"ibc_id\":\"2\",\"im_id\":\"29\",\"am_id\":\"2\",\"buying_code\":\"78\",\"user_id\":\"1\",\"status\":\"1\",\"create_date\":\"2020-05-08 22:34:00\",\"modify_date\":\"2020-05-08 22:34:00\"}', '1', 'master', '1', '2020-07-16 09:54:37');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('36', 'item_buying_codes', '1', 'delete', '{\"ibc_id\":\"1\",\"im_id\":\"29\",\"am_id\":\"1\",\"buying_code\":\"78\",\"user_id\":\"1\",\"status\":\"1\",\"create_date\":\"2020-05-08 22:33:43\",\"modify_date\":\"2020-05-08 22:33:43\"}', '1', 'master', '1', '2020-07-16 09:54:39');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('37', 'item_master', '29', 'delete', '{\"im_id\":\"29\",\"ig_id\":\"1\",\"im_code\":\"LTH001-0079\",\"item\":\"WAXY-KATTA OILY CRUMPLE V.T. (79) LEATHER\",\"sz_id\":\"1\",\"sh_id\":\"1\",\"u_id\":\"1\",\"info_1\":\"\",\"info_2\":\"\",\"type\":\"None\",\"thick\":\"1.5 +\",\"buy_code\":\"79\",\"sell_code\":\"\",\"enlist_jobber\":\"1\",\"enlist_costing\":\"1\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-05-08 22:33:29\",\"modify_date\":\"2020-05-08 22:33:29\"}', '1', 'master', '1', '2020-07-16 09:54:52');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('38', 'item_master', '29', 'delete', 'null', '1', 'master', '1', '2020-07-16 09:54:58');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('39', 'item_dtl', '375', 'delete', '{\"id_id\":\"375\",\"im_id\":\"114\",\"c_id\":\"1\",\"opening_stock\":\"1000\",\"reorder_qnty\":\"0\",\"img\":\"\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-07-28 11:19:53\",\"modify_date\":\"2020-07-28 11:19:53\"}', '1', 'master', '1', '2020-07-28 23:50:13');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('40', 'sizes', '12', 'edit', '{\"size\":\"1cm\",\"info\":\"\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2020-08-01 10:29:39');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('41', 'sizes', '13', 'edit', '{\"size\":\"1 INCH (25mm)\",\"info\":\"\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2020-08-01 10:31:02');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('42', 'sizes', '14', 'edit', '{\"size\":\"1.25 INCH (30mm)\",\"info\":\"\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2020-08-01 10:31:13');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('43', 'item_dtl', '436', 'delete', '{\"id_id\":\"436\",\"im_id\":\"161\",\"c_id\":\"46\",\"opening_stock\":\"4751\",\"reorder_qnty\":\"0\",\"img\":\"\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-08-03 01:48:57\",\"modify_date\":\"2020-08-03 01:48:57\"}', '1', 'master', '1', '2020-08-03 14:20:27');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('44', 'item_buying_codes', '15', 'delete', '{\"ibc_id\":\"15\",\"im_id\":\"163\",\"am_id\":\"13\",\"buying_code\":\"RNG008-002\",\"user_id\":\"1\",\"status\":\"1\",\"create_date\":\"2020-08-03 02:20:13\",\"modify_date\":\"2020-08-03 02:20:13\"}', '1', 'master', '1', '2020-08-03 14:57:10');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('45', 'item_dtl', '441', 'delete', '{\"id_id\":\"441\",\"im_id\":\"163\",\"c_id\":\"60\",\"opening_stock\":\"300\",\"reorder_qnty\":\"0\",\"img\":\"\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-08-03 02:23:45\",\"modify_date\":\"2020-08-03 02:23:45\"}', '1', 'master', '1', '2020-08-03 14:57:14');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('46', 'item_buying_codes', '16', 'delete', '{\"ibc_id\":\"16\",\"im_id\":\"163\",\"am_id\":\"13\",\"buying_code\":\"RNG008-002\",\"user_id\":\"1\",\"status\":\"1\",\"create_date\":\"2020-08-03 02:28:48\",\"modify_date\":\"2020-08-03 02:28:48\"}', '1', 'master', '1', '2020-08-03 15:17:59');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('47', 'item_buying_codes', '17', 'delete', '{\"ibc_id\":\"17\",\"im_id\":\"163\",\"am_id\":\"21\",\"buying_code\":\"RNG008-002\",\"user_id\":\"1\",\"status\":\"1\",\"create_date\":\"2020-08-03 02:43:02\",\"modify_date\":\"2020-08-03 02:43:02\"}', '1', 'master', '1', '2020-08-03 15:17:59');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('48', 'article_dtl', '10', 'delete', '{\"ad_id\":\"10\",\"am_id\":\"5\",\"lth_color_id\":\"1\",\"fit_color_id\":\"3\",\"img\":\"c2d9bd0d0a796d7a925f48c560cd8292.png\",\"status\":\"1\",\"user_id\":\"1\",\"create_id\":\"2020-08-03 03:29:17\",\"modify_id\":\"2020-08-03 03:29:17\"}', '1', 'master', '1', '2020-08-03 16:10:43');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('49', 'article_dtl', '11', 'delete', '{\"ad_id\":\"11\",\"am_id\":\"5\",\"lth_color_id\":\"75\",\"fit_color_id\":\"74\",\"img\":\"1296d8b1462f15481987e93a65bc5d51.png\",\"status\":\"1\",\"user_id\":\"1\",\"create_id\":\"2020-08-03 03:41:18\",\"modify_id\":\"2020-08-03 03:41:18\"}', '1', 'master', '1', '2020-08-03 16:11:37');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('50', 'article_dtl', '13', 'delete', '{\"ad_id\":\"13\",\"am_id\":\"5\",\"lth_color_id\":\"26\",\"fit_color_id\":\"73\",\"img\":\"903b5ed796261edb78c5d1c54e19336d.png\",\"status\":\"1\",\"user_id\":\"1\",\"create_id\":\"2020-08-03 04:04:52\",\"modify_id\":\"2020-08-03 04:05:18\"}', '1', 'master', '1', '2020-08-03 16:35:37');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('51', 'article_dtl', '12', 'delete', '{\"ad_id\":\"12\",\"am_id\":\"5\",\"lth_color_id\":\"75\",\"fit_color_id\":\"76\",\"img\":\"537597398201b89fb68a4210d701b3b6.jpg\",\"status\":\"1\",\"user_id\":\"1\",\"create_id\":\"2020-08-03 03:42:26\",\"modify_id\":\"2020-08-03 03:48:59\"}', '1', 'master', '1', '2020-08-03 16:35:42');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('52', 'acc_master', '10', 'edit', '{\"ag_id\":\"1\",\"name\":\"DHARIWAL TEXTILE PVT. LTD.\",\"short_name\":\"DT\",\"am_code\":\"SC009\",\"phone\":\"\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"113 H MATHESHWSRTALLA Road Kolkata 700046\",\"c_id\":\"4\",\"s_id\":\"5\",\"cur_id\":\"4\",\"acc_type\":\"None\",\"proprietor\":\"\",\"buyer\":\"\",\"courier_address\":\"\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2020-08-04 10:30:21');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('53', 'acc_master', '13', 'edit', '{\"ag_id\":\"1\",\"name\":\"M.M INTERNATIONAL\",\"short_name\":\"MMI\",\"am_code\":\"SC010\",\"phone\":\"\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"2, TARAK DUTTA ROAD ,KOLKATA - 700019.\",\"c_id\":\"4\",\"s_id\":\"5\",\"cur_id\":\"4\",\"acc_type\":\"None\",\"proprietor\":\"\",\"buyer\":\"\",\"courier_address\":\"\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2020-08-04 10:30:42');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('54', 'acc_master', '17', 'edit', '{\"ag_id\":\"1\",\"name\":\"M.A. IMPEX\",\"short_name\":\"MAI\",\"am_code\":\"SC011\",\"phone\":\"\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"2, TEMPLE STREETKOLKATA - 700072\",\"c_id\":\"4\",\"s_id\":\"5\",\"cur_id\":\"4\",\"acc_type\":\"None\",\"proprietor\":\"\",\"buyer\":\"\",\"courier_address\":\"\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2020-08-04 10:30:55');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('55', 'acc_master', '14', 'edit', '{\"ag_id\":\"1\",\"name\":\"JANAKSONS\",\"short_name\":\"JNK\",\"am_code\":\"SC012\",\"phone\":\"\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"237, JODHPUR PARKKOLKATA - 700 068\",\"c_id\":\"4\",\"s_id\":\"5\",\"cur_id\":\"4\",\"acc_type\":\"None\",\"proprietor\":\"\",\"buyer\":\"\",\"courier_address\":\"\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2020-08-04 10:31:10');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('56', 'acc_master', '18', 'edit', '{\"ag_id\":\"1\",\"name\":\"DIPAK TRADING CO.\",\"short_name\":\"DTC\",\"am_code\":\"SC013\",\"phone\":\"\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"61,BENTINCK STREET1ST FLOOR , ROOM NO. 0, 1KOLKATA-700069\",\"c_id\":\"4\",\"s_id\":\"5\",\"cur_id\":\"4\",\"acc_type\":\"None\",\"proprietor\":\"\",\"buyer\":\"\",\"courier_address\":\"\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2020-08-04 10:31:39');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('57', 'acc_master', '11', 'edit', '{\"ag_id\":\"1\",\"name\":\"CHANDAK COMMERCIAL (P) LTD.\",\"short_name\":\"CC\",\"am_code\":\"SC014\",\"phone\":\"\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"10, TARACHAND DUTTA STREETKOLKATA - 700 073\",\"c_id\":\"4\",\"s_id\":\"5\",\"cur_id\":\"4\",\"acc_type\":\"None\",\"proprietor\":\"\",\"buyer\":\"\",\"courier_address\":\"\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2020-08-04 10:31:55');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('58', 'acc_master', '12', 'edit', '{\"ag_id\":\"1\",\"name\":\"VENUS MARKETTING SERVICES\",\"short_name\":\"VMS\",\"am_code\":\"SC015\",\"phone\":\"\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"2A\\/1B, BRINDABAN PAUL LANE,KOLKATA - 700 003.\",\"c_id\":\"4\",\"s_id\":\"5\",\"cur_id\":\"4\",\"acc_type\":\"None\",\"proprietor\":\"\",\"buyer\":\"\",\"courier_address\":\"\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2020-08-04 10:32:44');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('59', 'item_dtl', '463', 'delete', '{\"id_id\":\"463\",\"im_id\":\"170\",\"c_id\":\"63\",\"opening_stock\":\"20\",\"reorder_qnty\":\"0\",\"img\":\"\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-08-03 23:47:01\",\"modify_date\":\"2020-08-03 23:47:01\"}', '1', 'master', '1', '2020-08-04 12:18:01');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('60', 'item_dtl', '520', 'delete', '{\"id_id\":\"520\",\"im_id\":\"180\",\"c_id\":\"73\",\"opening_stock\":\"0\",\"reorder_qnty\":\"0\",\"img\":\"\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-08-05 22:22:18\",\"modify_date\":\"2020-08-05 22:22:18\"}', '1', 'master', '1', '2020-08-06 10:52:28');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('61', 'item_rates', '470', 'delete', '{\"ir_id\":\"470\",\"id_id\":\"533\",\"am_id\":\"21\",\"purchase_rate\":\"5.00\",\"cost_rate\":\"8.00\",\"gst_percentage\":\"18.00\",\"effective_date\":\"2020-04-01\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-08-06 00:19:55\",\"modify_date\":\"2020-08-06 00:19:55\"}', '1', 'master', '1', '2020-08-06 12:50:10');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('62', 'acc_master', '29', 'edit', '{\"ag_id\":\"1\",\"name\":\"ADAMS EXIM PVT. LTD.\",\"short_name\":\"AE\",\"am_code\":\"SC021\",\"phone\":\"2286 5333 \\/ 5444 \\/ 5666\",\"email_id\":\"shabbir@adamsexim.com\",\"vat_no\":\"\",\"address\":\"Merlin Regency # T1G1 , 25, Dr. Suresh Sarkar Road. Kolkata \\u2013 700014\",\"c_id\":\"4\",\"s_id\":\"5\",\"cur_id\":\"4\",\"acc_type\":\"None\",\"proprietor\":\"\",\"buyer\":\"\",\"courier_address\":\"\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2020-08-07 11:28:36');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('63', 'item_rates', '315', 'delete', '{\"ir_id\":\"315\",\"id_id\":\"352\",\"am_id\":\"6\",\"purchase_rate\":\"123.00\",\"cost_rate\":\"321.00\",\"gst_percentage\":\"5.00\",\"effective_date\":\"2020-04-01\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-07-14 04:35:10\",\"modify_date\":\"2020-07-14 04:35:10\"}', '1', 'master', '1', '2020-08-07 11:52:37');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('64', 'article_dtl', '28', 'delete', '{\"ad_id\":\"28\",\"am_id\":\"12\",\"lth_color_id\":\"1\",\"fit_color_id\":\"3\",\"img\":null,\"status\":\"1\",\"user_id\":\"1\",\"create_id\":\"2020-08-10 10:53:13\",\"modify_id\":\"2020-08-10 10:53:13\"}', '1', 'master', '1', '2020-08-10 23:23:18');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('65', 'article_dtl', '27', 'delete', '{\"ad_id\":\"27\",\"am_id\":\"12\",\"lth_color_id\":\"1\",\"fit_color_id\":\"2\",\"img\":null,\"status\":\"1\",\"user_id\":\"1\",\"create_id\":\"2020-08-10 10:52:55\",\"modify_id\":\"2020-08-10 10:52:55\"}', '1', 'master', '1', '2020-08-10 23:23:27');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('66', 'item_dtl', '628', 'delete', '{\"id_id\":\"628\",\"im_id\":\"241\",\"c_id\":\"58\",\"opening_stock\":\"749\",\"reorder_qnty\":\"50\",\"img\":\"\",\"status\":\"1\",\"user_id\":\"1\",\"create_date\":\"2020-08-11 22:03:40\",\"modify_date\":\"2020-08-11 22:03:40\"}', '1', 'master', '1', '2020-08-12 10:33:49');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('67', 'item_buying_codes', '22', 'delete', '{\"ibc_id\":\"22\",\"im_id\":\"217\",\"am_id\":\"1\",\"main_color_id\":\"0\",\"buying_code\":\"\",\"buyer_im_id\":\"8\",\"customer_item_code\":\"BOX\",\"c_id\":\"4\",\"customer_colour_code\":\"BOX-MORO\",\"user_id\":\"1\",\"status\":\"1\",\"create_date\":\"2020-09-29 12:22:56\",\"modify_date\":\"2020-09-29 23:06:12\"}', '1', 'master', '1', '2020-09-30 09:01:37');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('68', 'item_buying_codes', '26', 'delete', '{\"ibc_id\":\"26\",\"im_id\":\"217\",\"am_id\":\"1\",\"main_color_id\":\"0\",\"buying_code\":\"\",\"buyer_im_id\":\"5\",\"customer_item_code\":\"yrtyrt\",\"c_id\":\"6\",\"customer_colour_code\":\"trytrytr\",\"user_id\":\"1\",\"status\":\"1\",\"create_date\":\"2020-09-30 08:56:27\",\"modify_date\":\"2020-09-30 08:56:27\"}', '1', 'master', '1', '2020-09-30 09:01:42');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('69', 'item_buying_codes', '23', 'delete', '{\"ibc_id\":\"23\",\"im_id\":\"217\",\"am_id\":\"5\",\"main_color_id\":\"0\",\"buying_code\":\"\",\"buyer_im_id\":\"8\",\"customer_item_code\":\"dfsfd\",\"c_id\":\"6\",\"customer_colour_code\":\"sdfdsf\",\"user_id\":\"1\",\"status\":\"1\",\"create_date\":\"2020-09-29 22:37:43\",\"modify_date\":\"2020-09-29 22:37:43\"}', '1', 'master', '1', '2020-09-30 09:01:44');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('70', 'item_buying_codes', '25', 'delete', '{\"ibc_id\":\"25\",\"im_id\":\"217\",\"am_id\":\"26\",\"main_color_id\":\"0\",\"buying_code\":\"\",\"buyer_im_id\":\"6\",\"customer_item_code\":\"werewrewr\",\"c_id\":\"6\",\"customer_colour_code\":\"werwerwer\",\"user_id\":\"1\",\"status\":\"1\",\"create_date\":\"2020-09-30 08:45:14\",\"modify_date\":\"2020-09-30 08:45:14\"}', '1', 'master', '1', '2020-09-30 09:01:47');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('71', 'item_buying_codes', '24', 'delete', '{\"ibc_id\":\"24\",\"im_id\":\"217\",\"am_id\":\"2\",\"main_color_id\":\"0\",\"buying_code\":\"\",\"buyer_im_id\":\"18\",\"customer_item_code\":\"vcbfdgf\",\"c_id\":\"28\",\"customer_colour_code\":\"fdgfdgdfg\",\"user_id\":\"1\",\"status\":\"1\",\"create_date\":\"2020-09-29 22:39:55\",\"modify_date\":\"2020-09-29 22:39:55\"}', '1', 'master', '1', '2020-09-30 09:01:50');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('72', 'units', '6', 'edit', '{\"unit\":\"Pair\",\"info\":\"\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-02-20 11:04:56');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('73', 'acc_master', '27', 'edit', '{\"name\":\"Brown Paper PVT. LTD.\",\"short_name\":\"BP\",\"am_code\":\"BP-001\",\"phone\":\"\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"\",\"proprietor\":\"\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-02-20 12:36:25');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('74', 'acc_master', '12', 'edit', '{\"name\":\"Art Paper Pvt. Ltd.\",\"short_name\":\"AP\",\"am_code\":\"AP-001\",\"phone\":\"\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"\",\"proprietor\":\"\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-02-20 12:36:59');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('75', 'acc_master', '12', 'edit', '{\"name\":\"Art Paper Pvt. Ltd.\",\"short_name\":\"AP\",\"am_code\":\"AP-001\",\"phone\":\"0090101000\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"\",\"proprietor\":\"\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-02-20 12:37:26');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('76', 'acc_master', '27', 'edit', '{\"name\":\"Brown Paper PVT. LTD.\",\"short_name\":\"BP\",\"am_code\":\"BP-001\",\"phone\":\"0090101000\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"\",\"proprietor\":\"\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-02-20 12:37:34');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('77', 'colors', '27', 'edit', '{\"color\":\"RED\",\"c_code\":\"RED\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-02-20 21:41:26');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('78', 'colors', '14', 'edit', '{\"color\":\"GREEN\",\"c_code\":\"GREEN\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-02-20 21:41:46');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('79', 'colors', '13', 'edit', '{\"color\":\"BLUE\",\"c_code\":\"BLUE\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-02-20 21:41:58');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('80', 'mill', '1', 'edit', '{\"mill_name\":\"paper mill\",\"mill_short_code\":\"PM\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-03-09 23:51:38');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('81', 'mill', '1', 'edit', '{\"mill_name\":\"paper mill\",\"mill_short_code\":\"PM\",\"mill_contact_person\":\"Mr. Roy\",\"mill_contact_phone\":\"9733935161\",\"mill_contact_cell\":\"9733935161\",\"mill_address\":\"<p>\\n\\tkolkata<\\/p>\\n\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-03-09 23:53:36');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('82', 'mill', '2', 'edit', '{\"mill_name\":\"paper mill 1\",\"mill_short_code\":\"PM1\",\"mill_contact_person\":\"My. Jana\",\"mill_contact_phone\":\"1234567890\",\"mill_contact_cell\":\"0123456789\",\"mill_address\":\"<p>\\n\\tkolkata<\\/p>\\n\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-03-09 23:56:57');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('83', 'acc_master', '12', 'edit', '{\"name\":\"Art Paper Pvt. Ltd.\",\"short_name\":\"AP\",\"am_code\":\"AP-001\",\"phone\":\"0090101000\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"\",\"proprietor\":\"\",\"mill_id\":\"3\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-03-10 00:04:27');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('84', 'acc_master', '27', 'edit', '{\"name\":\"Brown Paper PVT. LTD.\",\"short_name\":\"BP\",\"am_code\":\"BP-001\",\"phone\":\"0090101000\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"\",\"proprietor\":\"\",\"mill_id\":\"1\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-03-10 00:04:34');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('85', 'sizes', '35', 'edit', '{\"size\":\"14CMX9.5CM\",\"info\":\"\",\"paper_gsm\":\"3\",\"paper_bf\":\"2\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-03-11 22:59:30');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('86', 'sizes', '33', 'edit', '{\"size\":\"6 x 4 Cm.\",\"info\":\"\",\"paper_gsm\":\"1.5\",\"paper_bf\":\"1.5\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-03-11 22:59:43');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('87', 'sizes', '34', 'edit', '{\"size\":\"8 x 12 Cm.\",\"info\":\"\",\"paper_gsm\":\"3.5\",\"paper_bf\":\"3.5\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-03-11 23:00:00');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('88', 'sizes', '35', 'edit', '{\"size\":\"14CMX9.5CM\",\"info\":\"\",\"paper_gsm\":\"3\",\"paper_bf\":\"2\",\"rate_per_unit\":\"2.50\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-03-11 23:07:58');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('89', 'sizes', '33', 'edit', '{\"size\":\"6 x 4 Cm.\",\"info\":\"\",\"paper_gsm\":\"2\",\"paper_bf\":\"2\",\"rate_per_unit\":\"3.50\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-03-11 23:08:07');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('90', 'sizes', '34', 'edit', '{\"size\":\"8 x 12 Cm.\",\"info\":\"\",\"paper_gsm\":\"4\",\"paper_bf\":\"4\",\"rate_per_unit\":\"4.50\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-03-11 23:08:20');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('91', 'mill', '1', 'edit', '{\"mill_name\":\"BALLAVPUR\",\"mill_short_code\":\"BLVPR\",\"mill_contact_person\":\"\",\"mill_contact_phone\":\"7654890890\",\"mill_contact_cell\":\"\",\"mill_address\":\"<p>\\n\\tDURGAPUR<\\/p>\\n<p>\\n\\t&nbsp;<\\/p>\\n\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-04-01 09:35:32');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('92', 'mill', '3', 'edit', '{\"mill_name\":\"KRISHNA TISSU\",\"mill_short_code\":\"KRNT\",\"mill_contact_person\":\"\",\"mill_contact_phone\":\"8908765545\",\"mill_contact_cell\":\"\",\"mill_address\":\"<p>\\n\\tBURWANI<\\/p>\\n<p>\\n\\t&nbsp;<\\/p>\\n\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-04-01 09:36:12');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('93', 'acc_master', '12', 'edit', '{\"name\":\"ROY TRADER\",\"short_name\":\"RT\",\"am_code\":\"AP-001\",\"phone\":\"87897899887\",\"email_id\":\"\",\"vat_no\":\"AA6TUFNFDMKK\",\"address\":\"\",\"proprietor\":\"\",\"mill_id\":\"3\",\"supplier_buyer\":\"0\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-04-01 09:38:04');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('94', 'acc_master', '27', 'edit', '{\"name\":\"KARTIK\",\"short_name\":\"KT\",\"am_code\":\"KT\",\"phone\":\"\",\"email_id\":\"\",\"vat_no\":\"KT87988JKJKJN\",\"address\":\"\",\"proprietor\":\"\",\"mill_id\":\"1\",\"supplier_buyer\":\"1\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-04-01 09:39:54');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('95', 'sizes', '35', 'edit', '{\"size\":\"W8XH10X4\",\"info\":\"BROWN\",\"paper_gsm\":\"120\",\"paper_bf\":\"20\",\"rate_per_unit\":\"3.80\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-04-01 09:41:11');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('96', 'sizes', '33', 'edit', '{\"size\":\"W13XH16X5\",\"info\":\"WHITE\",\"paper_gsm\":\"120\",\"paper_bf\":\"20\",\"rate_per_unit\":\"5.70\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-04-01 09:42:13');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('97', 'colors', '13', 'edit', '{\"color\":\"LOYAL GOLD BROWN\",\"c_code\":\"LGB\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-16 13:12:42');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('98', 'acc_master', '29', 'edit', '{\"name\":\"RAVI UDYOG\",\"short_name\":\"SIL\\/RU\",\"am_code\":\"\",\"phone\":\"9332255551\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"WARD NO-13 ,NEAR SHIB MANDIR, PUNJABI PARA , SILIGURI, WEST BENGAL, PIN - 734001\",\"proprietor\":\"Ravi\",\"mill_id\":\"\",\"supplier_buyer\":\"1\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-19 13:37:49');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('99', 'acc_master', '29', 'edit', '{\"name\":\"RAVI UDYOG\",\"short_name\":\"SIL\\/RU\",\"am_code\":\"\",\"phone\":\"9332255551\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"<p>\\n\\tWARD NO-13 ,<br \\/>\\n\\tNEAR SHIB MANDIR,<br \\/>\\n\\tPUNJABI PARA ,<br \\/>\\n\\tSILIGURI, WEST BENGAL,<br \\/>\\n\\tPIN - 734001<\\/p>\\n\",\"place_of_supply\":\"<p>\\n\\tWB (19)<br \\/>\\n\\tPAN no ACSPD8047Q,<br \\/>\\n\\tTIN: 19891338563,<br \\/>\\n\\tGSTIN: 19ACSPD8047Q1ZN<\\/p>\\n\",\"proprietor\":\"Ravi\",\"mill_id\":\"1\",\"supplier_buyer\":\"1\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-19 14:53:56');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('100', 'acc_master', '29', 'edit', '{\"name\":\"RAVI UDYOG\",\"short_name\":\"SIL\\/RU\",\"am_code\":\"\",\"phone\":\"9332255551\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"<p>\\n\\tWARD NO-13 ,&nbsp;NEAR SHIB MANDIR,<br \\/>\\n\\tPUNJABI PARA ,&nbsp;SILIGURI, WEST BENGAL,<br \\/>\\n\\tPIN - 734001<\\/p>\\n\",\"place_of_supply\":\"<p>\\n\\tWB (19)<br \\/>\\n\\tPAN no ACSPD8047Q,<br \\/>\\n\\tTIN: 19891338563,<br \\/>\\n\\tGSTIN: 19ACSPD8047Q1ZN<\\/p>\\n\",\"proprietor\":\"Ravi\",\"mill_id\":\"1\",\"supplier_buyer\":\"1\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-19 15:03:13');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('101', 'sizes', '35', 'edit', '{\"product_name\":\"BROWN PAPER BAGS 810\",\"size\":\"W8XH10X4\",\"info\":\"BROWN\",\"paper_gsm\":\"120\",\"paper_bf\":\"20\",\"rate_per_unit\":\"3.80\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-19 16:05:57');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('102', 'sizes', '36', 'edit', '{\"product_name\":\"BROWN PAPER BAGS 1113\",\"size\":\"W11XH13X4\",\"info\":\"\",\"paper_gsm\":\"120\",\"paper_bf\":\"20\",\"rate_per_unit\":\"5.60\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-19 16:06:23');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('103', 'sizes', '33', 'edit', '{\"product_name\":\"BROWN PAPER BAGS 1316\",\"size\":\"W13XH16XG5\",\"info\":\"WHITE\",\"paper_gsm\":\"120\",\"paper_bf\":\"20\",\"rate_per_unit\":\"5.70\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-19 16:10:57');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('104', 'sizes', '37', 'edit', '{\"product_name\":\"BROWN PAPER BAGS 119\",\"size\":\"W11XH9XG9\",\"info\":\"\",\"paper_gsm\":\"120\",\"paper_bf\":\"20\",\"rate_per_unit\":\"6.50\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-19 16:11:31');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('105', 'sizes', '37', 'edit', '{\"product_name\":\"BROWN  BAGS HG 119\",\"size\":\"W11XH9XG9\",\"info\":\"\",\"paper_gsm\":\"120\",\"paper_bf\":\"20\",\"rate_per_unit\":\"5.50\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-19 16:48:12');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('106', 'sizes', '37', 'edit', '{\"product_name\":\"BROWN  BAGS SB 810\",\"size\":\"W 8 XH 10XG 3.5\",\"info\":\"\",\"paper_gsm\":\"120\",\"paper_bf\":\"20\",\"rate_per_unit\":\"3.80\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-19 16:50:02');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('107', 'sizes', '35', 'edit', '{\"product_name\":\"BROWN PAPER BAGS 810\",\"size\":\"W8XH10X 3.5\",\"info\":\"BROWN\",\"paper_gsm\":\"120\",\"paper_bf\":\"20\",\"rate_per_unit\":\"3.80\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-19 16:50:28');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('108', 'sizes', '37', 'edit', '{\"product_name\":\"BROWN  BAGS SB 1113\",\"size\":\"W 11 XH 13 XG 4\",\"info\":\"\",\"paper_gsm\":\"120\",\"paper_bf\":\"20\",\"rate_per_unit\":\"5.00\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-19 16:51:33');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('109', 'sizes', '37', 'edit', '{\"product_name\":\"BROWN  BAGS SB 1317\",\"size\":\"W 13 XH 17 XG 4\",\"info\":\"\",\"paper_gsm\":\"120\",\"paper_bf\":\"20\",\"rate_per_unit\":\"5.80\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-19 16:52:21');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('110', 'sizes', '43', 'edit', '{\"product_name\":\"BROWN  BAG SB 1113\",\"size\":\"W 11 XH 13 XG 4\",\"info\":\"\",\"paper_gsm\":\"120\",\"paper_bf\":\"20\",\"rate_per_unit\":\"5.00\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-19 16:58:04');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('111', 'sizes', '44', 'edit', '{\"product_name\":\"BROWN  BAG SB 1317\",\"size\":\"W 13 XH 17 XG 4\",\"info\":\"\",\"paper_gsm\":\"120\",\"paper_bf\":\"20\",\"rate_per_unit\":\"5.80\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-19 16:58:17');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('112', 'sizes', '45', 'edit', '{\"product_name\":\"BROWN BAG SB 1216\",\"size\":\"W 12 XH 16 XG 5\",\"info\":\"\",\"paper_gsm\":\"120\",\"paper_bf\":\"20\",\"rate_per_unit\":\"5.80\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-19 16:58:42');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('113', 'sizes', '49', 'edit', '{\"product_name\":\"BROWN BAG HG 1310\",\"size\":\"W 13 XH 10 XG 10\",\"info\":\"\",\"paper_gsm\":\"120\",\"paper_bf\":\"20\",\"rate_per_unit\":\"5.80\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-19 17:03:36');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('114', 'acc_master', '27', 'edit', '{\"name\":\"SUNRAYS \",\"short_name\":\"NEEL\",\"am_code\":\"\",\"phone\":\"\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"<p>\\n\\tahmedabad<\\/p>\\n\",\"place_of_supply\":\"<p>\\n\\tahmedabad<\\/p>\\n\",\"proprietor\":\"\",\"mill_id\":\"1\",\"supplier_buyer\":\"0\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-26 17:22:17');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('115', 'acc_master', '27', 'edit', '{\"name\":\"SUNRAYS \",\"short_name\":\"\",\"am_code\":\"S P\",\"phone\":\"\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"<p>\\n\\tahmedabad<\\/p>\\n\",\"place_of_supply\":\"<p>\\n\\tahmedabad<\\/p>\\n\",\"proprietor\":\"\",\"mill_id\":\"1\",\"supplier_buyer\":\"0\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-26 17:23:04');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('116', 'acc_master', '27', 'edit', '{\"name\":\"SUNRAYS \",\"short_name\":\"\",\"am_code\":\"S P\",\"phone\":\"\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"<p>\\n\\tahmedabad<\\/p>\\n\",\"place_of_supply\":\"<p>\\n\\tahmedabad<\\/p>\\n\",\"proprietor\":\"\",\"mill_id\":\"1\",\"supplier_buyer\":\"1\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-26 17:31:51');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('117', 'acc_master', '27', 'edit', '{\"name\":\"SUNRAYS \",\"short_name\":\"S P\",\"am_code\":\"S P\",\"phone\":\"\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"<p>\\n\\tahmedabad<\\/p>\\n\",\"place_of_supply\":\"<p>\\n\\tahmedabad<\\/p>\\n\",\"proprietor\":\"\",\"mill_id\":\"1\",\"supplier_buyer\":\"1\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-26 17:32:36');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('118', 'acc_master', '27', 'edit', '{\"name\":\"SUNRAYS \",\"short_name\":\"S P\",\"am_code\":\"S P\",\"phone\":\"9879883902\",\"email_id\":\"\",\"vat_no\":\"24ABECS4753B1ZX\",\"address\":\"<p>\\n\\tSATYA&nbsp; COMPLEX , OPP IOC PETROL PUMP,&nbsp; &nbsp;AHMEDABAD , GUJRAT -24<\\/p>\\n\",\"place_of_supply\":\"<p>\\n\\tSATYA&nbsp; COMPLEX , OPP IOC PETROL PUMP,&nbsp; &nbsp;AHMEDABAD , GUJRAT -24<\\/p>\\n\",\"proprietor\":\"\",\"mill_id\":\"1\",\"supplier_buyer\":\"1\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-26 17:58:24');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('119', 'sizes', '48', 'edit', '{\"product_name\":\"BROWN  BAG HG 119\",\"size\":\"W 11 XH 9 XG 9\",\"info\":\"\",\"paper_gsm\":\"120\",\"paper_bf\":\"20\",\"rate_per_unit\":\"5.50\",\"hsn_code\":\"48195090\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-26 19:46:23');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('120', 'sizes', '41', 'edit', '{\"product_name\":\"BROWN  BAG SB 810\",\"size\":\"W 8 XH 10XG 3.5\",\"info\":\"Inch\",\"paper_gsm\":\"120\",\"paper_bf\":\"20\",\"rate_per_unit\":\"3.80\",\"hsn_code\":\"48195090\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-26 19:48:30');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('121', 'acc_master', '27', 'edit', '{\"name\":\"SUNRAYS \",\"short_name\":\"S P\",\"am_code\":\"S P\",\"phone\":\"9879883902\",\"email_id\":\"\",\"vat_no\":\"19ABECS4753B1ZX\",\"address\":\"<p>\\n\\tSATYA&nbsp; COMPLEX , OPP IOC PETROL PUMP,&nbsp; &nbsp;AHMEDABAD , GUJRAT -24<\\/p>\\n\",\"place_of_supply\":\"<p>\\n\\tSATYA&nbsp; COMPLEX , OPP IOC PETROL PUMP,&nbsp; &nbsp;AHMEDABAD , GUJRAT -24<\\/p>\\n\",\"proprietor\":\"\",\"mill_id\":\"1\",\"supplier_buyer\":\"1\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-26 20:16:53');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('122', 'acc_master', '27', 'edit', '{\"name\":\"SUNRAYS \",\"short_name\":\"S P\",\"am_code\":\"S P\",\"phone\":\"9879883902\",\"email_id\":\"\",\"vat_no\":\"24ABECS4753B1ZX\",\"address\":\"<p>\\n\\tSATYA&nbsp; COMPLEX , OPP IOC PETROL PUMP,&nbsp; &nbsp;AHMEDABAD , GUJRAT -24<\\/p>\\n\",\"place_of_supply\":\"<p>\\n\\tSATYA&nbsp; COMPLEX , OPP IOC PETROL PUMP,&nbsp; &nbsp;AHMEDABAD , GUJRAT -24<\\/p>\\n\",\"proprietor\":\"\",\"mill_id\":\"1\",\"supplier_buyer\":\"1\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-26 20:18:14');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('123', 'acc_master', '12', 'edit', '{\"name\":\"SURE CARE  PVT LTD \",\"short_name\":\"SCP\",\"am_code\":\"SCP\",\"phone\":\"7000390373\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"<p>\\n\\tTOPSIA FLOOR NO 3&nbsp;<\\/p>\\n\",\"place_of_supply\":\"<p>\\n\\tTOPSIA FLOOR NO 3&nbsp;<\\/p>\\n\",\"proprietor\":\"TEJAS\",\"mill_id\":\"1\",\"supplier_buyer\":\"1\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-27 19:34:59');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('124', 'acc_master', '27', 'edit', '{\"name\":\"SUNRAYS \",\"short_name\":\"S P\",\"am_code\":\"NEEL\",\"phone\":\"9879883902\",\"email_id\":\"\",\"vat_no\":\"24ABECS4753B1ZX\",\"address\":\"<p>\\n\\tSATYA&nbsp; COMPLEX , OPP IOC PETROL PUMP,&nbsp; &nbsp;AHMEDABAD , GUJRAT -24<\\/p>\\n\",\"place_of_supply\":\"<p>\\n\\tSATYA&nbsp; COMPLEX , OPP IOC PETROL PUMP,&nbsp; &nbsp;AHMEDABAD , GUJRAT -24<\\/p>\\n\",\"proprietor\":\"\",\"mill_id\":\"1\",\"supplier_buyer\":\"1\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-27 19:35:43');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('125', 'acc_master', '12', 'edit', '{\"name\":\"SURE CARE  PVT LTD \",\"short_name\":\"SCP\",\"am_code\":\"TEJAS\",\"phone\":\"7000390373\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"<p>\\n\\tTOPSIA FLOOR NO 3&nbsp;<\\/p>\\n\",\"place_of_supply\":\"<p>\\n\\tTOPSIA FLOOR NO 3&nbsp;<\\/p>\\n\",\"proprietor\":\"TEJAS\",\"mill_id\":\"1\",\"supplier_buyer\":\"1\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-27 19:36:04');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('126', 'acc_master', '12', 'edit', '{\"name\":\"ROY TRADERS - KOLAKTA\",\"short_name\":\"ROYTRADERS\",\"am_code\":\"ROYTRADERS\",\"phone\":\"\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"<p>\\n\\tKOLKATA<\\/p>\\n\",\"place_of_supply\":\"<p>\\n\\tKOLKATA<\\/p>\\n\",\"proprietor\":\"TEJAS\",\"mill_id\":\"1\",\"supplier_buyer\":\"0\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-29 09:43:29');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('127', 'acc_master', '30', 'edit', '{\"name\":\"SURE CARE  PVT LTD\",\"short_name\":\"SCP\",\"am_code\":\"SCP\",\"phone\":\"7000390373\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"<div>\\n\\tTOPSIA FLOOR NO 3<\\/div>\\n<div>\\n\\t&nbsp;<\\/div>\\n\",\"place_of_supply\":\"<div>\\n\\tTOPSIA FLOOR NO 3<\\/div>\\n<div>\\n\\t&nbsp;<\\/div>\\n\",\"proprietor\":\"TEJAS\",\"mill_id\":\"1\",\"supplier_buyer\":\"1\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-29 09:45:31');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('128', 'acc_master', '12', 'edit', '{\"name\":\"ROY TRADERS - KOLKATA\",\"short_name\":\"ROYTRADERS\",\"am_code\":\"ROYTRADERS\",\"phone\":\"\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"<p>\\n\\tKOLKATA<\\/p>\\n\",\"place_of_supply\":\"<p>\\n\\tKOLKATA<\\/p>\\n\",\"proprietor\":\"TEJAS\",\"mill_id\":\"1\",\"supplier_buyer\":\"0\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-29 10:30:26');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('129', 'acc_master', '12', 'edit', '{\"name\":\"ROY TRADERS - KOLKATA\",\"short_name\":\"ROYTRADERS\",\"am_code\":\"ROYTRADERS\",\"phone\":\"\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"<p>\\n\\tKOLKATA<\\/p>\\n\",\"place_of_supply\":\"<p>\\n\\tKOLKATA<\\/p>\\n\",\"proprietor\":\"TEJAS\",\"mill_id\":\"1\",\"supplier_buyer\":\"0\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-29 10:30:31');
INSERT INTO `user_logs` (`ul_id`, `table_name`, `pk_id`, `action_taken`, `old_data`, `user_id`, `comment`, `status`, `create_date`) VALUES ('130', 'acc_master', '12', 'edit', '{\"name\":\"ROY TRADERS - KOLKATA\",\"short_name\":\"ROYTRADERS\",\"am_code\":\"ROYTRADERS\",\"phone\":\"\",\"email_id\":\"\",\"vat_no\":\"\",\"address\":\"<p>\\n\\tKOLKATA<\\/p>\\n\",\"place_of_supply\":\"<p>\\n\\tKOLKATA<\\/p>\\n\",\"proprietor\":\"TEJAS\",\"mill_id\":\"1\",\"supplier_buyer\":\"0\",\"status\":\"1\",\"user_id\":\"1\"}', '1', 'master', '1', '2021-07-29 10:30:38');


#
# TABLE STRUCTURE FOR: user_permission
#

DROP TABLE IF EXISTS `user_permission`;

CREATE TABLE `user_permission` (
  `up_id` int(11) NOT NULL AUTO_INCREMENT,
  `m_id` int(11) NOT NULL COMMENT 'menu id',
  `user_id` int(11) NOT NULL,
  `view_permission` tinyint(1) NOT NULL DEFAULT '1',
  `add_permission` tinyint(1) NOT NULL DEFAULT '1',
  `edit_permission` tinyint(1) NOT NULL DEFAULT '1',
  `delete_permission` tinyint(1) NOT NULL DEFAULT '1',
  `print_permission` tinyint(1) NOT NULL DEFAULT '1',
  `download_permission` tinyint(1) NOT NULL DEFAULT '1',
  `block_permission` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'menu block',
  `custom1` tinyint(1) DEFAULT '1',
  `custom2` tinyint(1) DEFAULT '1',
  `custom3` tinyint(1) DEFAULT '1',
  `custom4` tinyint(1) DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`up_id`),
  KEY `menu_id` (`m_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES ('1', '3', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '1', '1', '1', '2020-04-18 21:43:27', '2020-04-18 23:24:43');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES ('2', '5', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '1', '1', '1', '2020-04-18 21:43:27', '2020-04-18 23:34:55');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES ('3', '7', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '1', '1', '1', '2020-04-18 21:43:27', '2020-04-18 23:43:40');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES ('4', '8', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '1', '1', '1', '2020-04-18 21:43:27', '2020-04-18 23:52:12');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES ('5', '9', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '1', '1', '1', '2020-04-18 21:43:27', '2020-04-18 23:58:41');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES ('6', '10', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '1', '1', '1', '2020-04-18 21:43:27', '2020-04-18 23:58:41');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES ('7', '12', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '1', '1', '1', '2020-04-18 21:43:27', '2020-04-18 23:58:41');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES ('8', '13', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '1', '1', '1', '2020-04-18 21:43:27', '2020-04-18 23:58:41');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES ('9', '14', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '1', '1', '1', '2020-04-18 21:43:27', '2020-04-18 23:58:41');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES ('10', '15', '1', '1', '1', '1', '1', '1', '0', '0', '1', '1', '1', '1', '1', '2020-04-18 21:43:27', '2020-04-19 00:21:38');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES ('11', '16', '1', '1', '1', '1', '1', '1', '0', '0', '1', '1', '1', '1', '1', '2020-04-18 21:43:27', '2020-04-19 00:21:38');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES ('12', '17', '1', '1', '1', '1', '1', '1', '0', '0', '1', '1', '1', '1', '1', '2020-04-18 21:43:27', '2020-04-19 00:21:38');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES ('13', '18', '1', '1', '1', '1', '1', '1', '0', '0', '1', '1', '1', '1', '1', '2020-04-18 21:43:27', '2020-04-19 00:21:38');
INSERT INTO `user_permission` (`up_id`, `m_id`, `user_id`, `view_permission`, `add_permission`, `edit_permission`, `delete_permission`, `print_permission`, `download_permission`, `block_permission`, `custom1`, `custom2`, `custom3`, `custom4`, `status`, `create_date`, `modify_date`) VALUES ('14', '11', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '1', '1', '1', '2020-04-18 21:43:27', '2020-04-18 23:58:41');


#
# TABLE STRUCTURE FOR: user_reset_passwords
#

DROP TABLE IF EXISTS `user_reset_passwords`;

CREATE TABLE `user_reset_passwords` (
  `rp_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `otp` varchar(99) DEFAULT NULL,
  `time` varchar(30) DEFAULT NULL,
  `used` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`rp_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_reset_passwords_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `usertype` int(1) DEFAULT NULL COMMENT '1=admin',
  `username` varchar(30) DEFAULT NULL,
  `email` varchar(99) DEFAULT NULL,
  `pass` varchar(64) DEFAULT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `blocked` tinyint(1) NOT NULL DEFAULT '0',
  `registration_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`user_id`, `usertype`, `username`, `email`, `pass`, `verified`, `blocked`, `registration_date`) VALUES ('1', '1', 'admin', NULL, 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '1', '0', '2020-02-18 14:44:05');
INSERT INTO `users` (`user_id`, `usertype`, `username`, `email`, `pass`, `verified`, `blocked`, `registration_date`) VALUES ('2', '1', 'user', NULL, 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '1', '0', '2020-07-03 01:04:17');


